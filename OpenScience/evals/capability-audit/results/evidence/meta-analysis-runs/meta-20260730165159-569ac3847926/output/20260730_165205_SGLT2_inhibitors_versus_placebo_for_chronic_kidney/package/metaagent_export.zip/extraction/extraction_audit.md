# Data Extraction Audit

- Studies extracted: 1
- Outcomes extracted: 14
- Source quotes verified: 1
- Source quotes unverified: 2
- Source quotes not checked: 11
- Rows requiring review: 13
- Override revision: 0

| Study | Outcome | Values | Source | Confidence | Quote verified | Review |
|---|---|---|---|---|---|---|
| Miyamoto 2024 | Composite renal outcome | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | All-cause mortality | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Cardiovascular death | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Myocardial infarction | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Stroke | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Hospitalization for heart failure | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | All-cause hospitalization | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Change in eGFR slope | effect=4.4; 95% CI 1.6-7.3 | Abstract, page 1, p. 1 | high | yes | no |
| Miyamoto 2024 | Change in albuminuria (UACR) | effect=-30.8; 95% CI -42.6--16.8 | Abstract, page 1, p. 1 | high | no | yes |
| Miyamoto 2024 | Adverse events: diabetic ketoacidosis | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Adverse events: genital infections | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Adverse events: amputation | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Adverse events: fractures | no quantitative values | NR | high | not checked | yes |
| Miyamoto 2024 | Cardiovascular events (composite) | I events/total=1/49; C events/total=1/47 | Results, after Figure 7 | high | no | yes |
