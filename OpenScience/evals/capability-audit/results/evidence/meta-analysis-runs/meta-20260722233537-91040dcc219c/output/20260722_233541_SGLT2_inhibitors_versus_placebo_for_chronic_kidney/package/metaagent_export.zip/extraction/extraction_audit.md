# Data Extraction Audit

- Studies extracted: 2
- Outcomes extracted: 19
- Source quotes verified: 11
- Source quotes unverified: 8
- Source quotes not checked: 0
- Rows requiring review: 8
- Override revision: 0

| Study | Outcome | Values | Source | Confidence | Quote verified | Review |
|---|---|---|---|---|---|---|
| Herrington 2025 | Primary composite: progression of kidney disease or death from cardiovascular causes | effect=0.79; 95% CI 0.72-0.87; I events/total=865/3304; C events/total=1001/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | Kidney disease progression | effect=0.79; 95% CI 0.72-0.87; I events/total=778/3304; C events/total=897/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | Death from any cause or end-stage kidney disease | effect=0.81; 95% CI 0.72-0.9; I events/total=559/3304; C events/total=648/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | End-stage kidney disease | effect=0.74; 95% CI 0.64-0.87; I events/total=296/3304; C events/total=372/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | All-cause mortality | effect=0.86; 95% CI 0.74-1.01; I events/total=301/3304; C events/total=336/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | Cardiovascular mortality | effect=0.75; 95% CI 0.59-0.95; I events/total=126/3304; C events/total=162/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | Non-cardiovascular mortality | effect=0.97; 95% CI 0.79-1.2; I events/total=175/3304; C events/total=174/3305 | Table 3, p. 18 | high | yes | no |
| Herrington 2025 | Mean eGFR at last local measurement | effect=0.8; 95% CI 0.1-1.4; I mean/SD/N=31.4/None/3295; C mean/SD/N=30.6/None/3295 | Table 3, p. 18 | high | yes | no |
| Uchiyama 2025 | Composite of kidney disease progression | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | All-cause mortality | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Cardiovascular mortality | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Hospitalization for heart failure | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Rate of decline in eGFR (eGFRcr-cys slope) | effect=8.22; I mean/SD/N=2.57/7.88/27; C mean/SD/N=-5.65/9.57/27; p=0.002 | Table 3, p. 8 | high | yes | no |
| Uchiyama 2025 | Rate of decline in eGFR (eGFRcr slope) | effect=4.69; I mean/SD/N=1.03/10.78/27; C mean/SD/N=-3.66/8.88/27; p=0.06 | Table 3, p. 8 | high | yes | no |
| Uchiyama 2025 | Rate of decline in eGFR (eGFRcys slope) | effect=12.34; I mean/SD/N=3.91/11.4/27; C mean/SD/N=-8.43/13.44/27; p=0.003 | Table 3, p. 8 | high | yes | no |
| Uchiyama 2025 | Diabetic ketoacidosis | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Lower limb amputations | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Genital infections | no quantitative values | Not reported | low | no | yes |
| Uchiyama 2025 | Urinary tract infections | no quantitative values | Not reported | low | no | yes |
