# Data Extraction Audit

- Studies extracted: 1
- Outcomes extracted: 8
- Source quotes verified: 8
- Source quotes unverified: 0
- Source quotes not checked: 0
- Rows requiring review: 0
- Override revision: 0

| Study | Outcome | Values | Source | Confidence | Quote verified | Review |
|---|---|---|---|---|---|---|
| Herrington 2025 | Composite renal outcome (kidney disease progression or cardiovascular death) - overall | effect=0.79; 95% CI 0.72-0.87; I events/total=865/3304; C events/total=1001/3305 | Table 3, Primary outcome row, p. 18 | high | yes | no |
| Herrington 2025 | Kidney disease progression alone - overall | effect=0.79; 95% CI 0.72-0.87; I events/total=778/3304; C events/total=897/3305 | Table 3, Secondary outcomes - Kidney disease progression, p. 18 | high | yes | no |
| Herrington 2025 | Death from any cause or ESKD - overall | effect=0.81; 95% CI 0.72-0.9; I events/total=559/3304; C events/total=648/3305 | Table 3, Secondary outcomes - Death from any cause or ESKD, p. 18 | high | yes | no |
| Herrington 2025 | End-stage kidney disease (ESKD) - overall | effect=0.74; 95% CI 0.64-0.87; I events/total=296/3304; C events/total=372/3305 | Table 3, Secondary outcomes - ESKD, p. 18 | high | yes | no |
| Herrington 2025 | All-cause mortality - overall | effect=0.86; 95% CI 0.74-1.01; I events/total=301/3304; C events/total=336/3305 | Table 3, Tertiary outcomes - Death from any cause, p. 18 | high | yes | no |
| Herrington 2025 | Cardiovascular mortality - overall | effect=0.75; 95% CI 0.59-0.95; I events/total=126/3304; C events/total=162/3305 | Table 3, Tertiary outcomes - Death from cardiovascular cause, p. 18 | high | yes | no |
| Herrington 2025 | Non-cardiovascular mortality - overall | effect=0.97; 95% CI 0.79-1.2; I events/total=175/3304; C events/total=174/3305 | Table 3, Tertiary outcomes - Death from non-cardiovascular cause, p. 18 | high | yes | no |
| Herrington 2025 | eGFR at last local measurement (among those without ESKD) | effect=0.8; 95% CI 0.1-1.4; I mean/SD/N=31.4/11.48/3295; C mean/SD/N=30.6/11.48/3295 | Table 3, eGFR row, p. 18 | high | yes | no |
