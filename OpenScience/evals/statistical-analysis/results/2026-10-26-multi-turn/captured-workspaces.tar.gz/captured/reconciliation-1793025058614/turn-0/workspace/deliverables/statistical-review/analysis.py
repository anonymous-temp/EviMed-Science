#!/usr/bin/env python
"""Verification of the prior statistical report (no model training).

Reads only what was supplied with the package:
  data/prior-predictions.csv      row-level predictions (569 rows)
  data/prior-analysis-results.json structured results of the prior run
  data/breast-cancer.csv          raw WDBC extract
  data/wdbc-dictionary.md         codebook

It recomputes every number the revised report relies on from the row-level
predictions, compares it with the prior JSON, and records the comparison.
No classifier is fitted, no split is redrawn, no hyper-parameter is searched.

The only fitting done here is the 2-parameter logistic recalibration regression
(intercept, slope) on the held-out rows, because that quantity is reported and
was worth reproducing; it is a diagnostic of existing predictions, not the
prediction model.

Outputs: verification-results.json (own schema; see "shape" note below).
"""

import hashlib
import json
import math
import os
import platform
import sys

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels
import statsmodels.api as sm
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    log_loss,
    roc_auc_score,
)

Z = 1.959963984540054
PRIOR_JSON = "data/prior-analysis-results.json"
PRED_CSV = "data/prior-predictions.csv"
RAW_CSV = "data/breast-cancer.csv"
REPORT = "deliverables/statistical-review/statistical-report.md"
OUT = "deliverables/statistical-review/verification-results.json"

checks = []


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def wilson(k, n, z=Z):
    if n == 0:
        return (None, None)
    p = k / n
    den = 1.0 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


def check(cid, what, value, prior=None, tol=None, where=None):
    """Record one recomputed value and, when a prior value exists, the match."""
    rec = {"id": cid, "what": what, "recomputed": value}
    if prior is not None:
        rec["prior"] = prior
        if isinstance(value, (int, float)) and isinstance(prior, (int, float)):
            rec["match"] = bool(abs(float(value) - float(prior)) <= (tol if tol else 5e-4))
        else:
            rec["match"] = bool(value == prior)
    if where:
        rec["priorPath"] = where
    checks.append(rec)
    return rec


# ---------------------------------------------------------------- inputs ----
pred = pd.read_csv(PRED_CSV)
raw = pd.read_csv(RAW_CSV)
prior = json.load(open(PRIOR_JSON))

fp = {
    "prior-predictions.csv": {"sha256": sha256(PRED_CSV), "rows": int(len(pred))},
    "prior-analysis-results.json": {"sha256": sha256(PRIOR_JSON)},
    "breast-cancer.csv": {"sha256": sha256(RAW_CSV), "rows": int(len(raw))},
    "prior-analysis-results.json.dataFingerprint.sha256": prior["dataFingerprint"]["sha256"],
}

# ------------------------------------------------------- cohorts, denominators
n_all = len(pred)
mal_all = int((pred.y_true == 0).sum())
ben_all = int((pred.y_true == 1).sum())
train = pred[pred.split == "train"]
test = pred[pred.split == "test"]
n_tr, n_te = len(train), len(test)
mal_tr, mal_te = int((train.y_true == 0).sum()), int((test.y_true == 0).sum())
ben_tr, ben_te = int((train.y_true == 1).sum()), int((test.y_true == 1).sum())

check("n_rows", "rows in predictions file", n_all, prior["profile"]["rows"], 0, "profile.rows")
check("n_features", "feature columns in raw extract", int(raw.shape[1]) - 2,
      prior["profile"]["nFeatures"], 0, "profile.nFeatures")  # index + outcome removed
check("cohort_malignant", "malignant rows, whole file", mal_all,
      prior["profile"]["classCounts"]["malignant_source0"], 0, "profile.classCounts")
check("cohort_benign", "benign rows, whole file", ben_all,
      prior["profile"]["classCounts"]["benign_source1"], 0, "profile.classCounts")
check("prev_all", "prevalence, whole file", round(mal_all / n_all, 4),
      prior["profile"]["malignantPrevalence"], 5e-4, "profile.malignantPrevalence")
check("n_train", "training rows", n_tr, prior["diagnostics"]["trainRows"], 0, "diagnostics.trainRows")
check("n_test", "held-out rows", n_te, prior["diagnostics"]["testRows"], 0, "diagnostics.testRows")
check("mal_train", "malignant rows, training set", mal_tr,
      prior["diagnostics"]["trainMalignant"], 0, "diagnostics.trainMalignant")
check("mal_test", "malignant rows, held-out set", mal_te,
      prior["diagnostics"]["testMalignant"], 0, "diagnostics.testMalignant")
check("prev_test", "prevalence, held-out set (64/171)", round(mal_te / n_te, 4),
      prior["analyses"][0]["discrimination"]["testPrevalence"], 5e-4,
      "analyses[0].discrimination.testPrevalence")
check("prev_train", "prevalence, training set (148/398)", round(mal_tr / n_tr, 4), 0.3719, 5e-4)
den = {
    "whole_file": {"malignant": mal_all, "benign": ben_all, "n": n_all},
    "training": {"malignant": mal_tr, "benign": ben_tr, "n": n_tr},
    "held_out": {"malignant": mal_te, "benign": ben_te, "n": n_te},
}
den_add = {
    "train_plus_test_rows": n_tr + n_te,
    "train_plus_test_malignant": mal_tr + mal_te,
    "malignant_plus_benign_held_out": mal_te + ben_te,
}
check("denominator_addition", "398+171 and 148+64 and 64+107", den_add,
      {"train_plus_test_rows": 569, "train_plus_test_malignant": 212,
       "malignant_plus_benign_held_out": 171})

# raw-file profile
feat_cols = [c for c in raw.columns if c not in ("Unnamed: 0", "breast_cancer_yn")]
check("raw_missing", "missing cells in raw extract", int(raw.isna().sum().sum()),
      prior["profile"]["missingValues"], 0, "profile.missingValues")
check("raw_duplicate_all", "duplicate rows, all columns", int(raw.duplicated().sum()),
      prior["profile"]["duplicateRowsAllColumns"], 0, "profile.duplicateRowsAllColumns")
check("raw_duplicate_features", "duplicate rows on features", int(raw.duplicated(subset=feat_cols).sum()),
      prior["profile"]["duplicateRowsOnFeatures"], 0, "profile.duplicateRowsOnFeatures")
check("raw_index_unique", "record_id 0..568 unique and positional",
      bool(raw["Unnamed: 0"].is_unique and (raw["Unnamed: 0"].values == np.arange(len(raw))).all())
      and bool((pred.record_id.values == np.arange(len(pred))).all()))
check("pred_alignment", "predictions row order matches raw file order",
      bool((pred.y_true.values == raw["breast_cancer_yn"].values).all()))
check("split_overlap", "record_ids shared by training and held-out rows",
      len(set(train.record_id) & set(test.record_id)),
      prior["diagnostics"]["trainTestIdOverlap"], 0, "diagnostics.trainTestIdOverlap")

# --------------------------------------------------------- held-out metrics ----
y = (test.y_true == 0).astype(int).values  # 1 = malignant (dictionary: 0 = malignant)
s = test.p_malignant.values
a0 = prior["analyses"][0]
check("auroc", "AUROC, held-out", round(roc_auc_score(y, s), 4),
      a0["discrimination"]["auroc"], 5e-4, "analyses[0].estimate")
check("ap", "average precision, held-out", round(average_precision_score(y, s), 4),
      a0["discrimination"]["averagePrecision"], 5e-4, "discrimination.averagePrecision")
check("brier", "Brier, held-out", round(brier_score_loss(y, s), 4),
      a0["overall"]["brier"], 5e-4, "overall.brier")
check("logloss", "log loss, held-out", round(log_loss(y, s), 4),
      a0["overall"]["logLoss"], 5e-4, "overall.logLoss")
p_train = mal_tr / n_tr
ref_brier = float(np.mean(np.where(y == 1, (1 - p_train) ** 2, p_train ** 2)))
check("brier_reference", "Brier of 'always training prevalence'", round(ref_brier, 4), None)
check("bss", "Brier skill vs training prevalence", round(1 - brier_score_loss(y, s) / ref_brier, 4),
      a0["overall"]["brierSkillScoreVsTrainPrevalence"], 5e-4, "overall.brierSkillScoreVsTrainPrevalence")

# training-side values quoted in the report are in-sample fits, not out-of-fold
ytr = (train.y_true == 0).astype(int).values
check("train_auroc_in_sample", "AUROC on training rows (in-sample)",
      round(roc_auc_score(ytr, train.p_malignant.values), 4),
      a0["inSampleVsHeldOut"]["aurocTrainInSample"], 5e-4, "inSampleVsHeldOut.aurocTrainInSample")
check("train_brier_in_sample", "Brier on training rows (in-sample)",
      round(brier_score_loss(ytr, train.p_malignant.values), 4),
      a0["inSampleVsHeldOut"]["brierTrainInSample"], 5e-4, "inSampleVsHeldOut.brierTrainInSample")
check("train_column_is_in_sample", "p_malignant differs from the out-of-fold column on training rows",
      bool(not np.allclose(train.p_malignant.values, train.p_malignant_oof_train.values)))
check("json_heldout_prevalence", "results.json testPrevalence vs 64/171",
      round(mal_te / n_te, 4), a0["discrimination"]["testPrevalence"], 5e-4,
      "discrimination.testPrevalence")

# probability shape
p0 = int((s == 0).sum())
p1 = int((s == 1).sum())
below01 = int((s < 0.1).sum())
above09 = int((s > 0.9).sum())
mid = int(((s >= 0.1) & (s <= 0.9)).sum())
check("shape_below", "held-out rows with p < 0.1", below01,
      a0["probabilityShape"]["testRowsBelow0.1"], 0, "probabilityShape.testRowsBelow0.1")
check("shape_above", "held-out rows with p > 0.9", above09,
      a0["probabilityShape"]["testRowsAbove0.9"], 0, "probabilityShape.testRowsAbove0.9")
check("shape_mid", "held-out rows with 0.1 <= p <= 0.9", mid,
      a0["probabilityShape"]["testRowsBetween0.1And0.9"], 0, "probabilityShape.testRowsBetween0.1And0.9")
check("shape_sum", "98 + 55 + 18", below01 + above09 + mid, n_te, 0)
check("shape_exact", "rows exactly at p=0 / p=1", {"p0": p0, "p1": p1})

# ------------------------------------------------- operating points and CIs ----
def operating(thr):
    lab = (s >= thr).astype(int)
    tn, fp_, fn_, tp = confusion_matrix(y, lab, labels=[0, 1]).ravel()
    tp, fp_, fn_, tn = int(tp), int(fp_), int(fn_), int(tn)
    out = {
        "threshold": thr,
        "truePositive": tp, "falsePositive": fp_, "falseNegative": fn_, "trueNegative": tn,
        "predictedPositive": tp + fp_,
        "n": tp + fp_ + fn_ + tn,
        "sensitivity": tp / (tp + fn_) if tp + fn_ else None,
        "specificity": tn / (tn + fp_) if tn + fp_ else None,
        "positivePredictiveValue": tp / (tp + fp_) if tp + fp_ else None,
        "negativePredictiveValue": tn / (tn + fn_) if tn + fn_ else None,
        "accuracy": (tp + tn) / (tp + fp_ + fn_ + tn),
    }
    out["sensitivityCI95"] = wilson(tp, tp + fn_)
    out["specificityCI95"] = wilson(tn, tn + fp_)
    out["ppvCI95"] = wilson(tp, tp + fp_)
    out["npvCI95"] = wilson(tn, tn + fn_)
    return out


ops = {t: operating(t) for t in (0.1, 0.3, 0.5, 0.7, 0.9)}
o5 = ops[0.5]
for key, path in [("sensitivity", "sensitivity"), ("specificity", "specificity"),
                  ("positivePredictiveValue", "positivePredictiveValue"),
                  ("negativePredictiveValue", "negativePredictiveValue"),
                  ("accuracy", "accuracy")]:
    check(f"op05_{key}", f"threshold 0.5 {key}", round(o5[key], 4),
          a0["operatingPoints"]["0.5"][path], 5e-4, f"operatingPoints.0.5.{path}")
conf = a0["operatingPoints"]["0.5"]["confusion"]
check("op05_confusion", "threshold 0.5 confusion (TP,FP,FN,TN)",
      [o5["truePositive"], o5["falsePositive"], o5["falseNegative"], o5["trueNegative"]],
      [conf["truePositive"], conf["falsePositive"], conf["falseNegative"], conf["trueNegative"]])
for i, key in enumerate(["sensitivityCI95", "specificityCI95", "ppvCI95", "npvCI95"]):
    prior_ci_key = {"sensitivityCI95": "sensitivityCI95", "specificityCI95": "specificityCI95",
                    "ppvCI95": "positivePredictiveValueCI95",
                    "npvCI95": "negativePredictiveValueCI95"}[key]
    check(f"op05_ci{i}", f"threshold 0.5 Wilson {key}",
          [round(o5[key][0], 4), round(o5[key][1], 4)],
          a0["operatingPoints"]["0.5"][prior_ci_key], 1e-4,
          f"operatingPoints.0.5.{prior_ci_key}")

for thr in (0.1, 0.3, 0.7, 0.9):
    pp = a0["thresholdSensitivity"][f"{thr}"]
    c = pp["confusion"]
    check(f"op{thr}_confusion", f"threshold {thr} confusion",
          [ops[thr]["truePositive"], ops[thr]["falsePositive"],
           ops[thr]["falseNegative"], ops[thr]["trueNegative"]],
          [c["truePositive"], c["falsePositive"], c["falseNegative"], c["trueNegative"]])
    for k in ("sensitivity", "specificity", "positivePredictiveValue", "accuracy"):
        check(f"op{thr}_{k}", f"threshold {thr} {k}", round(ops[thr][k], 4), pp[k], 5e-4)

# what the 0.5 -> 0.3 change actually reclassifies
add_030 = test[(s >= 0.3) & (s < 0.5)]
add_010 = test[(s >= 0.1) & (s < 0.3)]
reclass = {
    "added_by_lowering_0.5_to_0.3": int(len(add_030)),
    "added_030_malignant": int((add_030.y_true == 0).sum()),
    "added_030_benign": int((add_030.y_true == 1).sum()),
    "added_by_lowering_0.3_to_0.1": int(len(add_010)),
    "added_010_malignant": int((add_010.y_true == 0).sum()),
    "added_010_benign": int((add_010.y_true == 1).sum()),
    "added_010_record_ids_malignant": add_010.loc[add_010.y_true == 0, "record_id"].tolist(),
}
check("reclassification", "rows reclassified when lowering the cut-point", reclass)

# --------------------------------------------------------------- calibration --
eps = 1e-12
sc = np.clip(s, eps, 1 - eps)
lp = np.log(sc / (1 - sc))
cal = sm.GLM(y, sm.add_constant(lp), family=sm.families.Binomial()).fit()
ci = cal.conf_int()
calibration = {
    "intercept": float(cal.params[0]), "slope": float(cal.params[1]),
    "interceptCI95": [float(ci[0][0]), float(ci[0][1])],
    "slopeCI95": [float(ci[1][0]), float(ci[1][1])],
    "n": int(len(y)), "note": "2-parameter diagnostic re-fit of reported intercept/slope; not the prediction model",
}
check("cal_intercept", "calibration intercept", round(calibration["intercept"], 4),
      a0["calibration"]["intercept"], 5e-4, "calibration.intercept")
check("cal_slope", "calibration slope", round(calibration["slope"], 4),
      a0["calibration"]["slope"], 5e-4, "calibration.slope")
check("cal_intercept_ci", "calibration intercept CI",
      [round(calibration["interceptCI95"][0], 4), round(calibration["interceptCI95"][1], 4)],
      a0["calibration"]["interceptCI95"], 1e-4)
check("cal_slope_ci", "calibration slope CI",
      [round(calibration["slopeCI95"][0], 4), round(calibration["slopeCI95"][1], 4)],
      a0["calibration"]["slopeCI95"], 1e-4)

bins = []
for b in a0["calibrationBins"]:
    sel = (s >= b["lower"]) & ((s < b["upper"]) if not b["upperInclusive"] else (s <= b["upper"]))
    bins.append({
        "range": f"[{b['lower']:.1f},{b['upper']:.1f}{']' if b['upperInclusive'] else ')'}",
        "count": int(sel.sum()),
        "events": int(y[sel].sum()),
        "meanProbability": round(float(s[sel].mean()), 4) if sel.sum() else None,
        "eventRate": round(float(y[sel].mean()), 4) if sel.sum() else None,
        "priorCount": b["count"], "priorEvents": b["events"],
        "countMatch": bool(int(sel.sum()) == b["count"] and int(y[sel].sum()) == b["events"]),
    })
check("calib_bins", "all 10 calibration bins reproduce count/events",
      all(b["countMatch"] for b in bins), True)
check("calib_bins_total", "bin counts sum to held-out n", sum(b["count"] for b in bins), n_te, 0)

# ------------------------------------------------------- L1 control model -----
s1 = test.p_malignant_l1.values
l1 = prior["analyses"][1]
check("l1_auroc", "L1 AUROC", round(roc_auc_score(y, s1), 4), l1["discrimination"]["auroc"], 5e-4)
check("l1_ap", "L1 average precision", round(average_precision_score(y, s1), 4),
      l1["discrimination"]["averagePrecision"], 5e-4)
check("l1_brier", "L1 Brier", round(brier_score_loss(y, s1), 4), l1["overall"]["brier"], 5e-4)
check("l1_logloss", "L1 log loss", round(log_loss(y, s1), 4), l1["overall"]["logLoss"], 5e-4)
check("l1_nselected", "L1 non-zero features", prior["coefficients"]["l1NSelected"], 14, 0)
check("l1_nzeroed", "L1 zeroed features", len(prior["coefficients"]["l1ZeroedFeatures"]), 16, 0)
check("l1_pred_column", "pred_malignant_l1_at_0.5 equals p_malignant_l1 >= 0.5",
      int(((s1 >= 0.5).astype(int) != test["pred_malignant_l1_at_0.5"].values).sum()), 0, 0)

# ------------------------------------------------------------ coefficients ----
rows = sorted(prior["coefficients"]["l2Rows"], key=lambda r: -abs(r["coefPerSD"]))
coef = [{"feature": r["feature"], "coefPerSD": r["coefPerSD"],
         "oddsRatioPerSD": r["oddsRatioPerSD"],
         "oddsRatioCI95": r["oddsRatioCI95Bootstrap"],
         "signShare": r["bootstrapSameSignShare"]} for r in rows[:8]]
exp_ok = max(abs(math.exp(r["coefPerSD"]) - r["oddsRatioPerSD"]) for r in rows)
check("coef_exp", "OR = exp(coef) for every coefficient", round(exp_ok, 6), 0.0, 1e-3)
tr_raw = raw.iloc[train.record_id.values][feat_cols]
corr = tr_raw.corr().abs().values
np.fill_diagonal(corr, 0)
pairs_ge_098 = int((corr >= 0.98).sum() // 2)
check("collinear_pairs", "training-set feature pairs with |r| >= 0.98", pairs_ge_098,
      prior["diagnostics"]["featurePairsAbsRAtLeast098"], 0, "diagnostics")
check("collinear_max", "max |r| in training set", round(float(corr.max()), 4),
      prior["diagnostics"]["maxAbsFeatureCorrelationTrain"], 5e-4)

# ------------------------------------------- out-of-fold 95% sensitivity cut ---
oof = train.p_malignant_oof_train.values
yo = (train.y_true == 0).astype(int).values
mal_oof = np.sort(oof[yo == 1])
# the lowest cut that still keeps >= 95% of malignant rows is the k-th smallest
# malignant out-of-fold probability, k = ceil(0.95 * n_malignant); ties above it
# are counted by the sensitivity recomputation below
k = int(np.ceil(0.95 * len(mal_oof)))
simplest = float(mal_oof[len(mal_oof) - k])
oof_sens = float(((oof >= simplest) & (yo == 1)).sum() / (yo == 1).sum())
check("oof_threshold", "training out-of-fold 95%-sensitivity cut", round(simplest, 4),
      prior["thresholds"]["trainCV95Sensitivity"], 5e-4, "thresholds.trainCV95Sensitivity")
check("oof_sensitivity", "out-of-fold sensitivity at that cut", round(oof_sens, 4),
      prior["thresholds"]["trainCV95SensitivityOofSensitivity"], 5e-4)
check("oof_test_equals_050", "held-out confusion at the out-of-fold cut equals that at 0.5",
      [ops[0.5]["truePositive"], ops[0.5]["falsePositive"]],
      [a0["operatingPoints"]["trainCV95Sensitivity"]["confusion"]["truePositive"],
       a0["operatingPoints"]["trainCV95Sensitivity"]["confusion"]["falsePositive"]])

# ------------------------------------------------------------------ errors ----
err = []
for rid, kind in [(135, "falseNegative"), (213, "falseNegative"), (413, "falsePositive")]:
    r = test[test.record_id == rid].iloc[0]
    err.append({"record_id": int(rid), "p_malignant": round(float(r.p_malignant), 4),
                "trueLabel": "malignant" if r.y_true == 0 else "benign", "kind": kind})
check("errors", "records misclassified at 0.5",
      [(e["record_id"], e["p_malignant"]) for e in err],
      [(e["record_id"], round(e["pMalignant"], 4)) for e in a0["errorsAt0.5"]])

# -------------------------------- PPV is tied to the held-out prevalence ------
se = o5["sensitivity"]
sp = o5["specificity"]


def ppv_at(prev):
    return (se * prev) / (se * prev + (1 - sp) * (1 - prev))


ppv_by_prevalence = {f"{p}": round(ppv_at(p), 4) for p in (0.3726, mal_te / n_te, 0.05, 0.01)}
check("ppv_selfconsistent", "PPV recomputed from own sensitivity/specificity at held-out prevalence",
      round(ppv_at(mal_te / n_te), 4), round(o5["positivePredictiveValue"], 4), 5e-4)
check("ppv_full_cohort_prev", "PPV if the prevalence were the whole-file 37.3%",
      round(ppv_at(mal_all / n_all), 4))
check("ppv_denominator", "PPV denominator = held-out rows predicted malignant",
      {"predictedPositive": o5["predictedPositive"], "TP": o5["truePositive"],
       "FP": o5["falsePositive"], "sensitivityDenominator": mal_te})
check("ppv_not_sensitivity", "PPV 62/63 vs sensitivity 62/64",
      {"ppv": o5["positivePredictiveValue"], "sensitivity": se})

# ------------------------------------------------- review of report bindings --
bindings = []
if os.path.exists(REPORT):
    text = open(REPORT, encoding="utf-8").read()
    wanted = {
        "auroc_0993": "0.993",
        "auroc_ci": "0.981–1.000",
        "brier_0022": "0.022",
        "confusion_row_malignant": "| 实际恶性 | 62 | 2 |",
        "confusion_row_benign": "| 实际良性 | 1 | 106 |",
        "se_0969": "0.969",
        "sp_0991": "0.991",
        "ppv_0984": "0.984",
        "npv_0982": "0.982",
        "prev_whole_373": "37.3%",
        "prev_heldout_374": "37.4%",
        "prev_train_372": "37.2%",
        "ppv_denominator_63": "63 例",
        "ppv_at_5pct": f"{ppv_by_prevalence['0.05']:.3f}",
        "ppv_at_1pct": f"{ppv_by_prevalence['0.01']:.3f}",
        "thr03_row": "| 实际恶性 | 62 | 2 |",
        "holdout_malignant_64": "64 例",
        "full_malignant_212": "212 例",
        "shape_98": "98 例",
        "shape_55": "55 例",
        "shape_18": "18 例",
        "errors_135": "0.115",
        "errors_213": "0.016",
        "errors_413": "0.642",
        "coef_radius_error": "3.64",
        "l1_nonzero_14": "14",
        "oof_0497": "0.497",
    }
    for k2, needle in wanted.items():
        bindings.append({"id": k2, "text": needle, "found": needle in text})
    check("report_bindings", "display strings present in the revised report",
          f"{sum(b['found'] for b in bindings)}/{len(bindings)}", None)

# ------------------------------------------------------------------ output ----
results = {
    "schemaVersion": 1,
    "id": "prior-report-verification",
    "status": "complete",
    "method": ("independent recomputation from row-level predictions; no classifier fitted, "
               "no split redrawn, no hyper-parameter searched; the only fit is the 2-parameter "
               "recalibration diagnostic"),
    "inputs": fp,
    "software": {"python": platform.python_version(), "numpy": np.__version__,
                 "pandas": pd.__version__, "scipy": scipy.__version__,
                 "scikit-learn": sklearn.__version__, "statsmodels": statsmodels.__version__},
    "cohorts": den,
    "heldOut": {"n": n_te, "malignant": mal_te, "prevalence": mal_te / n_te},
    "auroc": round(roc_auc_score(y, s), 4),
    "brier": round(brier_score_loss(y, s), 4),
    "brierReference": round(ref_brier, 4),
    "calibration": calibration,
    "calibrationBins": bins,
    "operatingPoints": {str(t): ops[t] for t in ops},
    "reclassification": reclass,
    "coefficientsTop8": coef,
    "oofThreshold": {"cut": simplest, "oofSensitivity": oof_sens, "k": k, "nMalignant": len(mal_oof)},
    "errorsAt0.5": err,
    "ppvByPrevalence": ppv_by_prevalence,
    "probabilityShape": {"below0.1": below01, "above0.9": above09, "mid": mid,
                         "exactly0": p0, "exactly1": p1},
    "reportBindings": bindings,
    "checks": checks,
    "summary": {
        "nChecks": len(checks),
        "mismatches": [c["id"] for c in checks if c.get("match") is False],
        "bindingFailures": [b["id"] for b in bindings if not b["found"]],
    },
}

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(results, fh, ensure_ascii=False, indent=2)

# ---- second output: results in the documented analysis-results shape --------
def entry(eid, method, estimand, n, estimate, interval=None, warnings=None, status="complete"):
    e = {"id": eid, "status": status, "method": method, "estimand": estimand, "n": n,
         "estimate": estimate, "warnings": warnings or []}
    if interval:
        e["interval"] = interval
        e["intervalLevel"] = 0.95
    return e


flagged = [c for c in checks if c.get("match") is False]
canonical = {
    "schemaVersion": 1,
    "id": "prior-report-verification",
    "status": "complete",
    "note": ("Re-verification of an existing report from its supplied row-level predictions. "
             "No classifier was fitted; the reported performance was recomputed and compared. "
             "The only fit is the 2-parameter recalibration diagnostic."),
    "inputs": fp,
    "software": results["software"],
    "analyses": [
        entry("cohort_counts", "row-level count of the supplied predictions",
              "rows / malignant / benign per population", n_all,
              {"wholeFile": den["whole_file"], "training": den["training"],
               "heldOut": den["held_out"]},
              warnings=["64 malignant rows are the held-out population; the whole file has 212"]),
        entry("heldout_discrimination", "recomputed from p_malignant on held-out rows",
              "AUROC and average precision", n_te,
              {"auroc": results["auroc"], "averagePrecision": round(average_precision_score(y, s), 4)},
              {"auroc95": prior["analyses"][0]["discrimination"]["aurocCI95Bootstrap"],
               "note": "bootstrap interval recorded in the prior results, not recomputed here"}),
        entry("heldout_overall_accuracy_scores", "recomputed from p_malignant on held-out rows",
              "Brier score, log loss, Brier skill vs training prevalence", n_te,
              {"brier": results["brier"], "logLoss": round(log_loss(y, s), 4),
               "brierReference": results["brierReference"],
               "brierSkillScoreVsTrainPrevalence": round(1 - brier_score_loss(y, s) / ref_brier, 4),
               "referencePrevalence": round(p_train, 4)}),
        *[entry(f"operating_point_{str(t).replace('.', '_')}",
                "threshold applied to the fixed held-out probabilities",
                "confusion matrix, sensitivity, specificity, predictive values at threshold "
                f"{t} (predict malignant when p >= {t})", n_te,
                {k: ops[t][k] for k in ("threshold", "predictedPositive", "truePositive",
                                        "falsePositive", "falseNegative", "trueNegative",
                                        "sensitivity", "specificity", "positivePredictiveValue",
                                        "negativePredictiveValue", "accuracy")},
                {"sensitivityWilson": ops[t]["sensitivityCI95"],
                 "specificityWilson": ops[t]["specificityCI95"],
                 "ppvWilson": ops[t]["ppvCI95"], "npvWilson": ops[t]["npvCI95"],
                 "method": "Wilson score interval"},
                warnings=(["zero false positives: PPV 1.0 is a boundary value of a small sample"]
                          if ops[t]["falsePositive"] == 0 else
                          (["PPV is conditional on the held-out prevalence 64/171 = 37.4%"] if t == 0.5 else [])))
        for t in (0.1, 0.3, 0.5, 0.7, 0.9)],
        entry("calibration_logistic_recalibration", "logit(event) = a + b * logit(p) on held-out rows",
              "recalibration intercept and slope", n_te,
              {"intercept": round(calibration["intercept"], 4), "slope": round(calibration["slope"], 4)},
              {"interceptCI95": [round(v, 4) for v in calibration["interceptCI95"]],
               "slopeCI95": [round(v, 4) for v in calibration["slopeCI95"]],
               "method": "Wald interval from the 2-parameter GLM"},
              warnings=["diagnostic of existing predictions, not the prediction model"]),
        entry("calibration_bins", "10 equal-width bins of the held-out probabilities",
              "count, events, mean predicted probability and observed rate per bin", n_te,
              {"bins": bins},
              warnings=["bins outside 0.1-0.9 hold 0-5 rows each; per-bin rates are unstable"]),
        entry("ppv_prevalence_transposition",
              "Bayes arithmetic with this report's sensitivity 0.96875 and specificity 0.990654",
              "PPV if the malignant proportion were 37.4%, 5% or 1%", n_te,
              {"atHeldOutPrevalence": ppv_by_prevalence["0.3742690058479532"],
               "at5Percent": ppv_by_prevalence["0.05"], "at1Percent": ppv_by_prevalence["0.01"]},
              warnings=["illustration of prevalence dependence, not a re-analysis of this dataset",
                        "no external population prevalence is assumed or estimated"]),
        entry("sparsity_control_l1", "L1-penalised logistic regression, same split and selection rule",
              "AUROC, average precision, Brier, log loss, selected features", n_te,
              {"auroc": round(roc_auc_score(y, s1), 4),
               "averagePrecision": round(average_precision_score(y, s1), 4),
               "brier": round(brier_score_loss(y, s1), 4), "logLoss": round(log_loss(y, s1), 4),
               "nonZeroFeatures": prior["coefficients"]["l1NSelected"],
               "zeroedFeatures": len(prior["coefficients"]["l1ZeroedFeatures"]), "nFeatures": 30}),
        entry("out_of_fold_95pct_sensitivity_cut",
              "lowest cut keeping out-of-fold sensitivity >= 0.95 on training rows",
              "cut-point and its out-of-fold sensitivity", n_tr,
              {"cut": round(simplest, 4), "outOfFoldSensitivity": round(oof_sens, 4),
               "malignantCovered": int(round(oof_sens * len(mal_oof))), "malignantTotal": len(mal_oof)},
              warnings=["held-out confusion at this cut equals the one at 0.5; the cut was not "
                        "selected on held-out rows"]),
        entry("misclassified_records_at_0.5", "inspection of the held-out rows called wrong at 0.5",
              "record_id and predicted probability of each error", n_te, {"records": err}),
        entry("verification_against_prior_results",
              "recomputation of every report number, compared with the supplied results file",
              "number of checks and mismatches", None,
              {"checks": len(checks), "mismatches": len(flagged),
               "mismatchedIds": [c["id"] for c in flagged],
               "reportStringBindings": {"total": len(bindings),
                                        "missing": [b["id"] for b in bindings if not b["found"]]}},
              status="complete" if not flagged else "partial"),
    ],
    "cohorts": den,
    "ppvByPrevalence": ppv_by_prevalence,
    "probabilityShape": results["probabilityShape"],
    "checks": {"total": len(checks), "mismatches": [c["id"] for c in flagged]},
}

CANON = "deliverables/statistical-review/analysis-results.json"
with open(CANON, "w", encoding="utf-8") as fh:
    json.dump(canonical, fh, ensure_ascii=False, indent=2)

print(json.dumps({
    "checks": len(checks),
    "mismatches": results["summary"]["mismatches"],
    "bindingFailures": results["summary"]["bindingFailures"],
    "ppvByPrevalence": ppv_by_prevalence,
    "calibration": [round(calibration["intercept"], 4), round(calibration["slope"], 4)],
    "reclass": reclass,
    "oof": [round(simplest, 4), round(oof_sens, 4)],
    "bins": [(b["range"], b["count"], b["events"]) for b in bins],
}, ensure_ascii=False, indent=1))
