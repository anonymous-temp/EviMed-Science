#!/usr/bin/env Rscript
# Independent cross-check (R) of the group B minus group A difference in the
# marker, plus the figure. Run after analysis.py (needs
# table-difference-estimates.csv for the forest panel).
#
#   Rscript crosscheck.R <data.csv> <outdir> [plotScale] [plotUnit]
#   e.g. Rscript crosscheck.R ../../data/cohort.csv . 0.1 cm
#
# crosscheck-r.json always holds millimetre values (the analysis unit); the
# optional plotScale/plotUnit only change what the figure draws and prints.

args <- commandArgs(trailingOnly = TRUE)
input <- if (length(args) >= 1) args[1] else "../../data/cohort.csv"
outdir <- if (length(args) >= 2) args[2] else "."
plot_scale <- if (length(args) >= 3) as.numeric(args[3]) else 1
plot_unit <- if (length(args) >= 4) args[4] else "mm"
if (!is.finite(plot_scale) || plot_scale <= 0) stop("plot scale must be positive")

d <- read.csv(input, stringsAsFactors = FALSE)
stopifnot(all(c("patient_id", "group", "age", "marker_mm") %in% names(d)))
d <- d[!is.na(d$marker_mm) & d$group %in% c("A", "B"), ]
a <- d$marker_mm[d$group == "A"]
b <- d$marker_mm[d$group == "B"]

alpha <- 0.05

# Hodges-Lehmann shift estimate and its distribution-free interval, R implementation
w <- wilcox.test(b, a, conf.int = TRUE, conf.level = 1 - alpha, exact = FALSE)
# Welch and pooled t intervals in a second implementation
tw <- t.test(b, a, var.equal = FALSE, conf.level = 1 - alpha)
tp <- t.test(b, a, var.equal = TRUE, conf.level = 1 - alpha)

hl <- list(
  estimate = unname(w$estimate),
  conf.low = unname(w$conf.int[1]),
  conf.high = unname(w$conf.int[2]),
  W = unname(w$statistic),
  p.value = unname(w$p.value),
  method = "Hodges-Lehmann shift (R wilcox.test conf.int, normal approximation)"
)

sha256 <- function(p) {
  if (!file.exists(p)) return(NA_character_)
  out <- tryCatch(
    system2("shasum", c("-a", "256", shQuote(p)), stdout = TRUE),
    error = function(e) NA_character_
  )
  if (length(out) == 0 || is.na(out[1])) return(NA_character_)
  sub("[[:space:]].*$", "", out[1])
}

res <- list(
  schemaVersion = 1,
  generatedAt = format(as.POSIXct(Sys.time(), tz = "UTC"), "%Y-%m-%dT%H:%M:%SZ"),
  interpreter = "R",
  rVersion = R.version.string,
  input = basename(input),
  inputSha256 = sha256(input),
  analysisUnit = "mm",
  plottedUnit = plot_unit,
  plottedScale = plot_scale,
  n = list(A = length(a), B = length(b)),
  hodgesLehmann = hl,
  welch = list(estimate = unname(tw$estimate[1] - tw$estimate[2]), conf.low = unname(tw$conf.int[1]),
               conf.high = unname(tw$conf.int[2]), p.value = unname(tw$p.value),
               df = unname(tw$parameter)),
  pooled = list(estimate = unname(tp$estimate[1] - tp$estimate[2]), conf.low = unname(tp$conf.int[1]),
                conf.high = unname(tp$conf.int[2]), p.value = unname(tp$p.value),
                df = unname(tp$parameter)),
  ciMethodAgreement = list(
    welchDelta = c(unname(tw$conf.int[1]) - 2.315310398856515,
                   unname(tw$conf.int[2]) - 3.6046648511434816)
  )
)

writeLines(jsonlite::toJSON(res, auto_unbox = TRUE, pretty = TRUE, digits = 8),
           file.path(outdir, "crosscheck-r.json"))

# ------------------------------------------------------------------ figure
col_A <- "#4F6D8F"; col_B <- "#B5643C"; grey <- "#5A5A5A"
pa <- a * plot_scale; pb <- b * plot_scale
dec <- if (max(c(pa, pb)) < 10) 3 else 2
fmt_v <- function(x) formatC(x, format = "f", digits = dec)

png(file.path(outdir, "fig-marker-by-group.png"), width = 2000, height = 1150,
    res = 220, type = "cairo")
layout(matrix(c(1, 2), nrow = 1), widths = c(1, 1.25))
par(mar = c(4.2, 4.4, 3.0, 1.0), mgp = c(2.6, 0.7, 0), las = 1, cex.axis = 0.85,
    cex.lab = 0.95, cex.main = 1.0, family = "sans", col.axis = grey, col.lab = grey)

# panel 1: distributions
set.seed(20261026)
strip <- function(x, at, col) {
  j <- at + runif(length(x), -0.16, 0.16)
  points(j, x, pch = 21, cex = 0.7, bg = adjustcolor(col, 0.35), col = adjustcolor(col, 0.9), lwd = 0.7)
}
yr <- range(c(pa, pb)); yr <- yr + c(-0.06, 0.06) * diff(yr)
boxplot(list(A = pa, B = pb), names = c("A", "B"), col = c(adjustcolor(col_A, 0.18), adjustcolor(col_B, 0.18)),
        border = c(col_A, col_B), outline = FALSE, widths = 0.5, ylim = yr,
        ylab = sprintf("marker (%s)", plot_unit), xlab = "", main = "Baseline marker by group",
        frame.plot = FALSE, boxwex = 0.5)
strip(pa, 1, col_A); strip(pb, 2, col_B)
for (i in 1:2) {
  x <- if (i == 1) pa else pb
  cc <- if (i == 1) col_A else col_B
  m <- mean(x); se <- sd(x) / sqrt(length(x)); tt <- qt(0.975, length(x) - 1)
  segments(i + 0.30, m - tt * se, i + 0.30, m + tt * se, col = cc, lwd = 1.6)
  points(i + 0.30, m, pch = 18, cex = 1.5, col = cc)
}
legend("topleft", legend = c("mean with 95% CI", "individual patients"),
       pch = c(18, 21), pt.cex = c(1.4, 0.9), col = c(grey, grey), bty = "n", cex = 0.7,
       pt.bg = c(NA, adjustcolor(grey, 0.3)))
mtext(sprintf("A: n=%d, mean %s %s      B: n=%d, mean %s %s",
              length(a), fmt_v(mean(pa)), plot_unit, length(b), fmt_v(mean(pb)), plot_unit),
      side = 1, line = 2.4, cex = 0.72, col = grey)

# panel 2: forest of the difference estimates
par(mar = c(4.2, 6.2, 3.0, 1.4))
tab <- read.csv(file.path(outdir, "table-difference-estimates.csv"), stringsAsFactors = FALSE)
est_col <- grep("^estimate", names(tab), value = TRUE)[1]
lab <- c(primary_welch = "Welch t", pooled_t = "Pooled t",
         bootstrap_percentile = "Bootstrap", ancova_age = "ANCOVA (age)")
rows <- data.frame(
  label = c(lab[tab$analysis], "Hodges-Lehmann"),
  est = c(tab[[est_col]], hl$estimate) * plot_scale,
  lo = c(tab$low, hl$conf.low) * plot_scale,
  hi = c(tab$high, hl$conf.high) * plot_scale,
  col = c(rep(col_A, nrow(tab)), col_B),
  stringsAsFactors = FALSE
)
nr <- nrow(rows)
ylim <- c(0.4, nr + 0.75)
xr <- range(c(0, rows$lo, rows$hi)); pad <- 0.12 * diff(xr)
plot(NA, xlim = c(0 - pad, xr[2] + pad), ylim = ylim, yaxt = "n",
     xlab = sprintf("difference B - A (%s)", plot_unit),
     ylab = "", main = "Estimate and 95% interval", frame.plot = FALSE, bty = "n")
abline(v = 0, lty = 3, col = grey, lwd = 1.2)
abline(v = (mean(b) - mean(a)) * plot_scale, lty = 2, col = adjustcolor(grey, 0.6), lwd = 1)
for (i in 1:nr) {
  y <- nr - i + 1
  segments(rows$lo[i], y, rows$hi[i], y, col = rows$col[i], lwd = 2.4)
  points(rows$est[i], y, pch = 15, cex = 1.5, col = rows$col[i])
}
axis(2, at = nr:1, labels = rows$label, tick = FALSE, cex.axis = 0.8, col.axis = grey)
text(rows$est, (nr:1) + 0.32,
     sprintf("%s [%s, %s]", fmt_v(rows$est), fmt_v(rows$lo), fmt_v(rows$hi)),
     cex = 0.62, col = rows$col)
mtext("Synthetic fixture data; distance between groups, not a causal effect",
      side = 3, line = 0.2, cex = 0.62, col = grey, adj = 0)
dev.off()

cat(sprintf("wrote crosscheck-r.json (mm) and fig-marker-by-group.png (plotted in %s)\n", plot_unit))
cat(sprintf("HL %.4f [%.4f, %.4f] mm, p=%.3g\n", hl$estimate, hl$conf.low, hl$conf.high, hl$p.value))
