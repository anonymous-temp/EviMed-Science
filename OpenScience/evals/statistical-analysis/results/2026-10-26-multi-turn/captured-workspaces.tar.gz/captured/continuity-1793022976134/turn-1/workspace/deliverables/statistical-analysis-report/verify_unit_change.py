#!/usr/bin/env python3
"""Check that the cm report equals a full re-analysis of the data in cm.

Method: take the same cohort, divide marker_mm by 10 once (so the file is a
centimetre copy of the same patients), rerun analysis.py and crosscheck.R on it
with the same seed, then compare:

  * every length quantity that convert_units.py divided by 10 must equal the
    re-run value (differences only from the 4-6 decimal rounding of results);
  * every quantity that must survive a change of unit (t, df, p, d, g, U, W,
    KS D, correlations, P(B>A)) must be identical to the millimetre run.

Writes unit-change-check.json and exits non-zero if any comparison fails.

Usage:  python3 verify_unit_change.py
"""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = (HERE / "../../data/cohort.csv").resolve()
DICT = (HERE / "../../data/dictionary.md").resolve()

# length paths that the conversion divides by 10 (mirrors convert_units.SCALE)
SCALE_PATHS = {
    "descriptive_by_group": ["estimate.by_group.A.mean", "estimate.by_group.A.sd",
                             "estimate.by_group.A.median", "estimate.by_group.A.q1",
                             "estimate.by_group.A.q3", "estimate.by_group.A.min",
                             "estimate.by_group.A.max", "estimate.by_group.B.mean",
                             "estimate.by_group.B.sd", "estimate.by_group.B.median",
                             "estimate.by_group.B.q1", "estimate.by_group.B.q3",
                             "estimate.by_group.B.min", "estimate.by_group.B.max",
                             "estimate.difference_of_means_raw"],
    "primary_mean_difference_welch": ["estimate", "interval.low", "interval.high",
                                      "statistics.se", "statistics.group_sd.A",
                                      "statistics.group_sd.B"],
    "crosscheck_mean_difference_pooled_t": ["estimate", "interval.low", "interval.high",
                                            "statistics.pooled_sd"],
    "crosscheck_bootstrap_percentile": ["estimate", "interval.low", "interval.high",
                                       "statistics.bootstrap_se"],
    "effect_size_cohens_d": ["statistics.pooled_sd"],
    "sensitivity_ancova_adjusted_for_age": ["estimate", "interval.low", "interval.high",
                                           "statistics.hc3_interval.low",
                                           "statistics.hc3_interval.high",
                                           "statistics.age_coefficient"],
}

KEEP_PATHS = {
    "primary_mean_difference_welch": ["statistics.t", "statistics.df", "pValue"],
    "crosscheck_mean_difference_pooled_t": ["statistics.t", "pValue"],
    "crosscheck_mann_whitney": ["estimate.U_B", "estimate.prob_B_greater_than_A_estimate", "pValue"],
    "effect_size_cohens_d": ["estimate", "interval.low", "interval.high",
                             "statistics.hedges_g", "statistics.hedges_J"],
    "sensitivity_ancova_adjusted_for_age": ["pValue", "statistics.r_squared", "statistics.age_p",
                                            "statistics.age_balance.mean_A",
                                            "statistics.age_balance.mean_B",
                                            "statistics.age_balance.difference_B_minus_A"],
    "diagnostics_distributional": ["estimate.shapiro.A.W", "estimate.shapiro.B.W",
                                   "estimate.shapiro.A.p", "estimate.shapiro.B.p",
                                   "estimate.levene_mean_centered.W",
                                   "estimate.levene_mean_centered.p",
                                   "estimate.ks_two_sample.D", "estimate.ks_two_sample.p"],
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def get(obj, path: str):
    cur = obj
    for part in path.split("."):
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    return cur


def close(a: float, b: float, rel: float, abs_tol: float = 0.0) -> bool:
    if a is None or b is None:
        return False
    return abs(a - b) <= max(abs_tol, rel * max(abs(a), abs(b)))


def main() -> int:
    import pandas as pd

    tmp = Path(tempfile.mkdtemp(prefix="unit-check-"))
    try:
        df = pd.read_csv(DATA)
        cm = df.copy()
        cm["marker_mm"] = cm["marker_mm"] / 10.0
        cm_path = tmp / "cohort_cm.csv"
        # full precision: the copy must be the same numbers divided by ten, so
        # that rank-based quantities (Hodges-Lehmann endpoints) are unaffected by
        # rounding to a fixed number of decimals
        cm.to_csv(cm_path, index=False, float_format="%.12f")

        py = subprocess.run(
            [sys.executable, str(HERE / "analysis.py"), "--input", str(cm_path),
             "--dictionary", str(DICT), "--outdir", str(tmp), "--seed", "20261026",
             "--bootstrap", "20000"],
            capture_output=True, text=True, cwd=str(HERE))
        if py.returncode != 0:
            print(py.stdout[-2000:], py.stderr[-2000:])
            raise SystemExit("analysis.py failed on the centimetre copy")

        r = subprocess.run(["Rscript", str(HERE / "crosscheck.R"), str(cm_path), str(tmp)],
                           capture_output=True, text=True, cwd=str(HERE))
        if r.returncode != 0:
            print(r.stdout[-2000:], r.stderr[-2000:])
            raise SystemExit("crosscheck.R failed on the centimetre copy")

        rerun = json.loads((tmp / "analysis-results.json").read_text(encoding="utf-8"))
        rerun_by_id = {a["id"]: a for a in rerun["analyses"]}
        converted = json.loads((HERE / "analysis-results-cm.json").read_text(encoding="utf-8"))
        conv_by_id = {a["id"]: a for a in converted["analyses"]}
        mm = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
        mm_by_id = {a["id"]: a for a in mm["analyses"]}

        rows, failures = [], 0
        for aid, paths in SCALE_PATHS.items():
            for p in paths:
                conv_v = get(conv_by_id[aid], p)
                run_v = get(rerun_by_id[aid], p)
                diff = abs(conv_v - run_v)
                ok = close(conv_v, run_v, 1e-6, 2e-6)
                failures += 0 if ok else 1
                rows.append({"analysis": aid, "field": p, "check": "scaled",
                             "reported_cm": conv_v, "rerun_cm": run_v,
                             "abs_diff": diff, "status": "ok" if ok else "FAIL"})

        for aid, paths in KEEP_PATHS.items():
            for p in paths:
                mm_v = get(mm_by_id[aid], p)
                run_v = get(rerun_by_id[aid], p)
                tol = 1e-3 if (p.lower().endswith("p") or "pvalue" in p.lower()) else 1e-9
                ok = close(mm_v, run_v, tol, 1e-12)
                failures += 0 if ok else 1
                rows.append({"analysis": aid, "field": p, "check": "unchanged",
                             "value_mm_run": mm_v, "rerun_cm_run": run_v,
                             "rel_diff": 0.0 if mm_v in (0, None) else abs(mm_v - run_v) / abs(mm_v),
                             "status": "ok" if ok else "FAIL"})

        # Hodges-Lehmann: converted value vs the re-run on the centimetre copy
        hl_mm = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))["hodgesLehmann"]
        hl_run = json.loads((tmp / "crosscheck-r.json").read_text(encoding="utf-8"))["hodgesLehmann"]
        hl_conv = {k: round(hl_mm[k] / 10.0, 10) for k in ("estimate", "conf.low", "conf.high")}
        # R locates the asymptotic shift interval by root finding with an absolute
        # tolerance of about 1.2e-4 (sqrt(.Machine$double.eps)), so its endpoints
        # carry that numerical slack; the shift estimate itself is the exact median
        # of the Walsh averages and must match to rounding.
        for k in ("estimate", "conf.low", "conf.high"):
            tol = 1e-6 if k == "estimate" else 1.5e-4
            ok = close(hl_conv[k], hl_run[k], 1e-6, tol)
            failures += 0 if ok else 1
            rows.append({"analysis": "hodges_lehmann_r", "field": k, "check": "scaled",
                         "reported_cm": hl_conv[k], "rerun_cm": hl_run[k],
                         "abs_diff": abs(hl_conv[k] - hl_run[k]),
                         "tolerance": tol, "status": "ok" if ok else "FAIL"})
        ok = close(hl_mm["p.value"], hl_run["p.value"], 1e-6, 1e-15)
        failures += 0 if ok else 1
        rows.append({"analysis": "hodges_lehmann_r", "field": "p.value", "check": "unchanged",
                     "value_mm_run": hl_mm["p.value"], "rerun_cm_run": hl_run["p.value"],
                     "rel_diff": abs(hl_mm["p.value"] - hl_run["p.value"]) / hl_mm["p.value"],
                     "status": "ok" if ok else "FAIL"})

        worst_scaled = max(r["abs_diff"] for r in rows if r["check"] == "scaled")
        direct = [r["abs_diff"] for r in rows
                  if r["check"] == "scaled" and r["analysis"] != "hodges_lehmann_r"]
        worst_direct = max(direct) if direct else 0.0
        worst_keep = max(r["rel_diff"] for r in rows if r["check"] == "unchanged")

        out = {
            "schemaVersion": 1,
            "status": "ok" if failures == 0 else "failed",
            "method": "divide marker_mm by 10 in a copy of the cohort, rerun analysis.py and "
                      "crosscheck.R with the same seed, compare with the converted results",
            "principle": "value_cm = value_mm / 10; unit-free quantities must be identical",
            "cohort": {"rows": int(len(df)), "sourceSha256": sha256(DATA),
                       "centimetreCopySha256": sha256(cm_path)},
            "scaledComparisons": sum(1 for r in rows if r["check"] == "scaled"),
            "unchangedComparisons": sum(1 for r in rows if r["check"] == "unchanged"),
            "maxAbsDiffScaled": worst_scaled,
            "maxAbsDiffScaledExcludingHodgesLehmann": worst_direct,
            "maxRelDiffUnchanged": worst_keep,
            "failures": failures,
            "rows": rows,
        }
        (HERE / "unit-change-check.json").write_text(
            json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({k: out[k] for k in ("status", "scaledComparisons",
                                              "unchangedComparisons", "maxAbsDiffScaled",
                                              "maxRelDiffUnchanged", "failures")}, indent=1))
        return 0 if failures == 0 else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
