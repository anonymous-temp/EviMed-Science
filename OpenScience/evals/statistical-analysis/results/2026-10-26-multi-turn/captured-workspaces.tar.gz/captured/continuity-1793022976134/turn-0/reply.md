**B 组 marker_mm 平均比 A 组高 2.96 mm，95% CI 2.32–3.60 mm。**

![B 组与 A 组 marker_mm 分布与差值估计](deliverables/statistical-analysis-report/fig-marker-by-group.png)

**计算方式**：80 例全部纳入（A 40 / B 40），无缺失、无重复患者，每例只有一次基线观测，所以按两个独立样本处理。A 组均值 10.23 mm（SD 1.44），B 组 13.19 mm（SD 1.46），差值标准误 0.324 mm，Welch t = 9.14（df 77.98），p = 5.8 × 10⁻¹⁴；换算成相对水平是 B 比 A 高 28.9%（22.6–35.2%）。

**这个差值有多稳**：把区间换成另外四种算法，结论不变——合并方差 t 2.32–3.60、非参数 bootstrap（2 万次重抽样，固定种子）2.33–3.58、Hodges-Lehmann 位移 2.98（2.36–3.57）、校正年龄的协方差分析 2.96（2.31–3.61）。两套独立实现（Python 与 R）对 Welch 区间的一致程度在 10⁻¹⁵ 量级。效应量 d = 2.04（1.65–2.56），分母是合并 SD 1.448 mm；换一种说法，随机取一名 B 与一名 A，B 更高的概率约 0.92。

**需要注意的两点**：一是两组分布偏离正态（Shapiro-Wilk 两组 p 均 < 0.01，峰度约 −1.45，比正态平坦），但每组 40 例时均值区间靠中心极限定理成立，bootstrap 和秩方法又完全不依赖分布形状，三者吻合，所以这个偏离没有改变结论——不过也不能反过来说数据服从正态。二是年龄不解释差值：两组年龄均值 54.5 与 55.5 岁（差 1.0 岁，95% CI −4.2 到 6.2），年龄与 marker_mm 相关 r = 0.046，校正后差值不变。

**边界**：这是模拟/合成数据，B、A 是观察性分组而不是随机分组，所以 2.96 mm 只能读作"这份数据里两组的水平差"，不能当作效应或因果结论；数据没有给出最小重要差异或参考范围，因此没有判定这个差值是否有临床意义。

**文件**（都在 [statistical-analysis-report](deliverables/statistical-analysis-report/statistical-report.md) 目录）：报告 [statistical-report.md](deliverables/statistical-analysis-report/statistical-report.md)、结果 [analysis-results.json](deliverables/statistical-analysis-report/analysis-results.json)、两张表（[组间汇总](deliverables/statistical-analysis-report/table-group-summary.csv)、[差值估计](deliverables/statistical-analysis-report/table-difference-estimates.csv)）、图、脚本 `run_all.py` / `analysis.py` / `crosscheck.R`。重跑只需 `python3 run_all.py`，会一并写回步骤定义、输入与脚本的 SHA-256、输出哈希和版本状态；`verify_numbers.py` 会把报告里 52 个数值逐个对回结果文件。后续数据更新时，先看报告第 12 节的清单（行数、组标签、单位、缺失、列名变化），命中任一项就重跑这两步。

方法参考：Welch 两样本区间 [1]，bootstrap 百分位区间 [2]。

1. Welch BL. Biometrika 1947;34:28–35. https://doi.org/10.1093/biomet/34.1-2.28
2. Efron B, Tibshirani RJ. An Introduction to the Bootstrap. 1993. https://doi.org/10.1201/9780429246593