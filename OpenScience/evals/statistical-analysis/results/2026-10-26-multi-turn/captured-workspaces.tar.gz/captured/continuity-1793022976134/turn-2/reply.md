两份数据已经合并并重新分析，上一版（n=80）的结果完整保留在原处，可独立重跑。

## 实际纳入了多少人

**101 行 → 100 名患者 → 98 人进入分析（A 组 49、B 组 49）**

| 步骤 | 行数 | 人数 |
|---|---|---|
| `cohort.csv` | 80 | 80（A 40 / B 40） |
| `supplement.csv`（厘米） | 21 | 21（A 11 / B 10） |
| 叠加 | 101 | 101 |
| 去掉完全重复的导出记录 | −1 | −1 |
| 唯一患者 | 100 | 100 |
| marker 缺失、不参与估计 | −2 | −2 |
| **进入分析** | **98** | **98（A 49 / B 49）** |

- **重复：** 只有 1 例 —— `S001`（A 组，36 岁）在 `supplement.csv` 里又出现了一次，三项内容与 `cohort.csv` 中的记录完全一致（1.1782942 cm 正好等于 11.782942 mm），按字典“完全重复即导出重复”只保留一条，该患者只计 1 次。没有“同一患者数值不同”的冲突重复。
- **缺失：** `S083`（A，36 岁）、`S094`（B，47 岁）marker 为空，按完整病例处理——不进任何估计、描述统计与图，但**保留在数据文件和审计表里**，没有插补；缺失机制未知是这一处理的代价。
- **单位：** 补充文件是厘米，先统一到毫米做全部计算，报告仍用厘米（同一轮的换算规则未变）。

## 更新后的结果

B 组比 A 组平均高 **0.304 cm（95% CI 0.246–0.361 cm）**，即 3.04 mm；标准误 0.0291 cm，t = 10.45，df = 95.97，p = 1.6 × 10⁻¹⁷。换成合并方差 t、bootstrap（20000 次，种子不变）、Hodges-Lehmann 位移、校正年龄的 ANCOVA，点估计都在 0.304–0.306 cm，区间基本重合；92.4% 的跨组配对是 B 更高。

## 与上一版（仅 cohort.csv，n=80）比

- **数值都略有变动：** 0.296 → 0.304 cm（+0.0076），区间从 0.232–0.360 收窄到 0.246–0.361（宽度 1.29 → 1.15 mm），标准误降 10%，d 由 2.044 升到 2.111。原因是**样本从 80 人变成 98 人**，不是单位或方法变了。
- **结论方向没变：** 差值为正、区间不含 0；每个 p 值都还在 α = 0.05 的同一侧（组间差、KS、Shapiro 显著；Levene、年龄项不显著），没有任何翻转；39 个长度量仍严格保持 ÷10，28 个无量纲量（t、df、d、g、U、r、R² 等）不随单位变化。
- **上一版保留在** `cohort-only/`：毫米与厘米结果、两张表、R 交叉核对、图、换算回执，加上上一版报告原文 `statistical-report-n80.md`；本轮重跑得到的关键数字与当时一致，两张毫米表、两张厘米表和图逐字节相同。

## 需要留意的局限

数据是模拟记录、组别为观察性分组，0.304 cm 只描述这两份文件里的组间差异，不是效应、不能外推；新增的 20 人可能不是同一人群的随机样本（缺失与重复都出现在新文件里），98 人只代表“这两份文件里可分析的全部记录”；没有 MID 或参考范围，不做“是否重要”的判断；p 极小不等于重要，不显著也不能证明无差异。

文件：[统计报告](<deliverables/statistical-analysis-report/statistical-report.md>)、[图](<deliverables/statistical-analysis-report/fig-marker-by-group.png>)；纳入审计 `derived/inclusion-audit.csv`、合并记录 `derived/reconciliation.json`、上一版与本版逐项对比 `table-stage-comparison.csv`、报告数字核对脚本 `verify_numbers.py`（已通过）。复现：在该目录执行 `python3 run_all.py --stage all`，再跑 `python3 verify_numbers.py`。

参考文献

1. Welch BL. The generalization of "Student's" problem when several different population variances are involved. *Biometrika*. 1947;34(1-2):28–35. https://doi.org/10.1093/biomet/34.1-2.28
2. Shapiro SS, Wilk MB. An analysis of variance test for normality (complete samples). *Biometrika*. 1965;52(3-4):591–611. https://doi.org/10.1093/biomet/52.3-4.591
3. Efron B, Tibshirani RJ. *An Introduction to the Bootstrap*. Chapman & Hall/CRC; 1993. https://doi.org/10.1201/9780429246593
4. Hedges LV. Distribution theory for Glass's estimator of effect size and related estimators. *Journal of Educational Statistics*. 1981;6(2):107–128. https://doi.org/10.3102/10769986006002107
5. Cohen J. *Statistical Power Analysis for the Behavioral Sciences*. 2nd ed. Lawrence Erlbaum; 1988. https://doi.org/10.4324/9780203771587
6. R Core Team. `wilcox.test`: Wilcoxon Rank Sum and Signed Rank Tests (R documentation). https://stat.ethz.ch/R-manual/R-devel/library/stats/html/wilcox.test.html
7. Little RJA, Rubin DB. *Statistical Analysis with Missing Data*. 3rd ed. Wiley; 2019. https://doi.org/10.1002/9781119482260