#!/usr/bin/env python3
"""Check that the numbers printed in statistical-report.md match the executed results.

This version of the report covers the combined data (cohort.csv + supplement.csv,
98 analysable patients); it also quotes the previous version's numbers (cohort.csv
only, 80 patients). Length bindings are checked against the centimetre results, the
previous version's numbers against the preserved cohort-only stage, unit-free
bindings against both the millimetre and the centimetre files, and every number
quoted from the merged or preserved data files is re-read from disk.

Each binding names a value, the number as written in the report, and a tolerance.
The check fails if the number is absent from the report text or differs from the
computed value. It verifies number-to-result correspondence only; it cannot
certify the prose.

    python3 verify_numbers.py            # combined stage in this directory
    python3 verify_numbers.py --dir DIR  # another stage directory
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

parser = argparse.ArgumentParser()
parser.add_argument("--dir", default=str(HERE), help="stage directory holding the results")
args = parser.parse_args()
DIR = Path(args.dir).resolve()
REPORT = DIR / "statistical-report.md"
OLD_DIR = DIR / "cohort-only"

text = REPORT.read_text(encoding="utf-8").replace("\u2212", "-")

mm = json.loads((DIR / "analysis-results.json").read_text(encoding="utf-8"))
cm = json.loads((DIR / "analysis-results-cm.json").read_text(encoding="utf-8"))
rc = json.loads((DIR / "crosscheck-r.json").read_text(encoding="utf-8"))
recon = json.loads((DIR / "derived" / "reconciliation.json").read_text(encoding="utf-8"))
stages = json.loads((DIR / "stage-comparison.json").read_text(encoding="utf-8"))
check = json.loads((DIR / "unit-change-check.json").read_text(encoding="utf-8"))

MM = {a["id"]: a for a in mm["analyses"]}
CM = {a["id"]: a for a in cm["analyses"]}
HL_CM = cm["crosscheckR"]["hodgesLehmann"]

CM_OLD = {a["id"]: a for a in json.loads(
    (OLD_DIR / "analysis-results-cm.json").read_text(encoding="utf-8"))["analyses"]}
HL_OLD = json.loads(
    (OLD_DIR / "crosscheck-r.json").read_text(encoding="utf-8"))["hodgesLehmann"]

# short aliases -> result record ids
SOURCES = {
    "primary": "primary_mean_difference_welch",
    "pooled": "crosscheck_mean_difference_pooled_t",
    "boot": "crosscheck_bootstrap_percentile",
    "mwu": "crosscheck_mann_whitney",
    "d": "effect_size_cohens_d",
    "ancova": "sensitivity_ancova_adjusted_for_age",
    "diag": "diagnostics_distributional",
    "desc": "descriptive_by_group",
}


def get(path: str, unit: str = "cm"):
    """Dotted path into the centimetre results (cm), the millimetre results (mm),
    the R results (hl / hl_old), the cohort flow (flow) or the previous version's
    centimetre results (old), e.g. 'primary.interval.low'."""
    if unit == "hl":
        cur, parts = HL_CM, path.split(".")
    elif unit == "hl_old":
        # the preserved stage recorded millimetres; convert to the report unit
        value = get(path, "hl_old_mm")
        return value / 10 if isinstance(value, (int, float)) else value
    elif unit == "hl_old_mm":
        cur, parts = HL_OLD, path.split(".")
    elif unit == "flow":
        cur, parts = cm["cohortFlow"], path.split(".")
    elif unit == "old":
        head, _, rest = path.partition(".")
        cur = CM_OLD[SOURCES[head]]
        parts = rest.split(".")
    else:
        base = MM if unit == "mm" else CM
        head, _, rest = path.partition(".")
        cur = base[SOURCES[head] if head in SOURCES else head]
        parts = rest.split(".")
    while parts:
        part = parts.pop(0)
        if isinstance(cur, list):
            cur = cur[int(part)]
        elif isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            merged = ".".join([part] + parts)
            if isinstance(cur, dict) and merged in cur:
                return cur[merged]
            raise KeyError(part)
    return cur


# (path, unit, number as printed, tolerance)
BINDINGS = [
    # headline difference, combined data, reported in cm
    ("primary.estimate", "cm", 0.304, 0.0005),
    ("primary.interval.low", "cm", 0.246, 0.0005),
    ("primary.interval.high", "cm", 0.361, 0.0005),
    ("primary.statistics.se", "cm", 0.0291, 0.00005),
    ("primary.statistics.t", "mm", 10.45, 0.005),
    ("primary.statistics.df", "mm", 95.97, 0.005),
    # other methods in cm
    ("pooled.interval.low", "cm", 0.246, 0.0005),
    ("pooled.interval.high", "cm", 0.361, 0.0005),
    ("boot.interval.low", "cm", 0.246, 0.0005),
    ("boot.interval.high", "cm", 0.361, 0.0005),
    ("boot.statistics.bootstrap_se", "cm", 0.0290, 0.00005),
    ("estimate", "hl", 0.306, 0.0005),
    ("conf.low", "hl", 0.253, 0.0005),
    ("conf.high", "hl", 0.356, 0.0005),
    ("mwu.estimate.U_B", "mm", 2218, 0.5),
    # effect size: unit-free, must be identical in both files
    ("d.estimate", "mm", 2.111, 0.0005),
    ("d.interval.low", "mm", 1.740, 0.0005),
    ("d.interval.high", "mm", 2.592, 0.0006),
    ("d.statistics.hedges_g", "mm", 2.095, 0.0006),
    ("d.statistics.pooled_sd", "cm", 0.1438, 0.00005),
    # ancova and age balance
    ("ancova.estimate", "cm", 0.304, 0.0005),
    ("ancova.interval.low", "cm", 0.246, 0.0005),
    ("ancova.interval.high", "cm", 0.362, 0.0005),
    ("ancova.statistics.hc3_interval.low", "cm", 0.245, 0.0005),
    ("ancova.statistics.hc3_interval.high", "cm", 0.362, 0.0005),
    ("ancova.statistics.age_coefficient", "cm", -0.00006, 5e-6),
    ("ancova.statistics.r_squared", "mm", 0.532, 0.0005),
    ("ancova.statistics.age_balance.mean_A", "mm", 53.37, 0.005),
    ("ancova.statistics.age_balance.mean_B", "mm", 53.33, 0.005),
    ("ancova.statistics.age_balance.difference_ci.0", "mm", -4.75, 0.005),
    ("ancova.statistics.age_balance.difference_ci.1", "mm", 4.67, 0.005),
    ("ancova.statistics.age_balance.welch_p", "mm", 0.99, 0.005),
    ("ancova.statistics.age_balance.corr_age_marker", "mm", -0.005, 0.0005),
    # diagnostics: unit-free
    ("diag.estimate.shapiro.A.W", "mm", 0.915, 0.0005),
    ("diag.estimate.shapiro.B.W", "mm", 0.908, 0.0005),
    ("diag.estimate.shapiro.A.p", "mm", 0.0017, 0.00005),
    ("diag.estimate.shapiro.B.p", "mm", 0.0010, 0.00005),
    ("diag.estimate.levene_mean_centered.W", "mm", 0.077, 0.0005),
    ("diag.estimate.levene_mean_centered.p", "mm", 0.78, 0.005),
    ("diag.estimate.ks_two_sample.D", "mm", 0.653, 0.0005),
    # descriptives, centimetre table
    ("desc.estimate.by_group.A.mean", "cm", 1.016, 0.0005),
    ("desc.estimate.by_group.A.sd", "cm", 0.143, 0.0005),
    ("desc.estimate.by_group.A.median", "cm", 1.031, 0.0005),
    ("desc.estimate.by_group.A.q1", "cm", 0.884, 0.0005),
    ("desc.estimate.by_group.A.q3", "cm", 1.144, 0.0005),
    ("desc.estimate.by_group.A.min", "cm", 0.800, 0.0005),
    ("desc.estimate.by_group.A.max", "cm", 1.233, 0.0005),
    ("desc.estimate.by_group.B.mean", "cm", 1.320, 0.0005),
    ("desc.estimate.by_group.B.sd", "cm", 0.145, 0.0005),
    ("desc.estimate.by_group.B.median", "cm", 1.318, 0.0005),
    ("desc.estimate.by_group.B.q1", "cm", 1.189, 0.0005),
    ("desc.estimate.by_group.B.q3", "cm", 1.455, 0.0005),
    ("desc.estimate.by_group.B.min", "cm", 1.101, 0.0005),
    ("desc.estimate.by_group.B.max", "cm", 1.538, 0.0005),
    # group standard deviations in millimetres, quoted in the text
    ("desc.estimate.by_group.A.sd", "mm", 1.425, 0.0005),
    ("desc.estimate.by_group.B.sd", "mm", 1.451, 0.0005),
    # cohort flow of the combined data
    ("rows_in_file", "flow", 101, 0.5),
    ("exact_duplicate_rows", "flow", 1, 0.5),
    ("missing_marker_mm", "flow", 2, 0.5),
    ("analysis_n", "flow", 98, 0.5),
    ("analysis_n_by_group.A", "flow", 49, 0.5),
    ("analysis_n_by_group.B", "flow", 49, 0.5),
    # previous version (cohort.csv only), quoted in the comparison table
    ("primary.estimate", "old", 0.296, 0.0005),
    ("primary.interval.low", "old", 0.232, 0.0005),
    ("primary.interval.high", "old", 0.360, 0.0005),
    ("primary.statistics.t", "old", 9.14, 0.005),
    ("primary.statistics.df", "old", 77.98, 0.005),
    ("boot.interval.low", "old", 0.233, 0.0005),
    ("boot.interval.high", "old", 0.358, 0.0005),
    ("estimate", "hl_old", 0.298, 0.0005),
    ("conf.low", "hl_old", 0.236, 0.0005),
    ("conf.high", "hl_old", 0.357, 0.0005),
    ("d.estimate", "old", 2.044, 0.0005),
    ("d.interval.low", "old", 1.648, 0.0005),
    ("d.interval.high", "old", 2.561, 0.0005),
    ("d.statistics.hedges_g", "old", 2.024, 0.0006),
    ("ancova.estimate", "old", 0.296, 0.0005),
    ("ancova.interval.low", "old", 0.231, 0.0005),
    ("ancova.interval.high", "old", 0.361, 0.0005),
    ("ancova.statistics.hc3_interval.low", "old", 0.229, 0.0005),
    ("ancova.statistics.hc3_interval.high", "old", 0.362, 0.0005),
    ("ancova.statistics.r_squared", "old", 0.517, 0.0005),
    ("ancova.statistics.age_coefficient", "old", 0.00026, 5e-6),
    ("ancova.statistics.age_balance.welch_p", "old", 0.70, 0.005),
    ("ancova.statistics.age_balance.difference_B_minus_A", "old", 1.0, 0.05),
    ("diag.estimate.shapiro.A.W", "old", 0.915, 0.0005),
    ("diag.estimate.shapiro.A.p", "old", 0.0053, 0.00005),
    ("diag.estimate.shapiro.B.p", "old", 0.0041, 0.00005),
    ("diag.estimate.levene_mean_centered.p", "old", 0.80, 0.005),
    ("desc.estimate.by_group.A.mean", "old", 1.023, 0.0005),
    ("desc.estimate.by_group.A.sd", "old", 0.144, 0.0005),
    ("desc.estimate.by_group.B.mean", "old", 1.319, 0.0005),
    ("desc.estimate.by_group.B.sd", "old", 0.146, 0.0005),
]

failures: list[str] = []
for path, unit, reported, tol in BINDINGS:
    try:
        value = float(get(path, unit))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"{path} ({unit}): cannot read value ({exc})")
        continue
    if abs(value - reported) > tol:
        failures.append(f"{path} ({unit}): results={value} but report says {reported} (tol {tol})")
    plain = f"{reported:f}"
    if "." in plain:
        plain = plain.rstrip("0").rstrip(".")
    candidates = {f"{reported:g}", f"{abs(reported):g}", plain, plain.lstrip("-")}
    if not any(c in text for c in candidates if c):
        failures.append(f"{path} ({unit}): value {reported:g} not found in report text")

# the previous version's sample size, quoted in the comparison table
old_flow = json.loads(
    (OLD_DIR / "analysis-results.json").read_text(encoding="utf-8"))["cohortFlow"]
for field, shown in [("analysis_n", 80), ("analysis_n_by_group.A", 40),
                     ("analysis_n_by_group.B", 40)]:
    head, _, group = field.partition(".")
    value = old_flow[head][group] if group else old_flow[head]
    if int(value) != shown:
        failures.append(f"previous stage {field} is {value}, report says {shown}")

# merge audit: the dropped duplicate and the two missing patients must be the ones named
dropped = [d["patientId"] for d in recon["duplicateHandling"]["dropped"]]
excluded = [e["patientId"] for e in recon["missingHandling"]["excluded"]]
if dropped != ["S001"]:
    failures.append(f"deduplicated patients are {dropped}, report names S001")
if sorted(excluded) != ["S083", "S094"]:
    failures.append(f"excluded patients for missing marker are {excluded}, report names S083 and S094")
for pid in dropped + excluded:
    if pid not in text:
        failures.append(f"patient {pid} not found in report text")
if recon["duplicateHandling"]["conflicting"]:
    failures.append("the merge found conflicting repeats, the report says there were none")
for key, shown in [("cohort.csv", 80), ("supplement.csv", 21)]:
    prof = [p for p in recon["profile"] if p["source"] == key][0]
    if prof["rows"] != shown:
        failures.append(f"{key} has {prof['rows']} rows, report says {shown}")

# each length quantity must still be exactly the millimetre value divided by ten
for aid, field in [
    ("primary_mean_difference_welch", "estimate"),
    ("primary_mean_difference_welch", "statistics.se"),
    ("crosscheck_mean_difference_pooled_t", "statistics.pooled_sd"),
    ("crosscheck_bootstrap_percentile", "statistics.bootstrap_se"),
    ("effect_size_cohens_d", "statistics.pooled_sd"),
    ("sensitivity_ancova_adjusted_for_age", "statistics.age_coefficient"),
    ("descriptive_by_group", "estimate.by_group.A.mean"),
    ("descriptive_by_group", "estimate.by_group.B.mean"),
]:
    lo = float(get(f"{aid}.{field}", "mm"))
    hi = float(get(f"{aid}.{field}", "cm"))
    if abs(hi - lo / 10) > 1e-9:
        failures.append(f"{aid}.{field}: cm {hi} is not mm {lo} / 10")

# unit-free quantities must be identical in the two result files
for aid, field in [
    ("primary_mean_difference_welch", "pValue"),
    ("primary_mean_difference_welch", "statistics.t"),
    ("primary_mean_difference_welch", "statistics.df"),
    ("effect_size_cohens_d", "estimate"),
    ("effect_size_cohens_d", "statistics.hedges_g"),
    ("crosscheck_mann_whitney", "estimate.U_B"),
    ("diagnostics_distributional", "estimate.ks_two_sample.D"),
]:
    a_mm = float(get(f"{aid}.{field}", "mm"))
    a_cm = float(get(f"{aid}.{field}", "cm"))
    if abs(a_mm - a_cm) > max(1e-12, 1e-6 * abs(a_mm)):
        failures.append(f"{aid}.{field}: changed with the unit ({a_mm} vs {a_cm})")

# derived quantities used in the report must reproduce from the results
mean_a_cm = float(get("desc.estimate.by_group.A.mean", "cm"))
ratio = float(get("primary.estimate", "cm")) / mean_a_cm * 100
ratio_lo = float(get("primary.interval.low", "cm")) / mean_a_cm * 100
ratio_hi = float(get("primary.interval.high", "cm")) / mean_a_cm * 100
mean_a_old = float(get("desc.estimate.by_group.A.mean", "old"))
ratio_old = float(get("primary.estimate", "old")) / mean_a_old * 100
for label, val, shown in [
    ("relative diff %", ratio, 29.9),
    ("relative CI low %", ratio_lo, 24.2),
    ("relative CI high %", ratio_hi, 35.5),
    ("previous relative diff %", ratio_old, 28.9),
]:
    if abs(val - shown) > 0.05:
        failures.append(f"{label}: computed {val:.1f}, report {shown}")
    if f"{shown:g}" not in text:
        failures.append(f"{label}: {shown} not found in report text")

p_prob = float(get("mwu.estimate.prob_B_greater_than_A_estimate", "mm"))
if abs(p_prob - 0.924) > 0.0006:
    failures.append(f"P(B>A) estimate {p_prob} does not round to 0.924")
if "92.4%" not in text:
    failures.append("P(B>A) 92.4% not found in report text")
if "91.8%" not in text:
    failures.append("previous P(B>A) 91.8% not found in report text")

# p values quoted as powers of ten, with the value they must equal
for path, unit, value, shown in [
    ("primary.pValue", "cm", 1.623e-17, "1.6 × 10⁻¹⁷"),
    ("pooled.pValue", "cm", 1.617e-17, "1.6 × 10⁻¹⁷"),
    ("ancova.pValue", "cm", 2.376e-17, "2.4 × 10⁻¹⁷"),
    ("p.value", "hl", 4.97379915e-13, "5.0 × 10⁻¹³"),
    ("diag.estimate.ks_two_sample.p", "mm", 3.589e-10, "3.6 × 10⁻¹⁰"),
    ("diag.estimate.ks_two_sample.p", "old", 2.806e-08, "2.8 × 10⁻⁸"),
    ("primary.pValue", "old", 5.764e-14, "5.8 × 10⁻¹⁴"),
]:
    got = float(get(path, unit))
    if abs(got - value) > max(1e-18, 0.05 * value):
        failures.append(f"{path} ({unit}): result {got} vs quoted {value}")
    if shown not in text:
        failures.append(f"p-value form {shown} not found in report text")

# interval widths quoted in the report
width_cm = float(get("primary.interval.high", "cm")) - float(get("primary.interval.low", "cm"))
if abs(width_cm - 0.115) > 0.0005:
    failures.append(f"interval width {width_cm:.4f} cm does not round to 0.115")
width_mm = float(get("primary.interval.high", "cm")) - float(get("primary.interval.low", "cm"))
if abs(width_mm * 10 - 1.15) > 0.005:
    failures.append(f"interval width in mm {width_mm * 10:.4f} does not round to 1.15")
old_width = float(get("primary.interval.high", "old")) - float(get("primary.interval.low", "old"))
if abs(old_width * 10 - 1.29) > 0.005:
    failures.append(f"previous interval width in mm {old_width * 10:.4f} does not round to 1.29")
if abs(old_width - width_cm - 0.014) > 0.0005:
    failures.append(f"narrowing {old_width - width_cm:.4f} cm does not round to 0.014")
delta = float(get("primary.estimate", "cm")) - float(get("primary.estimate", "old"))
if abs(delta - 0.0076) > 0.00005:
    failures.append(f"shift {delta:.5f} cm does not round to 0.0076")

# unit-convertibility audit and stage comparison must both pass
if check.get("maxAbsDiffScaledExcludingHodgesLehmann", 1) > 2e-6:
    failures.append("unit-change audit: non-Hodges-Lehmann deviation above 2e-6")
if check.get("maxAbsDiffScaled", 1) > 2e-4:
    failures.append("unit-change audit: deviation above 2e-4")
if "1.9 × 10⁻⁵" not in text:
    failures.append("Hodges-Lehmann conversion slack 1.9 × 10⁻⁵ not in report text")
if "5 × 10⁻⁷" not in text:
    failures.append("non-Hodges-Lehmann conversion deviation 5 × 10⁻⁷ not in report text")
if "1.8 × 10⁻¹⁵" not in text:
    failures.append("cm -> mm conversion deviation 1.8 × 10⁻¹⁵ not in report text")
cm_to_mm = recon["checks"][0]["value"]
if abs(cm_to_mm - 1.776e-15) > 1e-16:
    failures.append(f"cm -> mm conversion deviation {cm_to_mm} does not round to 1.8 × 10⁻¹⁵")
for name, passed in stages["checks"].items():
    if not passed["pass"]:
        failures.append(f"stage comparison check {name} did not pass")
if stages["rowsCompared"] != 67:
    failures.append(f"stage comparison covers {stages['rowsCompared']} rows, report says 67")
if "4 × 10⁻⁹" not in text:
    failures.append("stage comparison unit-consistency deviation 4 × 10⁻⁹ not in report text")
if abs(stages["checks"]["unitConversionConsistent"]["maxAbsDeviation"] - 4e-9) > 1e-10:
    failures.append("stage comparison unit-consistency deviation is not 4 × 10⁻⁹")

print(f"checked {len(BINDINGS)} value bindings + merge, conversion, stage and derived-value checks")
if failures:
    print("FAILED")
    for f in failures:
        print(" -", f)
    sys.exit(1)
print("all report numbers match the executed results")
