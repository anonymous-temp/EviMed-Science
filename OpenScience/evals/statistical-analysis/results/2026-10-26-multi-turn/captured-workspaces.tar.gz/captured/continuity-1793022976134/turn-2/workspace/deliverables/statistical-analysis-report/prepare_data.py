#!/usr/bin/env python3
"""Merge the centimetre supplement into the millimetre cohort, keeping one unit.

Inputs
  data/cohort.csv      patient_id, group, age, marker_mm   (millimetres)
  data/supplement.csv  patient_id, group, age, marker_cm   (centimetres)

Outputs (in --outdir)
  combined-mm.csv       the two files stacked in millimetres, canonical columns
                        patient_id,group,age,marker_mm; every source row present,
                        duplicates and blanks included, so that the analysis step
                        (not this script) applies the exclusion rules and records
                        the achieved sample
  inclusion-audit.csv   one row per source row with the decision that will apply:
                        included / excluded: export duplicate / excluded: missing marker
  reconciliation.json   counts per source file, the unit conversion, the expected
                        flow, the checks run, and input/output hashes

Rules (from data/dictionary.md, unchanged this turn):
  * a subject is one patient_id with one baseline observation;
  * an identical repeat patient is an export duplicate -> one row kept;
  * conflicting repeats need a stated rule -> this script stops if any exist;
  * a blank marker is missing -> excluded from estimates, complete case.

Usage
  python3 prepare_data.py --cohort ../../data/cohort.csv \
      --supplement ../../data/supplement.csv --outdir derived
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
CANONICAL = ["patient_id", "group", "age", "marker_mm"]
GROUPS = ["A", "B"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def profile(name: str, df: pd.DataFrame, unit: str, marker_col: str) -> dict:
    miss = df[marker_col].isna()
    return {
        "source": name,
        "rows": int(len(df)),
        "columns": list(df.columns),
        "markerColumn": marker_col,
        "markerUnit": unit,
        "groupCounts": {g: int((df["group"] == g).sum()) for g in GROUPS},
        "missingMarker": int(miss.sum()),
        "missingPatientIds": df.loc[miss, "patient_id"].tolist(),
        "duplicatePatientIdsWithinFile": int(df["patient_id"].duplicated().sum()),
        "ageMin": float(df["age"].min()),
        "ageMax": float(df["age"].max()),
        "markerRangeInFileUnit": [float(df[marker_col].min()), float(df[marker_col].max())],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cohort", default="../../data/cohort.csv")
    ap.add_argument("--supplement", default="../../data/supplement.csv")
    ap.add_argument("--outdir", default="derived")
    args = ap.parse_args()

    out = (HERE / args.outdir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    cohort_path = (HERE / args.cohort).resolve()
    supp_path = (HERE / args.supplement).resolve()
    for p in (cohort_path, supp_path):
        if not p.exists():
            raise SystemExit(f"input not found: {p}")

    cohort = pd.read_csv(cohort_path)
    supp = pd.read_csv(supp_path)
    if list(cohort.columns) != CANONICAL:
        raise SystemExit(f"cohort.csv columns changed: {list(cohort.columns)}")
    if list(supp.columns) != ["patient_id", "group", "age", "marker_cm"]:
        raise SystemExit(f"supplement.csv columns unexpected: {list(supp.columns)}")

    probe = profile("cohort.csv", cohort, "mm", "marker_mm")
    supp_probe = profile("supplement.csv", supp, "cm", "marker_cm")

    # --- unit harmonisation: the supplement is recorded in centimetres
    # mm = cm * 10; the supplement is the only source recorded in centimetres
    supp_mm = supp.copy()
    supp_mm["marker_mm"] = (supp_mm["marker_cm"] * 10.0).round(10)
    raw_diff = (supp_mm["marker_cm"] * 10.0 - supp_mm["marker_mm"]).abs().max()
    if raw_diff > 1e-9:
        raise SystemExit(f"centimetre-to-millimetre conversion is not exact: {raw_diff}")
    supp_mm = supp_mm.drop(columns=["marker_cm"])
    supp_mm["source"] = "supplement.csv"
    supp_mm["source_row"] = range(2, len(supp_mm) + 2)  # 1-based including header
    cohort_mm = cohort.copy()
    cohort_mm["source"] = "cohort.csv"
    cohort_mm["source_row"] = range(2, len(cohort_mm) + 2)

    stacked = pd.concat([cohort_mm, supp_mm], ignore_index=True)
    overlap = sorted(set(cohort["patient_id"]) & set(supp["patient_id"]))

    # --- duplicate rule applied on the canonical columns only
    key = CANONICAL
    dup_mask = stacked.duplicated(subset=key, keep="first")
    dup_rows = stacked.loc[dup_mask, ["patient_id", "source", "source_row"]].copy()
    first_occurrence = stacked.loc[~dup_mask].set_index("patient_id")["source"]
    duplicate_detail = [
        {
            "patientId": r.patient_id,
            "droppedSource": r.source,
            "keptSource": first_occurrence.get(r.patient_id, None),
            "reason": "identical patient_id, group, age and marker value: export duplicate",
        }
        for r in dup_rows.itertuples()
    ]

    # --- conflicting repeats: same patient_id, different values
    after_dup = stacked.loc[~dup_mask]
    conflict = (
        after_dup.groupby("patient_id")[["group", "age", "marker_mm"]]
        .nunique(dropna=False)
        .max(axis=1)
    )
    conflicting = sorted(conflict[conflict > 1].index.tolist())
    if conflicting:
        raise SystemExit(
            "conflicting repeats for patient_id " + ", ".join(conflicting)
            + ": no subject-level rule was given; stop before estimating"
        )

    # --- missing marker and expected analysis sample
    missing_in_stacked = (~dup_mask) & stacked["marker_mm"].isna()
    analysis = after_dup.loc[~after_dup["marker_mm"].isna()]
    expected_by_group = {g: int((analysis["group"] == g).sum()) for g in GROUPS}

    audit = stacked.copy()
    audit["marker_mm"] = audit["marker_mm"].map(lambda v: "" if pd.isna(v) else f"{v:.6f}")
    audit["included"] = "yes"
    audit.loc[dup_mask, "included"] = "no"
    audit["reason"] = ""
    audit.loc[dup_mask, "reason"] = "export duplicate: identical patient record already present"
    audit.loc[missing_in_stacked, "reason"] = "marker value missing (blank in source file)"
    audit.loc[missing_in_stacked, "included"] = "no"
    audit = audit[["patient_id", "group", "age", "marker_mm", "source", "source_row",
                   "included", "reason"]]
    audit.to_csv(out / "inclusion-audit.csv", index=False, encoding="utf-8")

    combined = stacked[CANONICAL].copy()
    combined.to_csv(out / "combined-mm.csv", index=False, encoding="utf-8")

    checks = [
        {
            "check": "unit conversion cm -> mm",
            "detail": "marker_mm = marker_cm * 10; max |x*10 - round(x*10, 10)|",
            "value": raw_diff,
            "pass": bool(raw_diff <= 1e-9),
        },
        {
            "check": "column mapping",
            "detail": "supplement marker_cm -> marker_mm; patient_id, group, age kept as recorded",
            "value": "ok",
            "pass": True,
        },
        {
            "check": "group codes",
            "detail": "observed codes in both files",
            "value": sorted(set(cohort["group"]) | set(supp["group"])),
            "pass": sorted(set(cohort["group"]) | set(supp["group"])) == GROUPS,
        },
        {
            "check": "conflicting repeats",
            "detail": "same patient_id with different group, age or marker after removing exact duplicates",
            "value": conflicting,
            "pass": len(conflicting) == 0,
        },
        {
            "check": "cross-file patient overlap",
            "detail": "patient_id present in both files",
            "value": overlap,
            "pass": all(
                bool((cohort.loc[cohort.patient_id == pid, CANONICAL[1:]].values
                      == supp_mm.loc[supp_mm.patient_id == pid, CANONICAL[1:]].values).all())
                for pid in overlap
            ),
        },
    ]

    reconciliation = {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "inputs": [
            {"path": cohort_path.name, "sha256": sha256(cohort_path), "unit": "mm", "rows": int(len(cohort))},
            {"path": supp_path.name, "sha256": sha256(supp_path), "unit": "cm", "rows": int(len(supp))},
        ],
        "profile": [probe, supp_probe],
        "unitHarmonisation": {
            "basis": "1 cm = 10 mm",
            "factor": 10.0,
            "appliedTo": "supplement marker_cm only",
            "reportedUnit": "cm",
            "analysisUnit": "mm",
        },
        "rows": {
            "cohort": int(len(cohort)),
            "supplement": int(len(supp)),
            "stacked": int(len(stacked)),
            "exactDuplicateRows": int(dup_mask.sum()),
            "conflictingRepeats": len(conflicting),
            "missingMarkerRows": int(missing_in_stacked.sum()),
            "expectedAnalysisN": int(len(analysis)),
            "expectedAnalysisNByGroup": expected_by_group,
            "expectedSourceCounts": {str(k): int(v) for k, v in
                                     analysis["source"].value_counts().items()},
        },
        "duplicateHandling": {
            "rule": "identical patient_id with identical group, age and marker = export duplicate; "
                    "one row kept (the cohort record when both files carry it)",
            "dropped": duplicate_detail,
            "conflicting": conflicting,
        },
        "missingHandling": {
            "rule": "a blank marker is missing; complete-case analysis, the row stays in the data file",
            "excluded": [
                {"patientId": r.patient_id, "source": r.source, "group": r.group, "age": int(r.age)}
                for r in after_dup.loc[after_dup["marker_mm"].isna()].itertuples()
            ],
        },
        "checks": checks,
        "outputs": [
            {"path": "combined-mm.csv", "sha256": sha256(out / "combined-mm.csv"),
             "rows": int(len(combined))},
            {"path": "inclusion-audit.csv", "sha256": sha256(out / "inclusion-audit.csv"),
             "rows": int(len(audit))},
        ],
        "note": "This script only stacks and harmonises units. Duplicate removal and the complete-case "
                "exclusion are applied by analysis.py, whose cohortFlow records the achieved sample; "
                "the expected counts here must match it.",
    }
    (out / "reconciliation.json").write_text(
        json.dumps(reconciliation, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({
        "status": "ok",
        "stacked": int(len(stacked)),
        "exactDuplicates": int(dup_mask.sum()),
        "missing": int(missing_in_stacked.sum()),
        "expectedAnalysisN": int(len(analysis)),
        "expectedByGroup": expected_by_group,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
