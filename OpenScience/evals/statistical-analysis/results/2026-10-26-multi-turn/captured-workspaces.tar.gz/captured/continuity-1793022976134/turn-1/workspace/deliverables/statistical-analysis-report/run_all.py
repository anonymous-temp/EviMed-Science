#!/usr/bin/env python3
"""One-command reproducible run for the marker group comparison, reported in cm.

Steps (defined in analysis-session.json, written by this script):
  1. estimate          python3 analysis.py      -> analysis-results.json, mm tables
  2. figure_crosscheck Rscript crosscheck.R     -> crosscheck-r.json (mm), figure (cm axis)
  3. report_cm         python3 convert_units.py -> cm results, cm tables, unit-change table
  4. unit_check        python3 verify_unit_change.py
                        -> unit-change-check.json (rerun on data/10, compare)

The analysis itself is done in millimetres, the unit of the stored data. Step 3
only re-expresses already computed results in centimetres (value_cm = value_mm
/ 10), and step 4 proves that this equals a full re-analysis of the data in
centimetres.

Then records what actually ran in analysis-state.json (per-step input, script,
output hashes and versions) and analysis-run.json (execution receipt).

Usage:  python3 run_all.py [--input ../../data/cohort.csv] [--dictionary ../../data/dictionary.md]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def rel(cmd: list[str]) -> str:
    """Command as recorded: host paths trimmed to project-relative form."""
    ws = HERE.parents[1]
    shown = []
    for part in cmd:
        txt = str(part).replace(str(HERE), ".").replace(str(ws) + "/", "")
        if Path(txt).name.startswith("python"):
            txt = "python3"
        shown.append(txt)
    return " ".join(shown)


def scrub(line: str) -> str:
    ws = HERE.parents[1]
    return line.replace(str(HERE), ".").replace(str(ws) + "/", "")


def run(cmd: list[str], cwd: Path) -> dict:
    started = now()
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return {
        "command": rel(cmd),
        "returncode": proc.returncode,
        "startedAt": started,
        "finishedAt": now(),
        "stdoutTail": [scrub(x) for x in proc.stdout.strip().splitlines()[-6:]],
        "stderrTail": [scrub(x) for x in proc.stderr.strip().splitlines()[-6:]],
    }


def hashed(paths: list[Path]) -> list[dict]:
    out = []
    for p in paths:
        if p.exists():
            out.append({"path": p.name, "sha256": sha256(p), "bytes": p.stat().st_size})
        else:
            out.append({"path": p.name, "sha256": None, "bytes": None, "missing": True})
    return out


def build_steps(in_path: Path, dict_path: Path, args) -> list[dict]:
    """Step definitions: command, declared inputs/outputs and the context they depend on."""
    mm_tables = [HERE / "table-group-summary.csv", HERE / "table-difference-estimates.csv"]
    cm_tables = [HERE / "table-group-summary-cm.csv",
                 HERE / "table-difference-estimates-cm.csv",
                 HERE / "table-unit-change.csv"]
    return [
        {
            "id": "estimate",
            "script": "analysis.py",
            "interpreter": "python",
            "cmd": [sys.executable, "analysis.py", "--input", str(in_path), "--dictionary", str(dict_path),
                    "--outdir", ".", "--seed", str(args.seed), "--bootstrap", str(args.bootstrap)],
            "inputs": [in_path, dict_path],
            "outputs": [HERE / "analysis-results.json", *mm_tables],
            "dependsOn": [],
            "context": {
                "unit": "patient_id (one baseline observation per subject)",
                "groupLevels": ["A", "B"],
                "referenceGroup": "A",
                "comparisonGroup": "B",
                "estimand": "mean marker_mm difference, B minus A",
                "outcome": "marker_mm",
                "outcomeUnit": "mm",
                "missing": "complete case (rows without marker_mm excluded; 0 in this delivery)",
                "duplicates": "no duplicate patient_id in this delivery; exact export duplicates would be dropped, "
                "conflicting repeats need a stated rule",
                "primary": "Welch t interval",
                "crossChecks": ["pooled t", "bootstrap percentile", "Mann-Whitney"],
                "sensitivity": "OLS ANCOVA adjusting for age",
                "alpha": 0.05,
                "seed": args.seed,
                "bootstrapResamples": args.bootstrap,
            },
        },
        {
            "id": "figure_crosscheck",
            "script": "crosscheck.R",
            "interpreter": "r",
            "cmd": ["Rscript", "crosscheck.R", str(in_path), ".", "0.1", "cm"],
            "inputs": [in_path, HERE / "table-difference-estimates.csv"],
            "outputs": [HERE / "crosscheck-r.json", HERE / "fig-marker-by-group.png"],
            "dependsOn": ["estimate"],
            "context": {
                "independentImplementation": "R",
                "adds": "Hodges-Lehmann shift with distribution-free interval (R wilcox.test conf.int)",
                "plot": "group distributions with mean and 95% CI; forest of the difference estimates",
                "analysisUnit": "mm (crosscheck-r.json stays in mm)",
                "plotUnit": "cm",
                "plotScale": 0.1,
            },
        },
        {
            "id": "report_cm",
            "script": "convert_units.py",
            "interpreter": "python",
            "cmd": [sys.executable, "convert_units.py", "--factor", "0.1",
                    "--source-unit", "mm", "--target-unit", "cm"],
            "inputs": [HERE / "analysis-results.json", HERE / "crosscheck-r.json", *mm_tables],
            "outputs": [HERE / "analysis-results-cm.json", *cm_tables, HERE / "unit-conversion.json"],
            "dependsOn": ["estimate", "figure_crosscheck"],
            "context": {
                "purpose": "report the same estimates in centimetres",
                "sourceUnit": "mm",
                "reportedUnit": "cm",
                "displayUnit": "cm",
                "factor": 0.1,
                "basis": "1 cm = 10 mm",
                "transform": "reported = source * 0.1 (deterministic rescaling, no re-estimation)",
                "reusedFrom": "estimate + figure_crosscheck (results are reused, not refitted)",
                "scaledQuantities": [
                    "group means, SDs, medians, quartiles, min/max",
                    "mean difference of every method with its interval limits",
                    "standard errors (Welch SE, bootstrap SE), pooled SD",
                    "Hodges-Lehmann shift and its interval",
                    "ANCOVA group coefficient and age coefficient (mm per year -> cm per year)",
                ],
                "invariantQuantities": [
                    "t statistics, degrees of freedom, all p values",
                    "Cohen's d, Hedges g, Hedges J",
                    "Mann-Whitney U and W, P(B > A)",
                    "KS D, Levene and Shapiro-Wilk statistics and their p values",
                    "correlation between age and marker, relative percentage difference",
                    "age in years, sample sizes, cohort flow",
                ],
            },
        },
        {
            "id": "unit_check",
            "script": "verify_unit_change.py",
            "interpreter": "python",
            "cmd": [sys.executable, "verify_unit_change.py"],
            "inputs": [in_path, HERE / "analysis-results.json", HERE / "analysis-results-cm.json"],
            "outputs": [HERE / "unit-change-check.json"],
            "dependsOn": ["report_cm"],
            "context": {
                "check": "divide marker_mm by 10 in a copy of the cohort, rerun analysis.py and crosscheck.R "
                "with the same seed, compare against the converted cm results",
                "passRule": "scaled quantities equal the re-run within result rounding (1e-6); unit-free "
                "quantities equal the millimetre run (1e-9, p values 1e-3)",
                "hodgesLehmannNote": "R locates the asymptotic shift interval by root finding with an absolute "
                "tolerance of about 1.2e-4, so its endpoints are compared at 1.5e-4; the shift estimate itself "
                "is the exact median of Walsh averages",
            },
        },
    ]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../../data/cohort.csv")
    ap.add_argument("--dictionary", default="../../data/dictionary.md")
    ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--bootstrap", type=int, default=20000)
    args = ap.parse_args()

    # paths are resolved from this script's directory, so the default
    # ../../data/... points at the project's data/ folder
    in_path = (HERE / args.input).resolve() if not Path(args.input).is_absolute() else Path(args.input)
    dict_path = (HERE / args.dictionary).resolve() if not Path(args.dictionary).is_absolute() else Path(args.dictionary)
    if not in_path.exists():
        raise SystemExit(f"input not found: {in_path}")

    steps = build_steps(in_path, dict_path, args)
    spec = {
        "schemaVersion": 1,
        "note": "Step definition for this analysis. context holds the semantics each step depends on; "
        "reuse a step only while its script, inputs and context are unchanged.",
        "steps": [{k: v for k, v in s.items() if k not in ("cmd", "inputs", "outputs")} | {
            "inputs": [p.name for p in s["inputs"]],
            "outputs": [p.name for p in s["outputs"]],
        } for s in steps],
    }
    spec_path = HERE / "analysis-session.json"
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    spec["steps"] = steps  # in-memory copy keeps the real paths for hashing

    runs = []
    for s in steps:
        r = run(s["cmd"], HERE)
        runs.append(r)
        if r["returncode"] != 0:
            print(json.dumps(r, ensure_ascii=False, indent=2))
            raise SystemExit(f"step {s['id']} failed")

    results = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
    r_cross = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))
    conv = json.loads((HERE / "unit-conversion.json").read_text(encoding="utf-8"))
    check = json.loads((HERE / "unit-change-check.json").read_text(encoding="utf-8"))

    py_versions = {
        "python": sys.version.split()[0],
        "pandas": results["environment"]["pandas"],
        "numpy": results["environment"]["numpy"],
        "scipy": results["environment"]["scipy"],
        "statsmodels": results["environment"]["statsmodels"],
    }

    def step_versions(s: dict) -> dict:
        if s["interpreter"] == "r":
            return {"r": r_cross.get("rVersion")}
        return dict(py_versions)

    state = {
        "schemaVersion": 1,
        "note": "Observed executions for the steps in analysis-session.json. A step's result may be reused "
        "only while these hashes, the context and the runtime versions match; a changed input hash means "
        "new data and requires re-running every dependent step.",
        "dataVersion": {
            "input": {"path": in_path.name, "sha256": sha256(in_path), "rows": None},
            "dictionary": {"path": dict_path.name, "sha256": sha256(dict_path) if dict_path.exists() else None},
            "analysisN": results["cohortFlow"]["analysis_n"],
            "analysisNByGroup": results["cohortFlow"]["analysis_n_by_group"],
        },
        "reportingUnits": {
            "analysisUnit": "mm",
            "reportedUnit": conv["reportedUnit"],
            "factor": conv["factor"],
            "basis": conv["basis"],
            "conversionScript": "convert_units.py",
            "conversionScriptSha256": sha256(HERE / "convert_units.py"),
            "sourceResults": {"path": "analysis-results.json", "sha256": sha256(HERE / "analysis-results.json")},
            "convertedResults": {"path": "analysis-results-cm.json",
                                 "sha256": sha256(HERE / "analysis-results-cm.json")},
            "changedQuantities": conv["scaled"],
            "unchangedQuantities": conv["unchanged"],
            "equivalenceCheck": {
                "script": "verify_unit_change.py",
                "scriptSha256": sha256(HERE / "verify_unit_change.py"),
                "result": check["status"],
                "scaledComparisons": check["scaledComparisons"],
                "unchangedComparisons": check["unchangedComparisons"],
                "failures": check["failures"],
            },
        },
        "executions": [],
    }
    for s, r in zip(steps, runs):
        state["executions"].append({
            "step": s["id"],
            "script": s["script"],
            "scriptPath": s["script"],
            "scriptSha256": sha256(HERE / s["script"]),
            "command": r["command"],
            "startedAt": r["startedAt"],
            "finishedAt": r["finishedAt"],
            "exitCode": r["returncode"],
            "inputs": hashed(s["inputs"]),
            "outputs": hashed(s["outputs"]),
            "spec": "analysis-session.json",
            "specSha256": sha256(spec_path),
            "context": s["context"],
            "environment": step_versions(s),
            "versions": step_versions(s),
            "resultsWrite": {"path": s["outputs"][0].name, "sha256": sha256(s["outputs"][0])},
            "returncode": r["returncode"],
            "status": "ok",
        })
    state_path = HERE / "analysis-state.json"
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    all_outputs = [
        HERE / "analysis-results.json",
        HERE / "table-group-summary.csv",
        HERE / "table-difference-estimates.csv",
        HERE / "crosscheck-r.json",
        HERE / "fig-marker-by-group.png",
        HERE / "analysis-results-cm.json",
        HERE / "table-group-summary-cm.csv",
        HERE / "table-difference-estimates-cm.csv",
        HERE / "table-unit-change.csv",
        HERE / "unit-conversion.json",
        HERE / "unit-change-check.json",
        spec_path,
        HERE / "statistical-report.md",
    ]
    receipt = {
        "schemaVersion": 1,
        "runId": hashlib.sha256((runs[0]["startedAt"] + str(args.seed) + str(in_path)).encode()).hexdigest()[:16],
        "startedAt": runs[0]["startedAt"],
        "finishedAt": runs[-1]["finishedAt"],
        "command": " ".join(["python3", "run_all.py", *sys.argv[1:]]),
        "platform": platform.platform(),
        "executions": [
            {
                "id": s["id"],
                "scriptPath": s["script"],
                "scriptSha256": sha256(HERE / s["script"]),
                "command": r["command"],
                "startedAt": r["startedAt"],
                "finishedAt": r["finishedAt"],
                "durationSeconds": round(
                    (datetime.fromisoformat(r["finishedAt"])
                     - datetime.fromisoformat(r["startedAt"])).total_seconds(), 2),
                "exitCode": r["returncode"],
                "status": "ok" if r["returncode"] == 0 else "failed",
                "inputs": hashed(s["inputs"]),
                "outputs": hashed(s["outputs"]),
                "resultsWritten": (s["outputs"][0].exists() and s["outputs"][0].stat().st_size > 0),
                "versions": step_versions(s),
            }
            for s, r in zip(steps, runs)
        ],
        "steps": runs,
        "inputs": hashed([in_path, dict_path]),
        "outputs": hashed(all_outputs),
        "environment": {**py_versions, "r": r_cross.get("rVersion")},
        "status": "ok" if all(r["returncode"] == 0 for r in runs) else "failed",
        "note": "Written by run_all.py from real hashes of what executed. The optional upstream helper "
        "receipt is not installed in this environment; this record replaces it.",
    }
    (HERE / "analysis-run.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({"status": receipt["status"], "runId": receipt["runId"],
                      "reportedUnit": conv["reportedUnit"],
                      "unitCheck": check["status"],
                      "steps": [{"id": s["id"], "command": r["command"], "returncode": r["returncode"]}
                                for s, r in zip(steps, runs)]},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
