#!/usr/bin/env python3
"""One-command reproducible run: previous (cohort only) and combined analysis.

Two stages are run in order, each estimating the same estimand (mean marker
difference, group B minus group A, independent unit patient_id) and each keeping
its own results, provenance and figure:

  stage "cohort"   -> cohort-only/   data/cohort.csv alone  (the previous delivery)
    prepare?  no
    estimate          analysis.py          -> analysis-results.json, mm tables
    figure_crosscheck crosscheck.R         -> crosscheck-r.json (mm), figure (cm axis)
    report_cm         convert_units.py     -> cm results and cm tables
    unit_check        verify_unit_change.py-> unit-change-check.json
  stage "combined" -> ./             data/cohort.csv + data/supplement.csv
    prepare           prepare_data.py      -> derived/combined-mm.csv, reconciliation.json
    estimate / figure_crosscheck / report_cm / unit_check   (same scripts, same settings)
    compare_stages    compare_stages.py    -> stage-comparison.json, table-stage-comparison.csv

The analysis is always done in millimetres, the unit of the stored data; the cm
layer only re-expresses executed results (value_cm = value_mm / 10) and the unit
check proves that this equals a full re-analysis of the data in centimetres.

Writes the step definition and the observed executions beside each stage
(cohort-only/cohort-session.json, cohort-state.json, cohort-receipt.json;
analysis-session.json, analysis-state.json, analysis-run.json at the top level).

Usage:  python3 run_all.py [--seed 20261026] [--bootstrap 20000] [--stage all|cohort|combined]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
DICT_REL = "../../data/dictionary.md"
COHORT_REL = "../../data/cohort.csv"
SUPP_REL = "../../data/supplement.csv"

STAGES = [
    {
        "id": "cohort",
        "dir": "cohort-only",
        "input": COHORT_REL,
        "label": "data/cohort.csv alone (previous delivery, reproducible)",
        "files": {"spec": "cohort-session.json", "state": "cohort-state.json",
                  "receipt": "cohort-receipt.json"},
        "prepare": False,
        "compare": False,
    },
    {
        "id": "combined",
        "dir": ".",
        "input": "derived/combined-mm.csv",
        "label": "data/cohort.csv + data/supplement.csv (this delivery)",
        "files": {"spec": "analysis-session.json", "state": "analysis-state.json",
                  "receipt": "analysis-run.json"},
        "prepare": True,
        "compare": True,
    },
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def rel(cmd: list[str]) -> str:
    ws = HERE.parents[1]
    shown = []
    for part in cmd:
        txt = str(part).replace(str(HERE), ".").replace(str(ws) + "/", "")
        if Path(txt).name.startswith("python"):
            txt = "python3"
        shown.append(txt)
    return " ".join(shown)


def scrub(line: str) -> str:
    ws = HERE.parents[1]
    return line.replace(str(HERE), ".").replace(str(ws) + "/", "")


def run(cmd: list[str], cwd: Path) -> dict:
    started = now()
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return {
        "command": rel(cmd),
        "returncode": proc.returncode,
        "startedAt": started,
        "finishedAt": now(),
        "stdoutTail": [scrub(x) for x in proc.stdout.strip().splitlines()[-6:]],
        "stderrTail": [scrub(x) for x in proc.stderr.strip().splitlines()[-6:]],
    }


def hashed(paths: list[Path]) -> list[dict]:
    out = []
    for p in paths:
        if p.exists():
            out.append({"path": p.name, "sha256": sha256(p), "bytes": p.stat().st_size})
        else:
            out.append({"path": p.name, "sha256": None, "bytes": None, "missing": True})
    return out


def stage_steps(cfg: dict, args) -> list[dict]:
    """Steps of one stage: command, declared inputs/outputs, context."""
    out_rel = cfg["dir"]
    out = (HERE / out_rel).resolve()
    in_rel = cfg["input"]
    in_abs = (HERE / in_rel).resolve()
    dict_abs = (HERE / DICT_REL).resolve()
    steps: list[dict] = []

    if cfg["prepare"]:
        steps.append({
            "id": "prepare",
            "script": "prepare_data.py",
            "interpreter": "python",
            "cmd": [sys.executable, "prepare_data.py", "--cohort", COHORT_REL,
                    "--supplement", SUPP_REL, "--outdir", "derived"],
            "inputs": [(HERE / COHORT_REL).resolve(), (HERE / SUPP_REL).resolve()],
            "outputs": [(HERE / "derived") / "combined-mm.csv",
                        (HERE / "derived") / "reconciliation.json",
                        (HERE / "derived") / "inclusion-audit.csv"],
            "dependsOn": [],
            "context": {
                "sources": ["data/cohort.csv (mm)", "data/supplement.csv (cm)"],
                "unitHarmonisation": "marker_mm = marker_cm * 10; analysis stays in mm",
                "duplicateRule": "identical patient_id with identical group, age and marker = export "
                "duplicate, one row kept (dictionary rule)",
                "conflictingRepeats": "stop before estimating; none present",
                "missingRule": "blank marker = missing; complete case applied by analysis.py",
                "writes": "canonical patient_id,group,age,marker_mm rows plus an inclusion audit",
            },
        })

    steps += [
        {
            "id": "estimate",
            "script": "analysis.py",
            "interpreter": "python",
            "cmd": [sys.executable, "analysis.py", "--input", in_rel, "--dictionary", DICT_REL,
                    "--outdir", out_rel, "--seed", str(args.seed), "--bootstrap", str(args.bootstrap)],
            "inputs": [in_abs, dict_abs],
            "outputs": [out / "analysis-results.json", out / "analysis-dataset.csv",
                        out / "table-group-summary.csv", out / "table-difference-estimates.csv"],
            "dependsOn": ["prepare"] if cfg["prepare"] else [],
            "context": {
                "unit": "patient_id (one baseline observation per subject)",
                "groupLevels": ["A", "B"],
                "referenceGroup": "A",
                "comparisonGroup": "B",
                "estimand": "mean marker_mm difference, B minus A",
                "outcome": "marker_mm",
                "outcomeUnit": "mm",
                "missing": "complete case (rows without marker_mm excluded; counted in cohortFlow)",
                "duplicates": "exact duplicate rows removed keeping the first occurrence; "
                "conflicting repeats need a stated rule",
                "primary": "Welch t interval",
                "crossChecks": ["pooled t", "bootstrap percentile", "Mann-Whitney"],
                "sensitivity": "OLS ANCOVA adjusting for age",
                "alpha": 0.05,
                "seed": args.seed,
                "bootstrapResamples": args.bootstrap,
            },
        },
        {
            "id": "figure_crosscheck",
            "script": "crosscheck.R",
            "interpreter": "r",
            # reads the analysis-ready rows written by estimate, so the R side sees
            # exactly the observations the estimates used (no second exclusion rule)
            "cmd": ["Rscript", "crosscheck.R", f"{out_rel.rstrip('/')}/analysis-dataset.csv"
                    if out_rel != "." else "analysis-dataset.csv", out_rel, "0.1", "cm"],
            "inputs": [out / "analysis-dataset.csv", out / "table-difference-estimates.csv"],
            "outputs": [out / "crosscheck-r.json", out / "fig-marker-by-group.png"],
            "dependsOn": ["estimate"],
            "context": {
                "independentImplementation": "R",
                "adds": "Hodges-Lehmann shift with distribution-free interval (R wilcox.test conf.int)",
                "plot": "group distributions with mean and 95% CI; forest of the difference estimates",
                "analysisUnit": "mm (crosscheck-r.json stays in mm)",
                "plotUnit": "cm",
                "plotScale": 0.1,
            },
        },
        {
            "id": "report_cm",
            "script": "convert_units.py",
            "interpreter": "python",
            "cmd": [sys.executable, "convert_units.py", "--outdir", out_rel, "--factor", "0.1",
                    "--source-unit", "mm", "--target-unit", "cm"],
            "inputs": [out / "analysis-results.json", out / "crosscheck-r.json"],
            "outputs": [out / "analysis-results-cm.json", out / "table-group-summary-cm.csv",
                        out / "table-difference-estimates-cm.csv", out / "table-unit-change.csv",
                        out / "unit-conversion.json"],
            "dependsOn": ["estimate", "figure_crosscheck"],
            "context": {
                "purpose": "report the same estimates in centimetres",
                "sourceUnit": "mm",
                "reportedUnit": "cm",
                "factor": 0.1,
                "basis": "1 cm = 10 mm",
                "transform": "reported = source * 0.1 (deterministic rescaling, no re-estimation)",
                "scaledQuantities": [
                    "group means, SDs, medians, quartiles, min/max",
                    "mean difference of every method with its interval limits",
                    "standard errors and pooled SD, Hodges-Lehmann shift and interval",
                    "ANCOVA group coefficient and age coefficient (per year)",
                ],
                "invariantQuantities": [
                    "t statistics, degrees of freedom, all p values",
                    "Cohen's d, Hedges g, Hedges J",
                    "Mann-Whitney U and W, P(B > A)",
                    "KS D, Levene and Shapiro-Wilk statistics and p values",
                    "correlation between age and marker, relative percentage difference",
                    "age in years, sample sizes, cohort flow",
                ],
            },
        },
        {
            "id": "unit_check",
            "script": "verify_unit_change.py",
            "interpreter": "python",
            "cmd": [sys.executable, "verify_unit_change.py", "--dir", out_rel, "--input", in_rel],
            "inputs": [in_abs, out / "analysis-results.json", out / "analysis-results-cm.json"],
            "outputs": [out / "unit-change-check.json"],
            "dependsOn": ["report_cm"],
            "context": {
                "check": "divide marker_mm by 10 in a copy of the stage input, rerun analysis.py and "
                "crosscheck.R with the same seed, compare against the converted cm results",
                "passRule": "scaled quantities equal the re-run within result rounding (1e-6); unit-free "
                "quantities equal the millimetre run (1e-9, p values 1e-3)",
                                "hodgesLehmannNote": "R finds the shift and its interval by root finding "
                "with an absolute tolerance of about 1.2e-4 in the units of the data it "
                "read, so all three Hodges-Lehmann numbers are compared at 1.5e-4",
            },
        },
    ]

    if cfg["compare"]:
        cohort_dir = (HERE / "cohort-only").resolve()
        steps.append({
            "id": "compare_stages",
            "script": "compare_stages.py",
            "interpreter": "python",
            "cmd": [sys.executable, "compare_stages.py", "--old", "cohort-only", "--new", out_rel],
            "inputs": [cohort_dir / "analysis-results.json", cohort_dir / "analysis-results-cm.json",
                       cohort_dir / "crosscheck-r.json", out / "analysis-results.json",
                       out / "analysis-results-cm.json", out / "crosscheck-r.json"],
            "outputs": [out / "stage-comparison.json", out / "table-stage-comparison.csv"],
            "dependsOn": ["estimate", "report_cm"],
            "context": {
                "purpose": "compare the previous cohort-only results with the combined results",
                "rule": "no statistic is recomputed; both stages use the same estimand, exclusion rules "
                "and methods, so only the input rows differ",
                "checks": "p values keep their side of alpha, estimates keep their sign, cm = mm / 10",
            },
        })
    return steps


def run_stage(cfg: dict, args, parent: dict | None) -> dict:
    out_rel = cfg["dir"]
    out = (HERE / out_rel).resolve()
    out.mkdir(parents=True, exist_ok=True)
    steps = stage_steps(cfg, args)

    spec_path = out / cfg["files"]["spec"]
    state_path = out / cfg["files"]["state"]
    receipt_path = out / cfg["files"]["receipt"]

    spec = {
        "schemaVersion": 1,
        "stage": cfg["id"],
        "label": cfg["label"],
        "note": "Step definition. context holds the semantics each step depends on; reuse a step only "
                "while its script, inputs and context are unchanged.",
        "steps": [{k: v for k, v in s.items() if k not in ("cmd", "inputs", "outputs")} | {
            "inputs": [p.name for p in s["inputs"]],
            "outputs": [p.name for p in s["outputs"]],
        } for s in steps],
    }
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")

    runs = []
    for s in steps:
        r = run(s["cmd"], HERE)
        runs.append(r)
        if r["returncode"] != 0:
            print(json.dumps(r, ensure_ascii=False, indent=2))
            raise SystemExit(f"stage {cfg['id']}: step {s['id']} failed")

    results = json.loads((out / "analysis-results.json").read_text(encoding="utf-8"))
    r_cross = json.loads((out / "crosscheck-r.json").read_text(encoding="utf-8"))
    conv = json.loads((out / "unit-conversion.json").read_text(encoding="utf-8"))
    check = json.loads((out / "unit-change-check.json").read_text(encoding="utf-8"))

    py_versions = {
        "python": sys.version.split()[0],
        "pandas": results["environment"]["pandas"],
        "numpy": results["environment"]["numpy"],
        "scipy": results["environment"]["scipy"],
        "statsmodels": results["environment"]["statsmodels"],
    }

    def step_versions(s: dict) -> dict:
        if s["interpreter"] == "r":
            return {"r": r_cross.get("rVersion")}
        return dict(py_versions)

    state = {
        "schemaVersion": 1,
        "stage": cfg["id"],
        "note": "Observed executions for the steps in this stage's session file. A step's result may be "
                "reused only while these hashes, the context and the runtime versions match; a changed "
                "input hash means new data and requires re-running every dependent step.",
        "dataVersion": {
            "input": {"path": Path(cfg["input"]).name, "sha256": sha256((HERE / cfg["input"]).resolve())},
            "dictionary": {"path": Path(DICT_REL).name, "sha256": sha256((HERE / DICT_REL).resolve())},
            "analysisN": results["cohortFlow"]["analysis_n"],
            "analysisNByGroup": results["cohortFlow"]["analysis_n_by_group"],
        },
        "reportingUnits": {
            "analysisUnit": "mm",
            "reportedUnit": conv["reportedUnit"],
            "factor": conv["factor"],
            "basis": conv["basis"],
            "conversionScript": "convert_units.py",
            "conversionScriptSha256": sha256(HERE / "convert_units.py"),
            "sourceResults": {"path": "analysis-results.json",
                              "sha256": sha256(out / "analysis-results.json")},
            "convertedResults": {"path": "analysis-results-cm.json",
                                 "sha256": sha256(out / "analysis-results-cm.json")},
            "changedQuantities": conv["scaled"],
            "unchangedQuantities": conv["unchanged"],
            "equivalenceCheck": {
                "script": "verify_unit_change.py",
                "scriptSha256": sha256(HERE / "verify_unit_change.py"),
                "result": check["status"],
                "scaledComparisons": check["scaledComparisons"],
                "unchangedComparisons": check["unchangedComparisons"],
                "failures": check["failures"],
            },
        },
        "executions": [],
    }
    for s, r in zip(steps, runs):
        state["executions"].append({
            "step": s["id"],
            "script": s["script"],
            "scriptSha256": sha256(HERE / s["script"]),
            "command": r["command"],
            "startedAt": r["startedAt"],
            "finishedAt": r["finishedAt"],
            "exitCode": r["returncode"],
            "inputs": hashed(s["inputs"]),
            "outputs": hashed(s["outputs"]),
            "spec": spec_path.name,
            "specSha256": sha256(spec_path),
            "context": s["context"],
            "environment": step_versions(s),
            "versions": step_versions(s),
            "resultsWrite": {"path": s["outputs"][0].name, "sha256": sha256(s["outputs"][0])},
            "status": "ok",
        })
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    all_outputs = [p for s in steps for p in s["outputs"]]
    if cfg["compare"]:
        all_outputs.append(HERE / "statistical-report.md")

    receipt = {
        "schemaVersion": 1,
        "stage": cfg["id"],
        "label": cfg["label"],
        "runId": hashlib.sha256((runs[0]["startedAt"] + str(args.seed) + cfg["input"]).encode()).hexdigest()[:16],
        "startedAt": runs[0]["startedAt"],
        "finishedAt": runs[-1]["finishedAt"],
        "command": " ".join(["python3", "run_all.py", *sys.argv[1:]]),
        "parent": parent,
        "workdir": ".",
        "interpreter": {"python": sys.executable.split("/")[-1] + " " + sys.version.split()[0],
                        "r": r_cross.get("rVersion")},
        "environment": py_versions,
        "seed": args.seed,
        "bootstrapResamples": args.bootstrap,
        "data": {
            "input": {"path": cfg["input"], "sha256": sha256((HERE / cfg["input"]).resolve())},
            "dictionary": {"path": DICT_REL, "sha256": sha256((HERE / DICT_REL).resolve())},
            "analysisN": results["cohortFlow"]["analysis_n"],
            "analysisNByGroup": results["cohortFlow"]["analysis_n_by_group"],
            "cohortFlow": results["cohortFlow"],
        },
        "spec": {"path": spec_path.name, "sha256": sha256(spec_path)},
        "state": {"path": state_path.name, "sha256": sha256(state_path)},
        "steps": [{**{k: v for k, v in s.items() if k not in ("cmd", "inputs", "outputs")},
                   "inputs": [p.name for p in s["inputs"]],
                   "outputs": [p.name for p in s["outputs"]]} for s in steps],
        "executions": state["executions"],
        "outputs": hashed(all_outputs),
        "reportingUnits": state["reportingUnits"],
        "status": "ok" if all(r["returncode"] == 0 for r in runs) else "failed",
        "note": "Written by run_all.py from real hashes of what executed. The optional upstream helper "
                "receipt is not installed in this environment; this record replaces it.",
    }
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "stage": cfg["id"],
        "dir": out_rel,
        "status": receipt["status"],
        "runId": receipt["runId"],
        "n": results["cohortFlow"]["analysis_n"],
        "reportedUnit": conv["reportedUnit"],
        "unitCheck": check["status"],
        "receipt": "cohort-only/" + receipt_path.name if out_rel == "cohort-only" else receipt_path.name,
        "steps": [{"id": s["id"], "returncode": r["returncode"]} for s, r in zip(steps, runs)],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--bootstrap", type=int, default=20000)
    ap.add_argument("--stage", default="all", choices=["all", "cohort", "combined"])
    args = ap.parse_args()

    chosen = [s for s in STAGES if args.stage in ("all", s["id"])]
    if args.stage == "combined" and not (HERE / "cohort-only" / "analysis-results.json").exists():
        raise SystemExit("cohort stage results missing: run --stage cohort first")

    summaries, parent = [], None
    for cfg in chosen:
        summary = run_stage(cfg, args, parent)
        summaries.append(summary)
        parent = {
            "stage": cfg["id"],
            "receipt": f"{cfg['dir']}/{cfg['files']['receipt']}" if cfg["dir"] != "."
            else cfg["files"]["receipt"],
            "runId": summary["runId"],
        }

    print(json.dumps({"status": "ok" if all(s["status"] == "ok" for s in summaries) else "failed",
                      "stages": summaries}, ensure_ascii=False, indent=2))
    return 0 if all(s["status"] == "ok" and s["unitCheck"] == "ok" for s in summaries) else 1


if __name__ == "__main__":
    raise SystemExit(main())
