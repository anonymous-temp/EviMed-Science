#!/usr/bin/env python3
"""Check that the numbers printed in statistical-report.md match the executed results.

The report is written in centimetres, so length bindings are checked against
analysis-results-cm.json (the converted results); unit-free bindings are checked
against analysis-results.json (the millimetre analysis) and must be identical in
both files. The millimetre column of the unit-change table is checked against
analysis-results.json, and the centimetre column against analysis-results-cm.json.

Each binding names a value, the number as written in the report, and a tolerance.
The check fails if the number is absent from the report text or differs from the
computed value. It verifies number-to-result correspondence only; it cannot
certify the prose.

    python3 verify_numbers.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPORT = HERE / "statistical-report.md"

mm = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
cm = json.loads((HERE / "analysis-results-cm.json").read_text(encoding="utf-8"))
rc = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))
text = REPORT.read_text(encoding="utf-8")

MM = {a["id"]: a for a in mm["analyses"]}
CM = {a["id"]: a for a in cm["analyses"]}
HL_CM = cm["crosscheckR"]["hodgesLehmann"]

# short aliases -> (centimetre record, millimetre record)
SOURCES = {
    "primary": ("primary_mean_difference_welch",),
    "pooled": ("crosscheck_mean_difference_pooled_t",),
    "boot": ("crosscheck_bootstrap_percentile",),
    "mwu": ("crosscheck_mann_whitney",),
    "d": ("effect_size_cohens_d",),
    "ancova": ("sensitivity_ancova_adjusted_for_age",),
    "diag": ("diagnostics_distributional",),
    "desc": ("descriptive_by_group",),
}


def get(path: str, unit: str = "cm"):
    """Dotted path into the converted results (cm), the millimetre results, the R
    results (hl) or the cohort flow, e.g. 'primary.interval.low'."""
    if unit == "r":
        cur = {"hl": HL_CM}
        parts = path.split(".")
    elif unit == "flow":
        cur = cm["cohortFlow"]
        parts = path.split(".")
    else:
        base = MM if unit == "mm" else CM
        head, _, rest = path.partition(".")
        cur = base[SOURCES[head][0] if head in SOURCES else head]
        parts = rest.split(".")
    while parts:
        part = parts.pop(0)
        if isinstance(cur, list):
            cur = cur[int(part)]
        elif isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            merged = ".".join([part] + parts)
            if isinstance(cur, dict) and merged in cur:
                return cur[merged]
            raise KeyError(part)
    return cur


# (path, unit, number as printed, tolerance)
BINDINGS = [
    # headline difference reported in cm
    ("primary.estimate", "cm", 0.296, 0.0005),
    ("primary.interval.low", "cm", 0.232, 0.0005),
    ("primary.interval.high", "cm", 0.360, 0.0005),
    ("primary.statistics.se", "cm", 0.032, 0.0005),
    ("primary.statistics.t", "mm", 9.14, 0.005),
    ("primary.statistics.df", "mm", 77.98, 0.005),
    # other methods in cm
    ("pooled.interval.low", "cm", 0.232, 0.0005),
    ("pooled.interval.high", "cm", 0.360, 0.0005),
    ("boot.interval.low", "cm", 0.233, 0.0005),
    ("boot.interval.high", "cm", 0.358, 0.0005),
    ("boot.statistics.bootstrap_se", "cm", 0.032, 0.0005),
    ("hl.estimate", "r", 0.298, 0.0005),
    ("hl.conf.low", "r", 0.236, 0.0005),
    ("hl.conf.high", "r", 0.357, 0.0005),
    ("mwu.estimate.U_B", "mm", 1468, 0.5),
    # effect size: unit-free, must be identical in both files
    ("d.estimate", "mm", 2.044, 0.0005),
    ("d.interval.low", "mm", 1.648, 0.0005),
    ("d.interval.high", "mm", 2.561, 0.0005),
    ("d.statistics.hedges_g", "mm", 2.024, 0.0005),
    ("d.statistics.pooled_sd", "cm", 0.145, 0.0005),
    # ancova and age balance
    ("ancova.estimate", "cm", 0.296, 0.0005),
    ("ancova.interval.low", "cm", 0.231, 0.0005),
    ("ancova.interval.high", "cm", 0.361, 0.0005),
    ("ancova.statistics.hc3_interval.low", "cm", 0.229, 0.0005),
    ("ancova.statistics.hc3_interval.high", "cm", 0.362, 0.0005),
    ("ancova.statistics.age_coefficient", "cm", 0.00026, 5e-6),
    ("ancova.statistics.r_squared", "mm", 0.517, 0.0005),
    ("ancova.statistics.age_balance.mean_A", "mm", 54.5, 0.05),
    ("ancova.statistics.age_balance.mean_B", "mm", 55.5, 0.05),
    ("ancova.statistics.age_balance.difference_ci.0", "mm", -4.20, 0.005),
    ("ancova.statistics.age_balance.difference_ci.1", "mm", 6.20, 0.005),
    ("ancova.statistics.age_balance.welch_p", "mm", 0.70, 0.005),
    ("ancova.statistics.age_balance.corr_age_marker", "mm", 0.0456, 0.00005),
    # diagnostics: unit-free
    ("diag.estimate.shapiro.A.W", "mm", 0.915, 0.0005),
    ("diag.estimate.shapiro.B.W", "mm", 0.911, 0.0005),
    ("diag.estimate.levene_mean_centered.W", "mm", 0.063, 0.0005),
    ("diag.estimate.levene_mean_centered.p", "mm", 0.80, 0.005),
    ("diag.estimate.ks_two_sample.D", "mm", 0.65, 0.005),
    # descriptives, centimetre table
    ("desc.estimate.by_group.A.mean", "cm", 1.023, 0.0005),
    ("desc.estimate.by_group.A.sd", "cm", 0.144, 0.0005),
    ("desc.estimate.by_group.A.median", "cm", 1.051, 0.0005),
    ("desc.estimate.by_group.A.q1", "cm", 0.894, 0.0005),
    ("desc.estimate.by_group.A.q3", "cm", 1.155, 0.0005),
    ("desc.estimate.by_group.A.min", "cm", 0.800, 0.0005),
    ("desc.estimate.by_group.A.max", "cm", 1.233, 0.0005),
    ("desc.estimate.by_group.B.mean", "cm", 1.319, 0.0005),
    ("desc.estimate.by_group.B.sd", "cm", 0.146, 0.0005),
    ("desc.estimate.by_group.B.median", "cm", 1.311, 0.0005),
    ("desc.estimate.by_group.B.q1", "cm", 1.186, 0.0005),
    ("desc.estimate.by_group.B.q3", "cm", 1.450, 0.0005),
    ("desc.estimate.by_group.B.min", "cm", 1.101, 0.0005),
    ("desc.estimate.by_group.B.max", "cm", 1.538, 0.0005),
    # same groups in millimetres (unit-change table)
    ("desc.estimate.by_group.A.mean", "mm", 10.233, 0.0005),
    ("desc.estimate.by_group.A.sd", "mm", 1.437, 0.0005),
    ("desc.estimate.by_group.A.median", "mm", 10.515, 0.0005),
    ("desc.estimate.by_group.A.q1", "mm", 8.938, 0.0005),
    ("desc.estimate.by_group.A.q3", "mm", 11.549, 0.0005),
    ("desc.estimate.by_group.A.min", "mm", 8.000, 0.0005),
    ("desc.estimate.by_group.A.max", "mm", 12.328, 0.0005),
    ("desc.estimate.by_group.B.mean", "mm", 13.193, 0.0005),
    ("desc.estimate.by_group.B.sd", "mm", 1.459, 0.0005),
    ("desc.estimate.by_group.B.median", "mm", 13.115, 0.0005),
    ("desc.estimate.by_group.B.q1", "mm", 11.864, 0.0005),
    ("desc.estimate.by_group.B.q3", "mm", 14.505, 0.0005),
    ("desc.estimate.by_group.B.min", "mm", 11.012, 0.0005),
    ("desc.estimate.by_group.B.max", "mm", 15.381, 0.0005),
    # flow
    ("analysis_n", "flow", 80, 0.5),
    ("analysis_n_by_group.A", "flow", 40, 0.5),
    ("analysis_n_by_group.B", "flow", 40, 0.5),
]

failures: list[str] = []
for path, unit, reported, tol in BINDINGS:
    try:
        value = float(get(path, unit))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"{path} ({unit}): cannot read value ({exc})")
        continue
    if abs(value - reported) > tol:
        failures.append(f"{path} ({unit}): results={value} but report says {reported} (tol {tol})")
    shown = f"{reported:g}"
    if shown not in text and f"{abs(reported):g}" not in text:
        failures.append(f"{path} ({unit}): value {shown} not found in report text")

# each length quantity must still be exactly the millimetre value divided by ten
for paired in [
    ("primary_mean_difference_welch", "estimate"),
    ("primary_mean_difference_welch", "statistics.se"),
    ("crosscheck_mean_difference_pooled_t", "statistics.pooled_sd"),
    ("crosscheck_bootstrap_percentile", "statistics.bootstrap_se"),
    ("effect_size_cohens_d", "statistics.pooled_sd"),
    ("sensitivity_ancova_adjusted_for_age", "statistics.age_coefficient"),
]:
    aid, field = paired
    lo = float(get(f"{aid}.{field}", "mm"))
    hi = float(get(f"{aid}.{field}", "cm"))
    if abs(hi - lo / 10) > 1e-9:
        failures.append(f"{aid}.{field}: cm {hi} is not mm {lo} / 10")

# unit-free quantities must be identical in the two result files
for aid, field in [
    ("primary_mean_difference_welch", "pValue"),
    ("primary_mean_difference_welch", "statistics.t"),
    ("primary_mean_difference_welch", "statistics.df"),
    ("effect_size_cohens_d", "estimate"),
    ("effect_size_cohens_d", "statistics.hedges_g"),
    ("crosscheck_mann_whitney", "estimate.U_B"),
    ("diagnostics_distributional", "estimate.ks_two_sample.D"),
]:
    a_mm = float(get(f"{aid}.{field}", "mm"))
    a_cm = float(get(f"{aid}.{field}", "cm"))
    if abs(a_mm - a_cm) > max(1e-12, 1e-6 * abs(a_mm)):
        failures.append(f"{aid}.{field}: changed with the unit ({a_mm} vs {a_cm})")

# derived quantities used in the report must reproduce from the results
mean_a_cm = float(get("desc.estimate.by_group.A.mean", "cm"))
ratio = float(get("primary.estimate", "cm")) / mean_a_cm * 100
ratio_lo = float(get("primary.interval.low", "cm")) / mean_a_cm * 100
ratio_hi = float(get("primary.interval.high", "cm")) / mean_a_cm * 100
for label, val, shown in [
    ("relative diff %", ratio, 28.9),
    ("relative CI low %", ratio_lo, 22.6),
    ("relative CI high %", ratio_hi, 35.2),
]:
    if abs(val - shown) > 0.05:
        failures.append(f"{label}: computed {val:.1f}, report {shown}")
    if f"{shown:g}" not in text:
        failures.append(f"{label}: {shown} not found in report text")

p_prob = float(get("mwu.estimate.prob_B_greater_than_A_estimate", "mm"))
if abs(p_prob - 0.918) > 0.0006:
    failures.append(f"P(B>A) estimate {p_prob} does not round to 0.918")
if "91.8%" not in text:
    failures.append("P(B>A) 91.8% not found in report text")

p_primary = float(get("primary.pValue", "cm"))
if abs(p_primary - 5.764e-14) > 1e-16:
    failures.append(f"primary p {p_primary} vs reported 5.8e-14")
for shown in ["5.8 × 10⁻¹⁴", "1.3 × 10⁻¹⁰", "8.9 × 10⁻¹⁴"]:
    if shown not in text:
        failures.append(f"p-value form {shown} not found in report text")

# interval widths quoted in the report
width_cm = float(get("primary.interval.high", "cm")) - float(get("primary.interval.low", "cm"))
if abs(width_cm - 0.129) > 0.0005:
    failures.append(f"interval width {width_cm:.4f} cm does not round to 0.129")
print(f"checked {len(BINDINGS)} value bindings + conversion and invariance checks")
if failures:
    print("FAILED")
    for f in failures:
        print(" -", f)
    sys.exit(1)
print("all report numbers match the executed results")
