#!/usr/bin/env python3
"""Compare the previous (cohort-file only) results with the combined analysis.

Reads the two result directories produced by run_all.py:
  --old  cohort-only   results from data/cohort.csv alone        (previous delivery)
  --new  .             results from cohort + supplement          (this delivery)

For every quantity that either changes with the data or is invariant to the
reported unit, it writes the old value, the new value and the change, in both the
analysis unit (mm) and the reported unit (cm). No statistic is recomputed here.

Outputs (in --new):
  stage-comparison.json        counts, per-metric comparison, checks
  table-stage-comparison.csv   the same comparison as a table

Usage:  python3 compare_stages.py --old cohort-only --new .
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import convert_units as cu

HERE = Path(__file__).resolve().parent


def get(entry: dict, path: str):
    cur = entry
    for part in path.split("."):
        if cur is None:
            return None
        cur = cur[int(part)] if isinstance(cur, list) else cur.get(part)
    return cur


def by_id(results: dict) -> dict:
    return {a["id"]: a for a in results["analyses"]}


def num(v):
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def load(dirpath: Path) -> dict:
    res = json.loads((dirpath / "analysis-results.json").read_text(encoding="utf-8"))
    cm = json.loads((dirpath / "analysis-results-cm.json").read_text(encoding="utf-8"))
    rc = json.loads((dirpath / "crosscheck-r.json").read_text(encoding="utf-8"))
    return {"mm": by_id(res), "cm": by_id(cm), "results": res, "rc": rc}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", default="cohort-only")
    ap.add_argument("--new", default=".")
    ap.add_argument("--alpha", type=float, default=0.05)
    args = ap.parse_args()

    old_dir = (HERE / args.old).resolve()
    new_dir = (HERE / args.new).resolve()
    old, new = load(old_dir), load(new_dir)

    rows = []
    for kind, registry in (("length", cu.SCALE), ("unit-free", cu.KEEP)):
        for aid, items in registry.items():
            for path, label in items:
                o_mm = num(get(old["mm"].get(aid, {}), path))
                n_mm = num(get(new["mm"].get(aid, {}), path))
                o_cm = num(get(old["cm"].get(aid, {}), path))
                n_cm = num(get(new["cm"].get(aid, {}), path))
                if o_mm is None or n_mm is None:
                    continue
                rel = None if o_mm == 0 else (n_mm - o_mm) / abs(o_mm)
                # the cm layer rescales lengths only; unit-free quantities carry the
                # same number in both files, so they get no cm column
                if kind != "length":
                    o_cm = n_cm = None
                rows.append({
                    "metric": label,
                    "analysis": aid,
                    "path": path,
                    "kind": kind,
                    "oldMm": round(o_mm, 10),
                    "newMm": round(n_mm, 10),
                    "changeMm": round(n_mm - o_mm, 10),
                    "relativeChange": None if rel is None else round(rel, 8),
                    "oldCm": None if o_cm is None else round(o_cm, 8),
                    "newCm": None if n_cm is None else round(n_cm, 8),
                    "changeCm": None if (o_cm is None or n_cm is None) else round(n_cm - o_cm, 8),
                })

    # Hodges-Lehmann shift from the R cross-check (millimetres in both stages)
    for key, label in (("estimate", "Hodges-Lehmann 位置移动"),
                       ("conf.low", "HL 区间下限"),
                       ("conf.high", "HL 区间上限")):
        o = num(old["rc"]["hodgesLehmann"].get(key))
        n = num(new["rc"]["hodgesLehmann"].get(key))
        if o is None or n is None:
            continue
        rows.append({
            "metric": label,
            "analysis": "hodges_lehmann_r",
            "path": f"hodgesLehmann.{key}",
            "kind": "length",
            "oldMm": round(o, 10), "newMm": round(n, 10), "changeMm": round(n - o, 10),
            "relativeChange": None if o == 0 else round((n - o) / abs(o), 8),
            "oldCm": round(o / 10.0, 8), "newCm": round(n / 10.0, 8),
            "changeCm": round((n - o) / 10.0, 8),
        })
    o_p = num(old["rc"]["hodgesLehmann"].get("p.value"))
    n_p = num(new["rc"]["hodgesLehmann"].get("p.value"))
    if o_p is not None and n_p is not None:
        rows.append({
            "metric": "HL p 值", "analysis": "hodges_lehmann_r",
            "path": "hodgesLehmann.p.value", "kind": "unit-free",
            "oldMm": o_p, "newMm": n_p, "changeMm": n_p - o_p,
            "relativeChange": None if o_p == 0 else round((n_p - o_p) / abs(o_p), 8),
            "oldCm": None, "newCm": None, "changeCm": None,
        })

    old_flow = old["results"]["cohortFlow"]
    new_flow = new["results"]["cohortFlow"]

    # p values must not switch side of alpha; estimates must keep their sign
    p_fields = [r for r in rows if r["path"] in ("pValue", "estimate.shapiro.A.p",
                                                 "estimate.shapiro.B.p", "estimate.levene_mean_centered.p",
                                                 "estimate.ks_two_sample.p", "statistics.age_p",
                                                 "hodgesLehmann.p.value")]
    sign_fields = [r for r in rows if r["metric"] in
                   ("Welch 均值差", "合并方差均值差", "bootstrap 均值差", "ANCOVA 组间差",
                    "Hodges-Lehmann 位置移动", "均值差（未进区间）", "Cohen's d")]
    checks = {
        "pValueSideOfAlphaUnchanged": {
            "alpha": args.alpha,
            "pass": all((r["oldMm"] < args.alpha) == (r["newMm"] < args.alpha) for r in p_fields),
            "detail": [{"metric": r["metric"], "old": r["oldMm"], "new": r["newMm"],
                        "oldSignificant": bool(r["oldMm"] < args.alpha),
                        "newSignificant": bool(r["newMm"] < args.alpha)} for r in p_fields],
        },
        "estimateSignUnchanged": {
            "pass": all((r["oldMm"] > 0) == (r["newMm"] > 0) for r in sign_fields),
            "detail": [{"metric": r["metric"], "old": r["oldMm"], "new": r["newMm"]}
                       for r in sign_fields],
        },
        "unitConversionConsistent": {
            "pass": all(abs(r["newCm"] - r["newMm"] / 10.0) <= 2e-6
                        for r in rows if r["kind"] == "length" and r["newCm"] is not None),
            "maxAbsDeviation": max([abs(r["newCm"] - r["newMm"] / 10.0) for r in rows
                                    if r["kind"] == "length" and r["newCm"] is not None] or [0.0]),
            "checkedRows": sum(1 for r in rows if r["kind"] == "length" and r["newCm"] is not None),
        },
    }

    unit_free = [r for r in rows if r["kind"] == "unit-free" and r["relativeChange"] is not None]
    out = {
        "schemaVersion": 1,
        "old": {"dir": args.old, "label": "cohort.csv only", "n": old_flow["analysis_n"],
                "nByGroup": old_flow["analysis_n_by_group"],
                "inputSha256": old["results"].get("dataset", {}).get("sha256")},
        "new": {"dir": args.new, "label": "cohort.csv + supplement.csv", "n": new_flow["analysis_n"],
                "nByGroup": new_flow["analysis_n_by_group"],
                "inputSha256": new["results"].get("dataset", {}).get("sha256")},
        "flow": {"old": old_flow, "new": new_flow},
        "rowsCompared": len(rows),
        "lengthRows": sum(1 for r in rows if r["kind"] == "length"),
        "unitFreeRows": len(unit_free),
        "maxAbsRelativeChangeUnitFree": max([abs(r["relativeChange"]) for r in unit_free] or [0.0]),
        "rows": rows,
        "checks": checks,
        "note": "Both stages use the same estimand (mean marker, group B minus A, independent unit "
                "patient_id), the same exclusion rules and the same methods; only the input rows "
                "differ. Values in mm come from analysis-results.json, values in cm from "
                "analysis-results-cm.json; nothing is recomputed here.",
    }
    (new_dir / "stage-comparison.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")

    def fmt(v, nd):
        return "" if v is None else f"{v:.{nd}f}"

    lines = ["项目,分析步骤,单位类别,上一版（n=%d）,本版（n=%d）,变化量,相对变化,"
             "上一版_cm,本版_cm,变化_cm" % (out["old"]["n"], out["new"]["n"])]
    lines.append("纳入人数（总）,cohortFlow,计数,%d,%d,%d,,,," %
                 (out["old"]["n"], out["new"]["n"], out["new"]["n"] - out["old"]["n"]))
    for g in ("A", "B"):
        lines.append("纳入人数（%s 组）,cohortFlow,计数,%d,%d,%d,,,," %
                     (g, old_flow["analysis_n_by_group"][g], new_flow["analysis_n_by_group"][g],
                      new_flow["analysis_n_by_group"][g] - old_flow["analysis_n_by_group"][g]))
    for r in rows:
        lines.append(",".join([
            r["metric"], r["analysis"], "长度量" if r["kind"] == "length" else "无量纲",
            fmt(r["oldMm"], 10), fmt(r["newMm"], 10), fmt(r["changeMm"], 10),
            "" if r["relativeChange"] is None else fmt(r["relativeChange"], 8),
            fmt(r["oldCm"], 8), fmt(r["newCm"], 8), fmt(r["changeCm"], 8),
        ]))
    (new_dir / "table-stage-comparison.csv").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({"status": "ok", "rowsCompared": out["rowsCompared"],
                      "oldN": out["old"]["n"], "newN": out["new"]["n"],
                      "maxAbsRelativeChangeUnitFree": out["maxAbsRelativeChangeUnitFree"],
                      "checks": {k: v["pass"] for k, v in checks.items()}}, ensure_ascii=False, indent=1))
    return 0 if all(v["pass"] for v in checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
