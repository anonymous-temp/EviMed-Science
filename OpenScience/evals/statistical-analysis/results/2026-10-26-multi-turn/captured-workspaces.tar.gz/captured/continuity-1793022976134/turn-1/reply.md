换算已经完成：报告里所有长度量都按 **1 cm = 10 mm** 统一除以 10，结论表述为 **B 组比 A 组平均高 0.296 cm（95% CI 0.232–0.360 cm）**，相当于 2.96 mm。这仍是同一批人、同样的分组，估计方法、随机种子和数据文件都没有改动。

**变了（所有以 marker 为单位的长度量，统一除以 10）**

| 量 | 原来（mm） | 现在（cm） |
|---|---|---|
| A 组均值 / SD | 10.233 / 1.437 | 1.023 / 0.144 |
| B 组均值 / SD | 13.193 / 1.459 | 1.319 / 0.146 |
| 均值差与区间 | 2.960（2.315–3.605） | 0.296（0.232–0.360） |
| Welch 标准误 | 0.324 | 0.032 |
| 合并标准差 | 1.448 | 0.145 |
| Hodges-Lehmann 位移与区间 | 2.985（2.363–3.567） | 0.298（0.236–0.357） |
| ANCOVA 年龄系数 | 0.0026 mm/岁 | 0.00026 cm/岁 |

中位数、四分位数、极值同样除以 10；置信区间宽度从 1.290 mm 变成 0.129 cm，覆盖含义不变。

**没变（无量纲或比值，数值与判断都一样）**：Welch t = 9.14、df = 77.98、p = 5.8 × 10⁻¹⁴；合并方差 t 与 p、bootstrap 区间方法、Hodges-Lehmann 的 W 与 p；Cohen's d = 2.044（1.648–2.561）、Hedges g = 2.024；Mann-Whitney U = 1468/1600、P(B>A) = 91.8%；KS D = 0.65；Levene W = 0.063；Shapiro-Wilk W = 0.915/0.911；年龄与 marker 相关 0.0456；相对差值 28.9%（22.6–35.2%）；年龄 54.5/55.5 岁、n = 80。换句话说，“有没有统计学证据”“差异相对于变异有多大”这两类判断和毫米版完全一致。

换算不是重新算一遍就了事：我把同一批患者的 marker 值整体除以 10 生成厘米副本，用同一种子重跑全部流程来核对——39 个长度量与换算结果的最大绝对差为 5 × 10⁻⁷（就是结果本身的小数舍入），28 个无量纲量完全一致。唯一的说明是 Hodges-Lehmann 区间端点：R 用求根定位近似区间、绝对容差约 1.2 × 10⁻⁴，所以厘米重跑与“毫米端点 ÷10”在 1 × 10⁻⁴ 内一致，点估计本身精确等于毫米值 ÷10，远小于报告中 3 位小数的精度。

![两组 marker 分布与各方法差值估计（单位：cm）](deliverables/statistical-analysis-report/fig-marker-by-group.png)

交付文件在 `deliverables/statistical-analysis-report/`：[报告（cm 版）](deliverables/statistical-analysis-report/statistical-report.md)、[图](deliverables/statistical-analysis-report/fig-marker-by-group.png)、[cm 结果表](deliverables/statistical-analysis-report/table-difference-estimates-cm.csv)、[逐项换算对照表](deliverables/statistical-analysis-report/table-unit-change.csv)、[换算核对结果](deliverables/statistical-analysis-report/unit-change-check.json)。原始数据 `data/cohort.csv` 未改动（仍按字典以毫米存储），毫米结果 `analysis-results.json` 保留为分析记录，厘米结果 `analysis-results-cm.json` 是报告层；状态文件里记了分析单位、报告单位、换算因子、变化量与不变量清单和核对结论。以后若只想再换单位（比如改成米），只需重跑换算这一步，不必重算估计。

参考文献：
1. Welch BL. The generalization of "Student's" problem when several different population variances are involved. *Biometrika*. 1947;34(1-2):28–35. https://doi.org/10.1093/biomet/34.1-2.28
2. Shapiro SS, Wilk MB. An analysis of variance test for normality (complete samples). *Biometrika*. 1965;52(3-4):591–611. https://doi.org/10.1093/biomet/52.3-4.591
3. Efron B, Tibshirani RJ. *An Introduction to the Bootstrap*. Chapman & Hall/CRC; 1993. https://doi.org/10.1201/9780429246593
4. Hedges LV. Distribution theory for Glass's estimator of effect size and related estimators. *Journal of Educational Statistics*. 1981;6(2):107–128. https://doi.org/10.3102/10769986006002107
5. Cohen J. *Statistical Power Analysis for the Behavioral Sciences*. 2nd ed. Lawrence Erlbaum; 1988. https://doi.org/10.4324/9780203771587
6. R Core Team. `wilcox.test`: Wilcoxon Rank Sum and Signed Rank Tests. https://stat.ethz.ch/R-manual/R-devel/library/stats/html/wilcox.test.html