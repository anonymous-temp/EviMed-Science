#!/usr/bin/env python3
"""Presentation-unit conversion: report the marker in centimetres.

The stored data and every fitted quantity stay in millimetres. This step only
re-expresses the reported values, so nothing is re-estimated:

    value_cm = value_mm / 10        (1 cm = 10 mm)

Length-valued quantities (means, SDs, medians, quartiles, extremes, the mean
difference with its interval and standard error, the Hodges-Lehmann shift, the
ANCOVA coefficient in mm/year -> cm/year) are divided by 10. Quantities that do
not carry the outcome's unit (t, df, p, Cohen's d, Hedges g, correlations, KS D,
Levene/Shapiro statistics, Mann-Whitney U, P(B>A), the relative percentage,
age in years, n) are copied unchanged.

Inputs   analysis-results.json, crosscheck-r.json, table-group-summary.csv,
         table-difference-estimates.csv
Outputs  analysis-results-cm.json, table-group-summary-cm.csv,
         table-difference-estimates-cm.csv, table-unit-change.csv,
         unit-conversion.json

Usage:  python3 convert_units.py [--outdir .] [--factor 0.1]
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent

# ---- fields that carry the outcome's length unit -------------------------
SCALE = {
    "descriptive_by_group": [
        ("estimate.by_group.A.mean", "A 组均值"),
        ("estimate.by_group.A.sd", "A 组标准差"),
        ("estimate.by_group.A.median", "A 组中位数"),
        ("estimate.by_group.A.q1", "A 组 Q1"),
        ("estimate.by_group.A.q3", "A 组 Q3"),
        ("estimate.by_group.A.min", "A 组最小"),
        ("estimate.by_group.A.max", "A 组最大"),
        ("estimate.by_group.B.mean", "B 组均值"),
        ("estimate.by_group.B.sd", "B 组标准差"),
        ("estimate.by_group.B.median", "B 组中位数"),
        ("estimate.by_group.B.q1", "B 组 Q1"),
        ("estimate.by_group.B.q3", "B 组 Q3"),
        ("estimate.by_group.B.min", "B 组最小"),
        ("estimate.by_group.B.max", "B 组最大"),
        ("estimate.difference_of_means_raw", "均值差（未进区间）"),
    ],
    "primary_mean_difference_welch": [
        ("estimate", "Welch 均值差"),
        ("interval.low", "Welch 区间下限"),
        ("interval.high", "Welch 区间上限"),
        ("statistics.se", "Welch 标准误"),
        ("statistics.group_sd.A", "A 组 SD"),
        ("statistics.group_sd.B", "B 组 SD"),
    ],
    "crosscheck_mean_difference_pooled_t": [
        ("estimate", "合并方差均值差"),
        ("interval.low", "合并方差区间下限"),
        ("interval.high", "合并方差区间上限"),
        ("statistics.pooled_sd", "合并标准差"),
    ],
    "crosscheck_bootstrap_percentile": [
        ("estimate", "bootstrap 均值差"),
        ("interval.low", "bootstrap 区间下限"),
        ("interval.high", "bootstrap 区间上限"),
        ("statistics.bootstrap_se", "bootstrap 标准误"),
    ],
    "effect_size_cohens_d": [
        ("statistics.pooled_sd", "Cohen's d 的分母（合并 SD）"),
    ],
    "sensitivity_ancova_adjusted_for_age": [
        ("estimate", "ANCOVA 组间差"),
        ("interval.low", "ANCOVA 区间下限"),
        ("interval.high", "ANCOVA 区间上限"),
        ("statistics.hc3_interval.low", "ANCOVA HC3 下限"),
        ("statistics.hc3_interval.high", "ANCOVA HC3 上限"),
        ("statistics.age_coefficient", "年龄系数（mm/岁 → cm/岁）"),
    ],
}

# ---- quantities the change of unit must leave untouched ------------------
KEEP = {
    "primary_mean_difference_welch": [
        ("statistics.t", "Welch t 统计量"),
        ("statistics.df", "Welch 自由度"),
        ("pValue", "Welch p 值"),
    ],
    "crosscheck_mean_difference_pooled_t": [
        ("statistics.t", "合并方差 t 统计量"),
        ("pValue", "合并方差 p 值"),
    ],
    "crosscheck_mann_whitney": [
        ("estimate.U_B", "Mann-Whitney U"),
        ("estimate.prob_B_greater_than_A_estimate", "P(B>A)"),
        ("pValue", "Mann-Whitney p 值"),
    ],
    "effect_size_cohens_d": [
        ("estimate", "Cohen's d"),
        ("interval.low", "d 区间下限"),
        ("interval.high", "d 区间上限"),
        ("statistics.hedges_g", "Hedges g"),
        ("statistics.hedges_J", "Hedges 校正因子 J"),
    ],
    "sensitivity_ancova_adjusted_for_age": [
        ("pValue", "ANCOVA p 值"),
        ("statistics.r_squared", "R²"),
        ("statistics.age_p", "年龄项 p 值"),
        ("statistics.age_balance.mean_A", "A 组年龄均值（岁）"),
        ("statistics.age_balance.mean_B", "B 组年龄均值（岁）"),
        ("statistics.age_balance.difference_B_minus_A", "年龄差（岁）"),
    ],
    "diagnostics_distributional": [
        ("estimate.shapiro.A.W", "Shapiro-Wilk W（A）"),
        ("estimate.shapiro.B.W", "Shapiro-Wilk W（B）"),
        ("estimate.shapiro.A.p", "Shapiro-Wilk p（A）"),
        ("estimate.shapiro.B.p", "Shapiro-Wilk p（B）"),
        ("estimate.levene_mean_centered.W", "Levene W"),
        ("estimate.levene_mean_centered.p", "Levene p"),
        ("estimate.ks_two_sample.D", "KS D"),
        ("estimate.ks_two_sample.p", "KS p"),
    ],
}

# extra unchanged values that live in derived prose quantities
DERIVED_KEEP = [
    ("relative_difference_pct", "相对差值（%）", 28.9),
    ("relative_difference_ci_low_pct", "相对差值区间下限（%）", 22.6),
    ("relative_difference_ci_high_pct", "相对差值区间上限（%）", 35.2),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def get(obj, path: str):
    cur = obj
    for part in path.split("."):
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    return cur


def put(obj, path: str, value) -> None:
    parts = path.split(".")
    cur = obj
    for part in parts[:-1]:
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    last = parts[-1]
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def relabel(text: str) -> str:
    """Unit labels inside free text: (mm) -> (cm), mm/岁 -> cm/岁."""
    if not isinstance(text, str):
        return text
    return (text.replace("(mm)", "(cm)")
                .replace("marker_mm (mm)", "marker_mm (cm)")
                .replace("mm/岁", "cm/岁")
                .replace("（mm）", "（cm）"))


def fmt(v: float) -> str:
    return f"{v:.6f}".rstrip("0").rstrip(".")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--factor", type=float, default=0.1,
                    help="value_reported = value_source * factor (default 0.1 for mm -> cm)")
    ap.add_argument("--source-unit", default="mm")
    ap.add_argument("--target-unit", default="cm")
    args = ap.parse_args()

    out = Path(args.outdir).resolve()
    src_path = HERE / "analysis-results.json"
    r_path = HERE / "crosscheck-r.json"
    res = json.loads(src_path.read_text(encoding="utf-8"))
    rc = json.loads(r_path.read_text(encoding="utf-8"))
    f = args.factor

    cm = copy.deepcopy(res)
    by_id = {a["id"]: a for a in cm["analyses"]}

    changed_rows, keep_rows = [], []
    for aid, fields in SCALE.items():
        for path, label in fields:
            old = get(by_id[aid], path)
            new = round(old * f, 10)
            put(by_id[aid], path, new)
            changed_rows.append([aid, path, label, old, new, "yes"])
        by_id[aid]["reportedUnit"] = args.target_unit
        by_id[aid]["sourceUnit"] = args.source_unit

    for aid, fields in KEEP.items():
        for path, label in fields:
            val = get(by_id[aid], path)
            keep_rows.append([aid, path, label, val, val, "no"])

    for aid, a in by_id.items():
        for key in ("estimand", "method", "notes", "denominator"):
            if key in a and isinstance(a[key], str):
                a[key] = relabel(a[key])
        if isinstance(a.get("statistics"), dict) and "denominator" in a["statistics"]:
            a["statistics"]["denominator"] = relabel(a["statistics"]["denominator"])

    hl = rc["hodgesLehmann"]
    hl_cm = {
        "estimate": round(hl["estimate"] * f, 10),
        "conf.low": round(hl["conf.low"] * f, 10),
        "conf.high": round(hl["conf.high"] * f, 10),
        "W": hl["W"],
        "p.value": hl["p.value"],
        "method": hl["method"],
    }
    changed_rows += [
        ["crosscheck_r_hodges_lehmann", "estimate", "Hodges-Lehmann 位移（R）", hl["estimate"], hl_cm["estimate"], "yes"],
        ["crosscheck_r_hodges_lehmann", "conf.low", "HL 区间下限", hl["conf.low"], hl_cm["conf.low"], "yes"],
        ["crosscheck_r_hodges_lehmann", "conf.high", "HL 区间上限", hl["conf.high"], hl_cm["conf.high"], "yes"],
    ]
    keep_rows += [
        ["crosscheck_r_hodges_lehmann", "W", "Wilcoxon W", hl["W"], hl["W"], "no"],
        ["crosscheck_r_hodges_lehmann", "p.value", "Wilcoxon p 值", hl["p.value"], hl["p.value"], "no"],
    ]
    for key, label, val in DERIVED_KEEP:
        keep_rows.append(["derived", key, label, val, val, "no"])

    cm["crosscheckR"] = {
        "source": r_path.name,
        "sourceUnit": args.source_unit,
        "reportedUnit": args.target_unit,
        "note": "Hodges-Lehmann shift re-expressed in the reported unit; the statistic and its p value "
                "are unit-free and unchanged",
        "hodgesLehmann": hl_cm,
    }
    cm["reportedUnit"] = args.target_unit
    cm["sourceUnit"] = args.source_unit
    cm["unitConversion"] = {
        "basis": f"1 {args.target_unit} = {round(1 / f, 10):g} {args.source_unit}",
        "factor": f,
        "formula": f"reported = source * {f}",
        "sourceFile": src_path.name,
        "sourceSha256": sha256(src_path),
        "rCrosscheckFile": r_path.name,
        "rCrosscheckSha256": sha256(r_path),
        "scaledFieldCount": len(changed_rows),
        "unchangedFieldCount": len(keep_rows),
        "appliedTo": ["means, SDs, medians, quartiles, min/max",
                      "mean difference (all four methods) with interval limits and standard errors",
                      "Hodges-Lehmann shift and its interval",
                      "ANCOVA coefficient for age (per year)"],
        "notAppliedTo": ["t statistics, degrees of freedom, p values",
                         "Cohen's d, Hedges g, Hedges J (standardized, unit-free)",
                         "rank statistics (U, W), KS D, Levene/Shapiro statistics and their p values",
                         "correlation, P(B>A), relative percentage difference",
                         "age in years, sample sizes"],
        "note": "Deterministic rescaling of already computed results; no re-estimation. "
                "Equivalence with a full re-run on data divided by 10 is checked by verify_unit_change.py.",
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    (out / "analysis-results-cm.json").write_text(
        json.dumps(cm, ensure_ascii=False, indent=2), encoding="utf-8")

    # tables, same layout as the millimetre versions but with centimetre columns
    with open(out / "table-group-summary-cm.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["group", "n", "mean_cm", "sd_cm", "median_cm", "q1_cm", "q3_cm", "min_cm", "max_cm"])
        for g in ("A", "B"):
            s = by_id["descriptive_by_group"]["estimate"]["by_group"][g]
            w.writerow([g, s["n"], fmt(s["mean"]), fmt(s["sd"]), fmt(s["median"]),
                        fmt(s["q1"]), fmt(s["q3"]), fmt(s["min"]), fmt(s["max"])])

    method = {
        "primary_welch": "Welch t",
        "pooled_t": "pooled t",
        "bootstrap_percentile": "bootstrap percentile",
        "ancova_age": "OLS t (HC3 cross-check)",
    }
    rows = [
        ("primary_welch", by_id["primary_mean_difference_welch"], "primary_welch"),
        ("pooled_t", by_id["crosscheck_mean_difference_pooled_t"], "pooled_t"),
        ("bootstrap_percentile", by_id["crosscheck_bootstrap_percentile"], "bootstrap_percentile"),
        ("ancova_age", by_id["sensitivity_ancova_adjusted_for_age"], "ancova_age"),
    ]
    with open(out / "table-difference-estimates-cm.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["analysis", "estimate_cm", "low", "high", "p", "interval_method"])
        for key, a, mkey in rows:
            w.writerow([key, f"{a['estimate']:.6f}", f"{a['interval']['low']:.6f}",
                        f"{a['interval']['high']:.6f}",
                        "" if a["pValue"] is None else f"{a['pValue']:.6g}",
                        method[mkey]])
        w.writerow(["hodges_lehmann", f"{hl_cm['estimate']:.6f}", f"{hl_cm['conf.low']:.6f}",
                    f"{hl_cm['conf.high']:.6f}", f"{hl_cm['p.value']:.6g}",
                    "Hodges-Lehmann shift (R wilcox.test, distribution-free)"])

    with open(out / "table-unit-change.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["analysis", "field", "label", "value_before", "value_after",
                    "unit_before", "unit_after", "changed"])
        for aid, path, label, old, new, ch in changed_rows:
            w.writerow([aid, path, label, old, new, args.source_unit, args.target_unit, ch])
        for aid, path, label, old, new, ch in keep_rows:
            w.writerow([aid, path, label, old, new, "unchanged", "unchanged", ch])

    (out / "unit-conversion.json").write_text(json.dumps({
        "schemaVersion": 1,
        "sourceUnit": args.source_unit,
        "reportedUnit": args.target_unit,
        "factor": f,
        "basis": f"1 {args.target_unit} = {round(1 / f, 10):g} {args.source_unit}",
        "formula": f"reported = source * {f}",
        "scaled": [{"analysis": a, "field": p, "label": lb, "before": o, "after": n}
                   for a, p, lb, o, n, _ in changed_rows],
        "unchanged": [{"analysis": a, "field": p, "label": lb, "value": o}
                      for a, p, lb, o, _, _ in keep_rows],
        "inputs": [{"path": src_path.name, "sha256": sha256(src_path)},
                   {"path": r_path.name, "sha256": sha256(r_path)}],
        "outputs": ["analysis-results-cm.json", "table-group-summary-cm.csv",
                    "table-difference-estimates-cm.csv", "table-unit-change.csv"],
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({"status": "ok", "reportedUnit": args.target_unit,
                      "scaledFields": len(changed_rows), "unchangedFields": len(keep_rows)}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
