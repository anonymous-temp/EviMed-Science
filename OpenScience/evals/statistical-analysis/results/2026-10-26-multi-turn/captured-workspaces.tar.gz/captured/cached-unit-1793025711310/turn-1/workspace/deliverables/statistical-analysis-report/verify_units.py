#!/usr/bin/env python3
"""Checks for the mm -> cm reporting conversion.

Verifies, without re-running the analysis, that:
  1. every length quantity in the cm report equals the frozen mm result x 0.1;
  2. scale-free quantities (p, d, g, r, ratios, counts) are unchanged between
     the two reports;
  3. the cm tables are exactly the mm tables x 0.1, with p columns identical;
  4. the original artifacts are byte-identical to the completed run.

Exit code 0 = all checks passed.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORIG = HERE / "statistical-report.md"
CM = HERE / "statistical-report-cm.md"
RESULTS = HERE / "analysis-results.json"
RECORD = HERE / "unit-conversion.json"
SUMMARY_MM = HERE / "table-group-summary.csv"
SUMMARY_CM = HERE / "table-group-summary-cm.csv"
DIFF_MM = HERE / "table-difference-estimates.csv"
DIFF_CM = HERE / "table-difference-estimates-cm.csv"

failures: list[str] = []
checks = 0


def check(cond: bool, label: str, detail: str = "") -> None:
    global checks
    checks += 1
    if not cond:
        failures.append(f"{label}{(' :: ' + detail) if detail else ''}")


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def rows(p: Path) -> list[dict]:
    with p.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main() -> int:
    orig = ORIG.read_text(encoding="utf-8")
    cm = CM.read_text(encoding="utf-8")
    res = json.loads(RESULTS.read_text(encoding="utf-8"))
    rec = json.loads(RECORD.read_text(encoding="utf-8"))
    a = {x["id"]: x for x in res["analyses"]}

    prim = a["primary_mean_difference_welch"]
    esc = a["effect_size_cohens_d"]
    sens = a["sensitivity_ancova_adjusted_for_age"]
    desc = a["descriptive_by_group"]["estimate"]["by_group"]
    boot = a["crosscheck_bootstrap_percentile"]
    mw = a["crosscheck_mann_whitney"]["estimate"]

    def need(text: str, label: str) -> None:
        check(text in cm, label, f"missing {text!r}")

    # ---- 1. converted values present in the cm report ----------------------
    diff_cm = prim["estimate"] * 0.1
    need(f"{diff_cm:.3f}", "primary estimate")
    need(f"{prim['interval']['low'] * 0.1:.3f}", "primary CI low")
    need(f"{prim['interval']['high'] * 0.1:.3f}", "primary CI high")
    need(f"{prim['statistics']['se'] * 0.1:.4f}", "Welch SE")
    width_cm = (prim["interval"]["high"] - prim["interval"]["low"]) * 0.1
    need(f"{width_cm:.3f}", "CI width")

    for g in ("A", "B"):
        d = desc[g]
        need(f"{d['mean'] * 0.1:.4f}", f"mean {g}")
        need(f"{d['sd'] * 0.1:.4f}", f"SD {g}")
        need(f"{d['median'] * 0.1:.4f}", f"median {g}")
        need(f"{d['q1'] * 0.1:.4f}", f"Q1 {g}")
        need(f"{d['q3'] * 0.1:.4f}", f"Q3 {g}")
        need(f"{d['min'] * 0.1:.4f}", f"min {g}")
        need(f"{d['max'] * 0.1:.4f}", f"max {g}")

    need(f"{boot['interval']['low'] * 0.1:.3f}", "bootstrap low")
    need(f"{boot['interval']['high'] * 0.1:.3f}", "bootstrap high")
    need(f"{a['crosscheck_mean_difference_pooled_t']['interval']['low'] * 0.1:.3f}", "pooled low")
    need(f"{a['crosscheck_mean_difference_pooled_t']['interval']['high'] * 0.1:.3f}", "pooled high")
    need(f"{sens['estimate'] * 0.1:.3f}", "ANCOVA estimate")
    need(f"{sens['interval']['low'] * 0.1:.3f}", "ANCOVA low")
    need(f"{sens['interval']['high'] * 0.1:.3f}", "ANCOVA high")
    need(f"{sens['statistics']['hc3_interval']['low'] * 0.1:.3f}", "HC3 low")
    need(f"{sens['statistics']['hc3_interval']['high'] * 0.1:.3f}", "HC3 high")
    need(f"{esc['statistics']['pooled_sd'] * 0.1:.4f}", "pooled SD")
    need(f"{sens['statistics']['age_coefficient'] * 0.1:.5f}".rstrip("0").rstrip("."), "age coefficient")
    need(f"{boot['statistics']['bootstrap_se'] * 0.1:.4f}", "bootstrap SE")

    # Hodges-Lehmann lives in the R crosscheck
    cc = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))
    need(f"{cc['hodgesLehmann']['estimate'] * 0.1:.3f}", "HL estimate")
    need(f"{cc['hodgesLehmann']['conf.low'] * 0.1:.3f}", "HL low")
    need(f"{cc['hodgesLehmann']['conf.high'] * 0.1:.3f}", "HL high")

    # ---- 2. scale-free quantities unchanged ---------------------------------
    unchanged = [
        ("5.8 × 10⁻¹⁴", "Welch p"),
        (f"{prim['statistics']['t']:.2f}", "Welch t"),
        (f"{prim['statistics']['df']:.2f}", "Welch df"),
        (f"{esc['estimate']:.2f}", "Cohen's d"),
        (f"{esc['statistics']['hedges_g']:.2f}", "Hedges g"),
        (f"{mw['prob_B_greater_than_A_estimate'] * 100:.1f}", "P(B>A)"),
        (f"{mw['U_B']:.0f}", "Mann-Whitney U"),
        (f"{a['diagnostics_distributional']['estimate']['ks_two_sample']['D']:.2f}", "KS D"),
        (f"{sens['statistics']['age_balance']['corr_age_marker']:.3f}", "age-marker r"),
    ]
    for text, label in unchanged:
        check(text in orig, f"{label} present in original report", text)
        check(text in cm, f"{label} carried over unchanged", text)

    rel = prim["estimate"] / desc["A"]["mean"]
    need(f"{rel * 100:.1f}%", "relative difference")

    # age quantities (years) must be identical in both reports
    check("54.5 vs 55.5 岁" in cm, "age means unchanged")

    # ---- 3. cm tables are exactly mm x 0.1 ---------------------------------
    s_mm, s_cm = rows(SUMMARY_MM), rows(SUMMARY_CM)
    check(len(s_mm) == len(s_cm) == 2, "summary row count", f"{len(s_mm)} vs {len(s_cm)}")
    for r_mm, r_cm in zip(s_mm, s_cm):
        check(r_mm["group"] == r_cm["group"] and r_mm["n"] == r_cm["n"], "summary key columns")
        for col in ("mean", "sd", "median", "q1", "q3", "min", "max"):
            mm = float(r_mm[f"{col}_mm"])
            got = float(r_cm[f"{col}_cm"])
            check(abs(got - mm * 0.1) < 5e-7, f"summary {r_mm['group']} {col}", f"{got} vs {mm * 0.1}")

    d_mm, d_cm = rows(DIFF_MM), rows(DIFF_CM)
    check(len(d_mm) == len(d_cm) == 4, "difference row count")
    for r_mm, r_cm in zip(d_mm, d_cm):
        check(r_mm["analysis"] == r_cm["analysis"], "difference key")
        check(r_mm["p"] == r_cm["p"], f"p unchanged for {r_rlabel(r_mm)}")
        check(r_mm["interval_method"] == r_cm["interval_method"], "interval method unchanged")
        for src, dst in (("estimate_mm", "estimate_cm"), ("low", "low_cm"), ("high", "high_cm")):
            mm = float(r_mm[src])
            got = float(r_cm[dst])
            check(abs(got - mm * 0.1) < 5e-7, f"difference {r_mm['analysis']} {src}", f"{got} vs {mm * 0.1}")

    # ---- 4. originals untouched --------------------------------------------
    for name, expected in rec["sources"].items():
        check(sha(HERE / name) == expected, f"source hash unchanged: {name}")

    state = json.loads((HERE / "analysis-state.json").read_text(encoding="utf-8"))
    for ex in state["executions"]:
        for out in ex["outputs"]:
            path = HERE / out["path"]
            check(path.exists() and sha(path) == out["sha256"],
                  f"output matches completed run: {out['path']}")

    print(f"{checks} checks, {len(failures)} failures")
    for f in failures:
        print("FAIL:", f)
    return 0 if not failures else 1


def r_rlabel(row: dict) -> str:
    return row["analysis"]


if __name__ == "__main__":
    sys.exit(main())
