#!/usr/bin/env python3
"""Check that the numbers printed in statistical-report.md match the executed results.

Each binding names a value in analysis-results.json (or crosscheck-r.json), the
number as written in the report, and a tolerance. The check fails if the number
is absent from the report text or differs from the computed value. It verifies
number-to-result correspondence only; it cannot certify the prose.

    python3 verify_numbers.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPORT = HERE / "statistical-report.md"

results = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
rc = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))
text = REPORT.read_text(encoding="utf-8")

A = {a["id"]: a for a in results["analyses"]}
d = A["descriptive_by_group"]["estimate"]["by_group"]


def get(path: str):
    """Dotted path into the merged results, e.g. primary.interval.low."""
    cur = {
        "primary": A["primary_mean_difference_welch"],
        "pooled": A["crosscheck_mean_difference_pooled_t"],
        "boot": A["crosscheck_bootstrap_percentile"],
        "mwu": A["crosscheck_mann_whitney"],
        "d": A["effect_size_cohens_d"],
        "ancova": A["sensitivity_ancova_adjusted_for_age"],
        "diag": A["diagnostics_distributional"],
        "desc": A["descriptive_by_group"],
        "flow": results["cohortFlow"],
        "hl": rc["hodgesLehmann"],
        "rw": rc["welch"],
    }
    parts = path.split(".")
    while parts:
        part = parts.pop(0)
        if isinstance(cur, list):
            cur = cur[int(part)]
        elif isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            # flat key holding dots, e.g. {"conf.low": ...}
            merged = ".".join([part] + parts)
            if isinstance(cur, dict) and merged in cur:
                return cur[merged]
            raise KeyError(part)
    return cur


BINDINGS = [
    # primary estimate and interval
    ("primary.estimate", 2.96, 0.005),
    ("primary.interval.low", 2.32, 0.005),
    ("primary.interval.high", 3.60, 0.005),
    ("primary.statistics.se", 0.324, 0.0005),
    ("primary.statistics.t", 9.14, 0.005),
    ("primary.statistics.df", 77.98, 0.005),
    # pooled and bootstrap and HL
    ("pooled.interval.low", 2.32, 0.005),
    ("boot.interval.low", 2.33, 0.005),
    ("boot.interval.high", 3.58, 0.005),
    ("boot.statistics.bootstrap_se", 0.321, 0.0005),
    ("hl.estimate", 2.98, 0.005),
    ("hl.conf.low", 2.36, 0.005),
    ("hl.conf.high", 3.57, 0.005),
    ("mwu.estimate.U_B", 1468, 0.5),
    # effect size
    ("d.estimate", 2.04, 0.005),
    ("d.interval.low", 1.65, 0.005),
    ("d.interval.high", 2.56, 0.005),
    ("d.statistics.hedges_g", 2.02, 0.005),
    ("d.statistics.pooled_sd", 1.448, 0.0005),
    # ancova and age balance
    ("ancova.estimate", 2.96, 0.005),
    ("ancova.interval.low", 2.31, 0.005),
    ("ancova.interval.high", 3.61, 0.005),
    ("ancova.statistics.hc3_interval.low", 2.29, 0.005),
    ("ancova.statistics.hc3_interval.high", 3.62, 0.005),
    ("ancova.statistics.age_coefficient", 0.0026, 0.00005),
    ("ancova.statistics.age_balance.mean_A", 54.5, 0.05),
    ("ancova.statistics.age_balance.mean_B", 55.5, 0.05),
    ("ancova.statistics.age_balance.difference_ci.0", -4.2, 0.05),
    ("ancova.statistics.age_balance.difference_ci.1", 6.2, 0.05),
    ("ancova.statistics.age_balance.welch_p", 0.70, 0.005),
    ("ancova.statistics.age_balance.corr_age_marker", 0.046, 0.0005),
    # diagnostics
    ("diag.estimate.shapiro.A.W", 0.915, 0.0005),
    ("diag.estimate.shapiro.B.W", 0.911, 0.0005),
    ("diag.estimate.levene_mean_centered.p", 0.80, 0.005),
    ("diag.estimate.ks_two_sample.D", 0.65, 0.005),
    # descriptive table
    ("desc.estimate.by_group.A.mean", 10.233, 0.0005),
    ("desc.estimate.by_group.A.sd", 1.437, 0.0005),
    ("desc.estimate.by_group.A.median", 10.515, 0.0005),
    ("desc.estimate.by_group.A.q1", 8.938, 0.0005),
    ("desc.estimate.by_group.A.q3", 11.549, 0.0005),
    ("desc.estimate.by_group.A.min", 8.000, 0.0005),
    ("desc.estimate.by_group.A.max", 12.328, 0.0005),
    ("desc.estimate.by_group.B.mean", 13.193, 0.0005),
    ("desc.estimate.by_group.B.sd", 1.459, 0.0005),
    ("desc.estimate.by_group.B.median", 13.115, 0.0005),
    ("desc.estimate.by_group.B.q1", 11.864, 0.0005),
    ("desc.estimate.by_group.B.q3", 14.505, 0.0005),
    ("desc.estimate.by_group.B.min", 11.012, 0.0005),
    ("desc.estimate.by_group.B.max", 15.381, 0.0005),
    # flow
    ("flow.analysis_n", 80, 0.5),
    ("flow.analysis_n_by_group.A", 40, 0.5),
    ("flow.analysis_n_by_group.B", 40, 0.5),
]

failures: list[str] = []
for path, reported, tol in BINDINGS:
    try:
        value = float(get(path))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"{path}: cannot read value ({exc})")
        continue
    if abs(value - reported) > tol:
        failures.append(f"{path}: results={value} but report says {reported} (tol {tol})")
    # the printed form must actually appear in the report
    if f"{reported:g}" not in text and f"{abs(reported):g}" not in text:
        failures.append(f"{path}: value {reported:g} not found in report text")

# derived quantities used in the report must reproduce from the results
mean_a = d["A"]["mean"]
ratio = get("primary.estimate") / mean_a * 100
ratio_lo = get("primary.interval.low") / mean_a * 100
ratio_hi = get("primary.interval.high") / mean_a * 100
for label, val, shown in [
    ("relative diff %", ratio, 28.9),
    ("relative CI low %", ratio_lo, 22.6),
    ("relative CI high %", ratio_hi, 35.2),
]:
    if abs(val - shown) > 0.05:
        failures.append(f"{label}: computed {val:.1f}, report {shown}")
    if f"{shown:g}" not in text:
        failures.append(f"{label}: {shown} not found in report text")

p_prob = get("mwu.estimate.prob_B_greater_than_A_estimate")
if abs(p_prob - 0.92) > 0.005:
    failures.append(f"P(B>A) estimate {p_prob} does not round to 0.92")
if "0.92" not in text:
    failures.append("P(B>A) 0.92 not found in report text")

p_primary = get("primary.pValue")
if abs(p_primary - 5.8e-14) > 1e-15:
    failures.append(f"primary p {p_primary} vs reported 5.8e-14")
for shown in ["5.8 × 10⁻¹⁴", "1.3 × 10⁻¹⁰", "8.9 × 10⁻¹⁴"]:
    if shown not in text:
        failures.append(f"p-value form {shown} not found in report text")

print(f"checked {len(BINDINGS)} value bindings + derived quantities")
if failures:
    print("FAILED")
    for f in failures:
        print(" -", f)
    sys.exit(1)
print("all report numbers match the executed results")
