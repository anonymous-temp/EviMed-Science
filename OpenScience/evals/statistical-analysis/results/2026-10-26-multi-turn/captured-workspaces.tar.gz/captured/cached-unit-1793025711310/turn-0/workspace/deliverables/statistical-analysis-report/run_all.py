#!/usr/bin/env python3
"""One-command reproducible run for the marker_mm group comparison.

Steps (defined in analysis-session.json, written by this script):
  1. prepare+estimate  python3 analysis.py       -> analysis-results.json, tables
  2. figure+crosscheck Rscript crosscheck.R      -> crosscheck-r.json, figure

Then records what actually ran in analysis-state.json (per-step input, script,
output hashes and versions) and analysis-run.json (execution receipt).

Usage:  python3 run_all.py [--input ../../data/cohort.csv] [--dictionary ../../data/dictionary.md]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def rel(cmd: list[str]) -> str:
    """Command as recorded: host paths trimmed to project-relative form."""
    ws = HERE.parents[1]
    shown = []
    for part in cmd:
        txt = str(part).replace(str(HERE), ".").replace(str(ws) + "/", "")
        if Path(txt).name.startswith("python"):
            txt = "python3"
        shown.append(txt)
    return " ".join(shown)


def scrub(line: str) -> str:
    ws = HERE.parents[1]
    return line.replace(str(HERE), ".").replace(str(ws) + "/", "")


def run(cmd: list[str], cwd: Path) -> dict:
    started = now()
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return {
        "command": rel(cmd),
        "returncode": proc.returncode,
        "startedAt": started,
        "finishedAt": now(),
        "stdoutTail": [scrub(x) for x in proc.stdout.strip().splitlines()[-6:]],
        "stderrTail": [scrub(x) for x in proc.stderr.strip().splitlines()[-6:]],
    }


def hashed(paths: list[Path]) -> list[dict]:
    out = []
    for p in paths:
        if p.exists():
            out.append({"path": p.name, "sha256": sha256(p), "bytes": p.stat().st_size})
        else:
            out.append({"path": p.name, "sha256": None, "bytes": None, "missing": True})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../../data/cohort.csv")
    ap.add_argument("--dictionary", default="../../data/dictionary.md")
    ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--bootstrap", type=int, default=20000)
    args = ap.parse_args()

    # paths are resolved from this script's directory, so the default
    # ../../data/... points at the project's data/ folder
    in_path = (HERE / args.input).resolve() if not Path(args.input).is_absolute() else Path(args.input)
    dict_path = (HERE / args.dictionary).resolve() if not Path(args.dictionary).is_absolute() else Path(args.dictionary)
    if not in_path.exists():
        raise SystemExit(f"input not found: {in_path}")

    spec = {
        "schemaVersion": 1,
        "note": "Step definition for this analysis. context holds the semantics each step depends on; "
        "reuse a step only while its script, inputs and context are unchanged.",
        "steps": [
            {
                "id": "estimate",
                "script": "analysis.py",
                "interpreter": "python",
                "inputs": [str(in_path), str(dict_path)],
                "outputs": ["analysis-results.json", "table-group-summary.csv", "table-difference-estimates.csv"],
                "dependsOn": [],
                "context": {
                    "unit": "patient_id (one baseline observation per subject)",
                    "groupLevels": ["A", "B"],
                    "referenceGroup": "A",
                    "comparisonGroup": "B",
                    "estimand": "mean marker_mm difference, B minus A",
                    "outcome": "marker_mm",
                    "outcomeUnit": "mm",
                    "missing": "complete case (rows without marker_mm excluded; 0 in this delivery)",
                    "duplicates": "no duplicate patient_id in this delivery; exact export duplicates would be dropped, "
                    "conflicting repeats need a stated rule",
                    "primary": "Welch t interval",
                    "crossChecks": ["pooled t", "bootstrap percentile", "Mann-Whitney"],
                    "sensitivity": "OLS ANCOVA adjusting for age",
                    "alpha": 0.05,
                    "seed": args.seed,
                    "bootstrapResamples": args.bootstrap,
                },
            },
            {
                "id": "figure_crosscheck",
                "script": "crosscheck.R",
                "interpreter": "r",
                "inputs": [str(in_path), "table-difference-estimates.csv"],
                "outputs": ["crosscheck-r.json", "fig-marker-by-group.png"],
                "dependsOn": ["estimate"],
                "context": {
                    "independentImplementation": "R",
                    "adds": "Hodges-Lehmann shift with distribution-free interval (R wilcox.test conf.int)",
                    "plot": "group distributions with mean and 95% CI; forest of the difference estimates",
                },
            },
        ],
    }
    spec_path = HERE / "analysis-session.json"
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")

    runs = []
    runs.append(
        run([sys.executable, "analysis.py", "--input", str(in_path), "--dictionary", str(dict_path),
             "--outdir", ".", "--seed", str(args.seed), "--bootstrap", str(args.bootstrap)], HERE)
    )
    if runs[-1]["returncode"] != 0:
        print(json.dumps(runs[-1], ensure_ascii=False, indent=2))
        raise SystemExit("python analysis failed")
    runs.append(run(["Rscript", "crosscheck.R", str(in_path), "."], HERE))
    if runs[-1]["returncode"] != 0:
        print(json.dumps(runs[-1], ensure_ascii=False, indent=2))
        raise SystemExit("R crosscheck failed")

    results_path = HERE / "analysis-results.json"
    results = json.loads(results_path.read_text(encoding="utf-8"))
    r_cross = json.loads((HERE / "crosscheck-r.json").read_text(encoding="utf-8"))

    state = {
        "schemaVersion": 1,
        "note": "Observed executions for the steps in analysis-session.json. A step's result may be reused "
        "only while these hashes, the context and the runtime versions match; a changed input hash means "
        "new data and requires re-running every dependent step.",
        "dataVersion": {
            "input": {"path": in_path.name, "sha256": sha256(in_path), "rows": None},
            "dictionary": {"path": dict_path.name, "sha256": sha256(dict_path) if dict_path.exists() else None},
            "analysisN": results["cohortFlow"]["analysis_n"],
            "analysisNByGroup": results["cohortFlow"]["analysis_n_by_group"],
        },
        "executions": [
            {
                "step": "estimate",
                "script": "analysis.py",
                "scriptPath": str(HERE / "analysis.py"),
                "scriptSha256": sha256(HERE / "analysis.py"),
                "command": runs[0]["command"],
                "startedAt": runs[0]["startedAt"],
                "exitCode": runs[0]["returncode"],
                "inputs": hashed([in_path, dict_path]),
                "outputs": hashed([results_path, HERE / "table-group-summary.csv", HERE / "table-difference-estimates.csv"]),
                "spec": "analysis-session.json",
                "specSha256": sha256(spec_path),
                "context": spec["steps"][0]["context"],
                "environment": {
                    "python": sys.version.split()[0],
                    "pandas": results["environment"]["pandas"],
                    "numpy": results["environment"]["numpy"],
                    "scipy": results["environment"]["scipy"],
                    "statsmodels": results["environment"]["statsmodels"],
                },
                "versions": {
                    "python": sys.version.split()[0],
                    "pandas": results["environment"]["pandas"],
                    "numpy": results["environment"]["numpy"],
                    "scipy": results["environment"]["scipy"],
                    "statsmodels": results["environment"]["statsmodels"],
                },
                "resultsWrite": {"path": str(results_path), "sha256": sha256(results_path)},
                "returncode": runs[0]["returncode"],
                "finishedAt": runs[0]["finishedAt"],
                "status": "ok",
            },
            {
                "step": "figure_crosscheck",
                "script": "crosscheck.R",
                "scriptPath": str(HERE / "crosscheck.R"),
                "scriptSha256": sha256(HERE / "crosscheck.R"),
                "command": runs[1]["command"],
                "startedAt": runs[1]["startedAt"],
                "exitCode": runs[1]["returncode"],
                "inputs": hashed([in_path, HERE / "table-difference-estimates.csv"]),
                "outputs": hashed([HERE / "crosscheck-r.json", HERE / "fig-marker-by-group.png"]),
                "spec": "analysis-session.json",
                "specSha256": sha256(spec_path),
                "context": spec["steps"][1]["context"],
                "environment": {"r": r_cross.get("rVersion")},
                "versions": {"r": r_cross.get("rVersion")},
                "returncode": runs[1]["returncode"],
                "finishedAt": runs[1]["finishedAt"],
                "status": "ok",
            },
        ],
    }
    state_path = HERE / "analysis-state.json"
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    receipt = {
        "schemaVersion": 1,
        "runId": hashlib.sha256((runs[0]["startedAt"] + str(args.seed) + str(in_path)).encode()).hexdigest()[:16],
        "startedAt": runs[0]["startedAt"],
        "finishedAt": runs[-1]["finishedAt"],
        "command": " ".join(["python3", "run_all.py", *sys.argv[1:]]),
        "platform": platform.platform(),
        "executions": [
            {
                "id": spec["steps"][i]["id"],
                "scriptPath": str(HERE / spec["steps"][i]["script"]),
                "scriptSha256": sha256(HERE / spec["steps"][i]["script"]),
                "command": runs[i]["command"],
                "startedAt": runs[i]["startedAt"],
                "finishedAt": runs[i]["finishedAt"],
                "durationSeconds": round(
                    (datetime.fromisoformat(runs[i]["finishedAt"])
                     - datetime.fromisoformat(runs[i]["startedAt"])).total_seconds(), 2),
                "exitCode": runs[i]["returncode"],
                "status": "ok" if runs[i]["returncode"] == 0 else "failed",
                "inputs": hashed([in_path, dict_path] if i == 0 else [in_path, HERE / "table-difference-estimates.csv"]),
                "outputs": hashed(
                    [results_path, HERE / "table-group-summary.csv", HERE / "table-difference-estimates.csv"]
                    if i == 0
                    else [HERE / "crosscheck-r.json", HERE / "fig-marker-by-group.png"]
                ),
                "resultsWritten": (results_path.exists() and (HERE / "analysis-results.json").stat().st_size > 0),
                "versions": (
                    {"python": sys.version.split()[0], **results["environment"], "r": r_cross.get("rVersion")}
                ),
            }
            for i in range(len(runs))
        ],
        "steps": runs,
        "inputs": hashed([in_path, dict_path]),
        "outputs": hashed(
            [
                results_path,
                HERE / "table-group-summary.csv",
                HERE / "table-difference-estimates.csv",
                HERE / "crosscheck-r.json",
                HERE / "fig-marker-by-group.png",
                spec_path,
                HERE / "statistical-report.md",
            ]
        ),
        "environment": {
            "python": sys.version.split()[0],
            **results["environment"],
            "r": r_cross.get("rVersion"),
        },
        "status": "ok" if all(r["returncode"] == 0 for r in runs) else "failed",
        "note": "Written by run_all.py from real hashes of what executed. The optional upstream helper "
        "receipt is not installed in this environment; this record replaces it.",
    }
    (HERE / "analysis-run.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({"status": receipt["status"], "runId": receipt["runId"],
                      "steps": [{"command": r["command"], "returncode": r["returncode"]} for r in runs]},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
