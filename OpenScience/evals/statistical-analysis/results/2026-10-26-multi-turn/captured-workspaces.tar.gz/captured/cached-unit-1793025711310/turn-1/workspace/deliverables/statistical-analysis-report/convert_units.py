#!/usr/bin/env python3
"""Reporting-unit conversion: millimetres -> centimetres.

The completed analysis (analysis.py / crosscheck.R) is NOT re-run and its stored
results are NOT modified.  This script reads the frozen outputs, multiplies the
length quantities by exactly 0.1, writes cm versions of the two result tables,
and records the conversion (source hashes, converted fields, untouched fields).

Values that are scale-free (p values, standardized effect sizes, ratios,
correlations, counts, age quantities in years) are carried over unchanged and
asserted to be identical.

Usage:
    python3 convert_units.py            # writes the cm tables + unit-conversion.json
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

FACTOR = 0.1  # 1 mm = 0.1 cm, an exact decimal scale change
HERE = Path(__file__).resolve().parent
RESULTS = HERE / "analysis-results.json"
SUMMARY = HERE / "table-group-summary.csv"
DIFF = HERE / "table-difference-estimates.csv"
CROSSCHECK = HERE / "crosscheck-r.json"

OUT_SUMMARY = HERE / "table-group-summary-cm.csv"
OUT_DIFF = HERE / "table-difference-estimates-cm.csv"
OUT_RECORD = HERE / "unit-conversion.json"

SUMMARY_MM_COLS = ["mean_mm", "sd_mm", "median_mm", "q1_mm", "q3_mm", "min_mm", "max_mm"]
SUMMARY_CM_COLS = [c.replace("_mm", "_cm") for c in SUMMARY_MM_COLS]
DIFF_MM_COLS = ["estimate_mm", "low", "high"]
DIFF_CM_COLS = ["estimate_cm", "low_cm", "high_cm"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with path.open(newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    return list(rows[0].keys()), rows


def cm(x: str) -> float:
    return float(x) * FACTOR


def write_csv(path: Path, header: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=header)
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    for p in (RESULTS, SUMMARY, DIFF, CROSSCHECK):
        if not p.exists():
            print(f"missing required input: {p}", file=sys.stderr)
            return 2

    # ---- group summary -----------------------------------------------------
    s_head, s_rows = read_csv(SUMMARY)
    assert s_head[0] == "group" and s_head[1] == "n", s_head
    out_s_rows = []
    for r in s_rows:
        row = {"group": r["group"], "n": r["n"]}
        for src, dst in zip(SUMMARY_MM_COLS, SUMMARY_CM_COLS):
            row[dst] = f"{cm(r[src]):.6f}"
        out_s_rows.append(row)
    write_csv(OUT_SUMMARY, ["group", "n"] + SUMMARY_CM_COLS, out_s_rows)

    # ---- difference estimates ---------------------------------------------
    d_head, d_rows = read_csv(DIFF)
    assert d_head[0] == "analysis", d_head
    out_d_rows = []
    for r in d_rows:
        row = {"analysis": r["analysis"]}
        for src, dst in zip(DIFF_MM_COLS, DIFF_CM_COLS):
            row[dst] = f"{cm(r[src]):.6f}"
        row["p"] = r["p"]  # scale-free, copied verbatim
        row["interval_method"] = r["interval_method"]
        out_d_rows.append(row)
    write_csv(OUT_DIFF, ["analysis"] + DIFF_CM_COLS + ["p", "interval_method"], out_d_rows)

    # ---- consistency checks -------------------------------------------------
    res = json.loads(RESULTS.read_text(encoding="utf-8"))
    analyses = {a["id"]: a for a in res["analyses"]}
    prim = analyses["primary_mean_difference_welch"]
    esc = analyses["effect_size_cohens_d"]
    sens = analyses["sensitivity_ancova_adjusted_for_age"]
    desc = analyses["descriptive_by_group"]["estimate"]

    mm_diff = prim["estimate"]
    cm_diff = mm_diff * FACTOR
    # the converted tables must reproduce the converted primary estimate exactly
    row_prim = next(r for r in out_d_rows if r["analysis"] == "primary_welch")
    assert abs(float(row_prim["estimate_cm"]) - cm_diff) < 5e-7
    # scale-free quantities stay identical
    rel_mm = mm_diff / desc["by_group"]["A"]["mean"]
    rel_cm = cm_diff / (desc["by_group"]["A"]["mean"] * FACTOR)
    assert abs(rel_mm - rel_cm) < 1e-12
    d_mm = mm_diff / esc["statistics"]["pooled_sd"]
    d_cm = cm_diff / (esc["statistics"]["pooled_sd"] * FACTOR)
    assert abs(d_mm - d_cm) < 1e-12
    assert abs(esc["estimate"] - d_mm) < 5e-3  # stored d is rounded to 3 dp

    # ---- conversion record ---------------------------------------------------
    record = {
        "schemaVersion": 1,
        "conversion": {
            "from": "mm",
            "to": "cm",
            "multiplier": FACTOR,
            "nature": "exact decimal scale change; no re-estimation, no re-sampling, no data change",
            "appliedOn": "2026-10-26",
        },
        "sources": {
            "analysis-results.json": sha256(RESULTS),
            "table-group-summary.csv": sha256(SUMMARY),
            "table-difference-estimates.csv": sha256(DIFF),
            "crosscheck-r.json": sha256(CROSSCHECK),
        },
        "converted": [
            {
                "output": OUT_SUMMARY.name,
                "from": SUMMARY.name,
                "columns": dict(zip(SUMMARY_MM_COLS, SUMMARY_CM_COLS)),
            },
            {
                "output": OUT_DIFF.name,
                "from": DIFF.name,
                "columns": dict(zip(DIFF_MM_COLS, DIFF_CM_COLS)),
            },
        ],
        "reportedInCm": {
            "primary_mean_difference": {
                "estimate": round(cm_diff, 6),
                "low": round(prim["interval"]["low"] * FACTOR, 6),
                "high": round(prim["interval"]["high"] * FACTOR, 6),
                "estimate_mm": prim["estimate"],
                "low_mm": prim["interval"]["low"],
                "high_mm": prim["interval"]["high"],
            },
            "group_means": {
                g: {
                    "mean_cm": round(desc["by_group"][g]["mean"] * FACTOR, 6),
                    "sd_cm": round(desc["by_group"][g]["sd"] * FACTOR, 6),
                    "mean_mm": desc["by_group"][g]["mean"],
                    "sd_mm": desc["by_group"][g]["sd"],
                }
                for g in ("A", "B")
            },
            "welch_se_cm": round(prim["statistics"]["se"] * FACTOR, 6),
            "bootstrap_se_cm": round(
                analyses["crosscheck_bootstrap_percentile"]["statistics"]["bootstrap_se"] * FACTOR, 6
            ),
            "ancova": {
                "estimate_cm": round(sens["estimate"] * FACTOR, 6),
                "low_cm": round(sens["interval"]["low"] * FACTOR, 6),
                "high_cm": round(sens["interval"]["high"] * FACTOR, 6),
                "hc3_low_cm": round(sens["statistics"]["hc3_interval"]["low"] * FACTOR, 6),
                "hc3_high_cm": round(sens["statistics"]["hc3_interval"]["high"] * FACTOR, 6),
                "age_coefficient_cm_per_year": round(
                    sens["statistics"]["age_coefficient"] * FACTOR, 8
                ),
            },
            "pooled_sd_cm": round(esc["statistics"]["pooled_sd"] * FACTOR, 6),
        },
        "unchanged": {
            "reason": "scale-free, unit-free, counts, p values, or measured in years",
            "items": [
                {"name": "p values (Welch, pooled t, ANCOVA, Mann-Whitney, KS, Shapiro, Levene)",
                 "value": "carried over verbatim"},
                {"name": "Welch t statistic and df", "value": prim["statistics"]["t"], "df": prim["statistics"]["df"]},
                {"name": "relative difference (B vs A, %)", "value": round(rel_mm * 100, 2),
                 "ci_pct": [22.6, 35.2]},
                {"name": "Cohen's d", "value": esc["estimate"], "ci": [esc["interval"]["low"], esc["interval"]["high"]]},
                {"name": "Hedges g", "value": esc["statistics"]["hedges_g"]},
                {"name": "Mann-Whitney U / U_max", "value": analyses["crosscheck_mann_whitney"]["estimate"]},
                {"name": "P(B > A) from U", "value": analyses["crosscheck_mann_whitney"]["estimate"]["prob_B_greater_than_A_estimate"]},
                {"name": "KS D", "value": analyses["diagnostics_distributional"]["estimate"]["ks_two_sample"]["D"]},
                {"name": "age quantities (years) and age-marker correlation",
                 "value": sens["statistics"]["age_balance"]},
                {"name": "n, group sizes, cohort flow", "value": res["cohortFlow"]},
                {"name": "data file cohort.csv", "note": "kept in mm; only the report's unit changed",
                 "sha256": "2318b4fc60b2c8c1cd0c78ec1e44600fbe5880240da208132585ca1d98fda90d"},
            ],
        },
        "outputs": {
            OUT_SUMMARY.name: sha256(OUT_SUMMARY),
            OUT_DIFF.name: sha256(OUT_DIFF),
        },
        "reports": {
            "statistical-report.md (mm, unchanged)": sha256(HERE / "statistical-report.md"),
            "statistical-report-cm.md (cm)": sha256(HERE / "statistical-report-cm.md"),
        },
        "note": "Source files (analysis-results.json, both mm tables, crosscheck-r.json, "
                "analysis.py, analysis-state.json, analysis-run.json) are byte-identical to the "
                "completed run; the statistical estimates were reused, not recomputed.",
    }
    OUT_RECORD.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # ---- console summary -----------------------------------------------------
    p = record["reportedInCm"]["primary_mean_difference"]
    print(f"primary mean difference: {p['estimate_mm']:.6f} mm = {p['estimate']:.6f} cm")
    print(f"95% CI: {p['low_mm']:.6f}-{p['high_mm']:.6f} mm = {p['low']:.6f}-{p['high']:.6f} cm")
    for g in ("A", "B"):
        gm = record["reportedInCm"]["group_means"][g]
        print(f"group {g}: mean {gm['mean_cm']:.4f} cm (SD {gm['sd_cm']:.4f} cm)")
    print("wrote:", OUT_SUMMARY.name, OUT_DIFF.name, OUT_RECORD.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
