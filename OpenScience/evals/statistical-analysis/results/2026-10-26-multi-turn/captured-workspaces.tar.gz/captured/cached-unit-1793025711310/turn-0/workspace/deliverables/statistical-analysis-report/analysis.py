#!/usr/bin/env python3
"""Reproducible analysis: marker_mm difference between group B and group A.

Estimand: difference in mean baseline marker_mm (group B minus group A) in mm,
independent unit = patient_id (one baseline observation per subject).

Primary method: Welch two-sample t interval (equal variances not assumed).
Cross-checks: pooled-variance t interval, nonparametric bootstrap percentile
interval, Mann-Whitney U test (distribution-free p). The Hodges-Lehmann shift
and its interval are computed independently in R (crosscheck.R).
Sensitivity: OLS ANCOVA adjusting for age.

Writes: analysis-results.json, table-group-summary.csv,
table-difference-estimates.csv. The step definition, execution state and run
receipt are written by run_all.py, which also runs crosscheck.R.

Usage:
  python3 analysis.py --input ../../data/cohort.csv --dictionary ../../data/dictionary.md \
      --outdir . --seed 20261026 --bootstrap 20000
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import statsmodels
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
from statsmodels.stats.weightstats import CompareMeans, DescrStatsW

SCHEMA_VERSION = 1
GROUPS = ("A", "B")
PRIMARY_PAIR = ("B", "A")  # B minus A


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def r2(x, n=4):
    return None if x is None or not np.isfinite(x) else round(float(x), n)


def entry(**kw):
    """One analysis entry shaped for analysis-results.json (schemaVersion 1)."""
    base = {
        "id": None,
        "status": "complete",
        "method": None,
        "estimand": None,
        "n": None,
        "estimate": None,
        "interval": None,
        "pValue": None,
        "warnings": [],
    }
    base.update(kw)
    return base


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--dictionary", default=None)
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--bootstrap", type=int, default=20000)
    ap.add_argument("--alpha", type=float, default=0.05)
    args = ap.parse_args()

    ws = Path.cwd()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    in_path = (ws / args.input).resolve() if not Path(args.input).is_absolute() else Path(args.input)
    dict_path = None
    if args.dictionary:
        dict_path = (ws / args.dictionary).resolve()

    t0 = utcnow()
    warnings: list[str] = []
    analyses: list[dict] = []

    # ---------------------------------------------------------------- prepare
    raw = pd.read_csv(in_path)
    n_rows_raw = len(raw)
    required = {"patient_id", "group", "age", "marker_mm"}
    missing_cols = sorted(required - set(raw.columns))
    if missing_cols:
        raise SystemExit(f"missing required columns: {missing_cols}")

    flow = {"rows_in_file": n_rows_raw}
    df = raw.copy()

    # group coding
    observed_groups = sorted(df["group"].dropna().unique().tolist())
    unexpected = [g for g in observed_groups if g not in GROUPS]
    if unexpected:
        warnings.append(f"unexpected group codes ignored/flagged: {unexpected}")
    df = df[df["group"].isin(GROUPS)].copy()
    flow["rows_after_group_filter"] = len(df)

    # duplicate handling (dictionary: identical repeat patient = export duplicate;
    # conflicting repeats need a stated rule)
    n_dup_subject = int(df["patient_id"].duplicated().sum())
    flow["duplicate_patient_ids"] = n_dup_subject
    n_exact_dup = int(df.duplicated().sum())
    flow["exact_duplicate_rows"] = n_exact_dup
    if n_dup_subject:
        df = df.sort_values(["patient_id", "group", "age", "marker_mm"])
        exact = df.duplicated(keep="first")
        df = df[~exact].copy()
        remaining = int(df["patient_id"].duplicated().sum())
        flow["conflicting_duplicate_patient_ids"] = remaining
        if remaining:
            warnings.append(
                "conflicting repeats kept as separate rows: no subject-level rule was given"
            )
        else:
            flow["duplicate_rule"] = "exact duplicate rows removed, first occurrence kept"
    else:
        flow["duplicate_rule"] = "not needed (no duplicate patient_id)"

    # missing outcome
    n_missing_marker = int(df["marker_mm"].isna().sum())
    flow["missing_marker_mm"] = n_missing_marker
    dfm = df.dropna(subset=["marker_mm"]).copy()
    flow["analysis_n"] = len(dfm)
    flow["analysis_n_by_group"] = {g: int((dfm["group"] == g).sum()) for g in GROUPS}
    if n_missing_marker:
        warnings.append(
            f"{n_missing_marker} rows without marker_mm excluded from all estimates "
            "(complete-case; missingness mechanism unknown)"
        )

    a = dfm.loc[dfm["group"] == PRIMARY_PAIR[1], "marker_mm"].to_numpy(float)
    b = dfm.loc[dfm["group"] == PRIMARY_PAIR[0], "marker_mm"].to_numpy(float)
    n_a, n_b = len(a), len(b)
    if n_a < 2 or n_b < 2:
        raise SystemExit("fewer than 2 observations per group; cannot estimate")

    mean_a, mean_b = a.mean(), b.mean()
    sd_a, sd_b = a.std(ddof=1), b.std(ddof=1)
    diff = mean_b - mean_a

    # ------------------------------------------------------------ descriptive
    def describe(x: np.ndarray) -> dict:
        return {
            "n": int(len(x)),
            "mean": r2(x.mean(), 6),
            "sd": r2(x.std(ddof=1), 6),
            "median": r2(np.median(x), 6),
            "q1": r2(np.percentile(x, 25), 6),
            "q3": r2(np.percentile(x, 75), 6),
            "min": r2(x.min(), 6),
            "max": r2(x.max(), 6),
        }

    by_group = {g: describe(dfm.loc[dfm["group"] == g, "marker_mm"].to_numpy(float)) for g in GROUPS}
    analyses.append(
        entry(
            id="descriptive_by_group",
            method="mean, SD, median, IQR, range per group (no test)",
            estimand="level of marker_mm (mm) in each group",
            n=len(dfm),
            estimate={"by_group": by_group, "difference_of_means_raw": r2(diff, 6)},
            notes="Descriptive; no interval or p value is implied.",
        )
    )

    # --------------------------------------------------- primary: Welch t CI
    cm = CompareMeans(DescrStatsW(b), DescrStatsW(a))
    welch_ci = cm.tconfint_diff(alpha=args.alpha, usevar="unequal")
    welch_t, welch_p, welch_df = cm.ttest_ind(usevar="unequal")
    welch = {
        "difference": diff,
        "ci_low": float(welch_ci[0]),
        "ci_high": float(welch_ci[1]),
        "se": float(np.sqrt(sd_a**2 / n_a + sd_b**2 / n_b)),
        "t": float(welch_t),
        "df": float(welch_df),
        "p": float(welch_p),
    }
    analyses.append(
        entry(
            id="primary_mean_difference_welch",
            method="Welch two-sample t interval (equal variances not assumed)",
            estimand="mean marker_mm, group B minus group A (mm)",
            n=n_b + n_a,
            estimate=r2(diff, 6),
            interval={"level": 1 - args.alpha, "low": r2(welch["ci_low"], 6), "high": r2(welch["ci_high"], 6)},
            pValue=float(f"{welch['p']:.3e}"),
            statistics={
                "se": r2(welch["se"], 6),
                "t": r2(welch["t"], 4),
                "df": r2(welch["df"], 3),
                "group_n": {"A": n_a, "B": n_b},
                "group_sd": {"A": r2(sd_a, 6), "B": r2(sd_b, 6)},
            },
            methodRecord={
                "assumptions": [
                    "independent observations (one baseline row per patient_id)",
                    "approximately normal sampling distribution of the group means "
                    "(n=40 per group; CLT applies, see normality diagnostics)",
                    "no assumption of equal variances",
                ],
                "references": [
                    "Welch BL. Biometrika 1947;34:28-35",
                    "statsmodels CompareMeans.tconfint_diff(usevar='unequal')",
                ],
            },
        )
    )

    # ------------------------------------------------- cross-check: pooled t
    pooled_ci = cm.tconfint_diff(alpha=args.alpha, usevar="pooled")
    pooled_t, pooled_p, pooled_df = cm.ttest_ind(usevar="pooled")
    pooled_sd = float(np.sqrt(((n_a - 1) * sd_a**2 + (n_b - 1) * sd_b**2) / (n_a + n_b - 2)))
    analyses.append(
        entry(
            id="crosscheck_mean_difference_pooled_t",
            method="Student pooled-variance two-sample t interval",
            estimand="mean marker_mm, group B minus group A (mm)",
            n=n_b + n_a,
            estimate=r2(diff, 6),
            interval={"level": 1 - args.alpha, "low": r2(pooled_ci[0], 6), "high": r2(pooled_ci[1], 6)},
            pValue=float(f"{pooled_p:.3e}"),
            statistics={"t": r2(pooled_t, 4), "df": int(pooled_df), "pooled_sd": r2(pooled_sd, 6)},
            methodRecord={"assumptions": ["as Welch plus equal population variances"], "references": []},
        )
    )

    # -------------------------------------------- cross-check: bootstrap CI
    rng = np.random.default_rng(args.seed)
    n_boot = int(args.bootstrap)
    boot = np.empty(n_boot)
    for i in range(n_boot):
        boot[i] = rng.choice(b, size=n_b, replace=True).mean() - rng.choice(
            a, size=n_a, replace=True
        ).mean()
    lo, hi = np.percentile(boot, [100 * args.alpha / 2, 100 * (1 - args.alpha / 2)])
    analyses.append(
        entry(
            id="crosscheck_bootstrap_percentile",
            method=f"nonparametric bootstrap percentile interval, {n_boot} resamples, seed {args.seed}",
            estimand="mean marker_mm, group B minus group A (mm)",
            n=n_b + n_a,
            estimate=r2(diff, 6),
            interval={"level": 1 - args.alpha, "low": r2(lo, 6), "high": r2(hi, 6)},
            statistics={"bootstrap_se": r2(boot.std(ddof=1), 6), "resamples": n_boot, "seed": args.seed},
            methodRecord={
                "assumptions": ["independent observations", "exchangeability within group", "no parametric form"],
                "references": ["Efron B, Tibshirani RJ. An Introduction to the Bootstrap, 1993"],
            },
        )
    )

    # --------------------------------------- cross-check: rank-based p value
    mwu = stats.mannwhitneyu(b, a, alternative="two-sided")
    n_pair = n_a * n_b
    analyses.append(
        entry(
            id="crosscheck_mann_whitney",
            method="Mann-Whitney U test (two-sided), normal approximation",
            estimand="stochastic ordering of marker_mm, group B relative to group A",
            n=n_b + n_a,
            estimate={
                "U_B": float(mwu.statistic),
                "U_max": float(n_pair),
                "prob_B_greater_than_A_estimate": r2(float(mwu.statistic) / n_pair, 4),
            },
            pValue=float(f"{mwu.pvalue:.3e}"),
            methodRecord={
                "assumptions": ["independent observations", "no distributional form"],
                "references": ["Mann HB, Whitney DR. Ann Math Stat 1947;18:50-60"],
            },
        )
    )
    # the Hodges-Lehmann shift estimate and its interval come from R (crosscheck.R),
    # which is a second independent implementation.

    # ------------------------------------------------------------ effect size
    d_cohen = diff / pooled_sd
    boot_d = np.empty(n_boot)
    for i in range(n_boot):
        rb = rng.choice(b, size=n_b, replace=True)
        ra = rng.choice(a, size=n_a, replace=True)
        sp = np.sqrt(((n_a - 1) * ra.var(ddof=1) + (n_b - 1) * rb.var(ddof=1)) / (n_a + n_b - 2))
        boot_d[i] = rb.mean() - ra.mean()
        boot_d[i] = boot_d[i] / sp if sp > 0 else np.nan
    dlo, dhi = np.nanpercentile(boot_d, [100 * args.alpha / 2, 100 * (1 - args.alpha / 2)])
    j = 1 - 3 / (4 * (n_a + n_b) - 9)  # Hedges small-sample correction
    analyses.append(
        entry(
            id="effect_size_cohens_d",
            method="Cohen's d (pooled-SD denominator) with bootstrap percentile interval; Hedges g = J*d",
            estimand="standardized mean difference, group B minus group A",
            n=n_b + n_a,
            estimate=r2(d_cohen, 4),
            interval={"level": 1 - args.alpha, "low": r2(dlo, 4), "high": r2(dhi, 4)},
            statistics={
                "hedges_g": r2(d_cohen * j, 4),
                "hedges_J": r2(j, 6),
                "pooled_sd": r2(pooled_sd, 6),
                "denominator": "pooled SD of marker_mm (mm)",
            },
            methodRecord={
                "assumptions": ["as Welch", "bootstrap resampling within group"],
                "references": ["Cohen J. Statistical Power Analysis, 1988", "Hedges LV. J Educ Stat 1981;6:107-128"],
            },
        )
    )

    # ------------------------------------------------------ sensitivity: age
    age_a = dfm.loc[dfm["group"] == "A", "age"].to_numpy(float)
    age_b = dfm.loc[dfm["group"] == "B", "age"].to_numpy(float)
    age_cm = CompareMeans(DescrStatsW(age_b), DescrStatsW(age_a))
    age_ci = age_cm.tconfint_diff(alpha=args.alpha, usevar="unequal")
    age_t, age_p, _ = age_cm.ttest_ind(usevar="unequal")
    r_age_marker = float(np.corrcoef(dfm["age"], dfm["marker_mm"])[0, 1])
    r_p = float(stats.pearsonr(dfm["age"], dfm["marker_mm"]).pvalue)

    ols = smf.ols("marker_mm ~ C(group) + age", data=dfm).fit()
    hc3 = ols.get_robustcov_results(cov_type="HC3")
    term = "C(group)[T.B]"
    ci = ols.conf_int(alpha=args.alpha).loc[term]
    ci_hc3 = hc3.conf_int(alpha=args.alpha)[hc3.model.exog_names.index(term)]
    adj_diff = float(ols.params[term])
    analyses.append(
        entry(
            id="sensitivity_ancova_adjusted_for_age",
            method="OLS ANCOVA: marker_mm ~ group + age (HC3 robust interval as a check)",
            estimand="group B minus group A difference in marker_mm (mm) holding age constant",
            n=int(ols.nobs),
            estimate=r2(adj_diff, 6),
            interval={"level": 1 - args.alpha, "low": r2(ci.iloc[0], 6), "high": r2(ci.iloc[1], 6)},
            pValue=float(f"{ols.pvalues[term]:.3e}"),
            statistics={
                "residual_df": int(ols.df_resid),
                "r_squared": r2(ols.rsquared, 4),
                "hc3_interval": {"low": r2(ci_hc3[0], 6), "high": r2(ci_hc3[1], 6)} if ci_hc3 is not None else None,
                "age_coefficient": r2(float(ols.params["age"]), 6),
                "age_p": float(f"{ols.pvalues['age']:.3e}"),
                "age_balance": {
                    "mean_A": r2(age_a.mean(), 3),
                    "mean_B": r2(age_b.mean(), 3),
                    "sd_A": r2(age_a.std(ddof=1), 3),
                    "sd_B": r2(age_b.std(ddof=1), 3),
                    "difference_B_minus_A": r2(age_b.mean() - age_a.mean(), 3),
                    "difference_ci": [r2(age_ci[0], 3), r2(age_ci[1], 3)],
                    "welch_p": float(f"{age_p:.3e}"),
                    "corr_age_marker": r2(r_age_marker, 4),
                    "corr_age_marker_p": float(f"{r_p:.3e}"),
                },
            },
            warnings=[
                "observational groups, not randomized: the adjusted difference is not a causal effect"
            ],
            methodRecord={
                "assumptions": ["linearity in age", "additivity of group and age", "independent errors"],
                "references": ["Vittinghoff E et al. Regression Methods in Biostatistics, 2nd ed."],
            },
        )
    )

    # ----------------------------------------------------------- diagnostics
    sh_a = stats.shapiro(a)
    sh_b = stats.shapiro(b)
    lev = stats.levene(a, b)
    bf = stats.levene(a, b, center="median")
    ks = stats.ks_2samp(b, a)
    diag_warn = []
    if min(sh_a.pvalue, sh_b.pvalue) < 0.05:
        diag_warn.append(
            "Shapiro-Wilk rejects normality in at least one group; with n=40 per group the "
            "Welch interval relies on the central limit theorem, and the bootstrap percentile "
            "interval does not rely on it"
        )
    if lev.pvalue < 0.05 or bf.pvalue < 0.05:
        diag_warn.append("variance homogeneity rejected; the pooled-variance interval is only a cross-check")
    analyses.append(
        entry(
            id="diagnostics_distributional",
            method="Shapiro-Wilk, Levene (mean and median centered), two-sample KS, skewness/kurtosis",
            estimand="assumption checks for the group comparison",
            n=n_b + n_a,
            estimate={
                "shapiro": {
                    "A": {"W": r2(sh_a.statistic, 4), "p": float(f"{sh_a.pvalue:.3e}"),
                          "skew": r2(stats.skew(a), 3), "excess_kurtosis": r2(stats.kurtosis(a), 3)},
                    "B": {"W": r2(sh_b.statistic, 4), "p": float(f"{sh_b.pvalue:.3e}"),
                          "skew": r2(stats.skew(b), 3), "excess_kurtosis": r2(stats.kurtosis(b), 3)},
                },
                "levene_mean_centered": {"W": r2(lev.statistic, 4), "p": r2(lev.pvalue, 4)},
                "levene_median_centered_brown_forsythe": {"W": r2(bf.statistic, 4), "p": r2(bf.pvalue, 4)},
                "ks_two_sample": {"D": r2(ks.statistic, 4), "p": float(f"{ks.pvalue:.3e}")},
            },
            warnings=diag_warn,
            methodRecord={
                "note": "a non-significant test does not prove the assumption; these are labels, not verdicts",
                "references": ["Shapiro SS, Wilk MB. Biometrika 1965;52:591-611"],
            },
        )
    )

    # ------------------------------------------------------------ multiplicity
    analyse_note = {
        "primary_comparisons": 1,
        "exploratory_comparisons": 0,
        "adjustment": "none applied: one pre-specified primary estimand (B minus A); "
        "cross-checks and the ANCOVA address the same estimand rather than additional hypotheses",
    }

    results = {
        "schemaVersion": SCHEMA_VERSION,
        "generatedAt": t0,
        "dataset": {
            "input": str(in_path.name),
            "inputSha256": sha256(in_path),
            "dictionary": dict_path.name if dict_path else None,
            "dictionarySha256": sha256(dict_path) if dict_path and dict_path.exists() else None,
            "outcome": "marker_mm",
            "outcomeUnit": "mm",
            "groupVariable": "group",
            "groups": list(GROUPS),
            "referenceGroup": PRIMARY_PAIR[1],
            "comparisonGroup": PRIMARY_PAIR[0],
            "independentUnit": "patient_id (one baseline observation per subject)",
            "note": "Synthetic/deterministic fixture data; no clinical efficacy claim is warranted.",
        },
        "cohortFlow": flow,
        "analyses": analyses,
        "multiplicity": analyse_note,
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "statsmodels": statsmodels.__version__,
        },
        "seed": args.seed,
        "warnings": warnings,
    }

    results_path = outdir / "analysis-results.json"
    results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    # ----------------------------------------------------------- flat tables
    rows = []
    for g in GROUPS:
        s = by_group[g]
        rows.append(
            {
                "group": g,
                "n": s["n"],
                "mean_mm": s["mean"],
                "sd_mm": s["sd"],
                "median_mm": s["median"],
                "q1_mm": s["q1"],
                "q3_mm": s["q3"],
                "min_mm": s["min"],
                "max_mm": s["max"],
            }
        )
    pd.DataFrame(rows).to_csv(outdir / "table-group-summary.csv", index=False)

    flat = [
        {"analysis": "primary_welch", "estimate_mm": welch["difference"], "low": welch["ci_low"],
         "high": welch["ci_high"], "p": welch["p"], "interval_method": "Welch t"},
        {"analysis": "pooled_t", "estimate_mm": diff, "low": pooled_ci[0], "high": pooled_ci[1],
         "p": pooled_p, "interval_method": "pooled t"},
        {"analysis": "bootstrap_percentile", "estimate_mm": diff, "low": lo, "high": hi,
         "p": None, "interval_method": "bootstrap percentile"},
        {"analysis": "ancova_age", "estimate_mm": adj_diff, "low": ci.iloc[0], "high": ci.iloc[1],
         "p": ols.pvalues[term], "interval_method": "OLS t (HC3 cross-check)"},
    ]
    pd.DataFrame(flat).to_csv(outdir / "table-difference-estimates.csv", index=False)

    print(
        json.dumps(
            {
                "n": {"A": n_a, "B": n_b},
                "mean": {"A": r2(mean_a, 4), "B": r2(mean_b, 4)},
                "diff": r2(diff, 4),
                "welch_ci": [r2(welch_ci[0], 4), r2(welch_ci[1], 4)],
                "pooled_ci": [r2(pooled_ci[0], 4), r2(pooled_ci[1], 4)],
                "boot_ci": [r2(lo, 4), r2(hi, 4)],
                "ancova": [r2(adj_diff, 4), r2(ci.iloc[0], 4), r2(ci.iloc[1], 4)],
                "cohen_d": r2(d_cohen, 4),
                "out": str(outdir),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
