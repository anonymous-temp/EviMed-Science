分析已经完成，结果文件保存在 `deliverables/statistical-analysis-package/`。

## 做了什么

- **数据**：569 行、30 个数值特征，无缺失值、无完全重复行；`breast_cancer_yn` 按数据字典 **0 = 恶性**（212 例）拟合 P(恶性)，全流程未对概率取反。首列行号只作记录键，不作特征。
- **模型**：训练行内拟合标准化，再加 L2 逻辑回归，共 30 个特征；惩罚强度 C 只在训练行内用 5 折分层交叉验证按 log loss 选（选定 C = 1.0）。
- **验证**：分层 70/30 随机划分 → 训练 398 例（恶性 148）、测试 171 例（恶性 64），测试集只评一次，未参与标准化、调参或阈值选择；阈值 0.5 是先验默认值，不是调出来的临床切点。
- **对照**：同一划分与调参规则下的 L1 逻辑回归，用来看 30 个特征里有多少冗余。

## 未参与拟合的数据上的表现

| 指标 | L2 主模型 | L1 稀疏对照 |
| --- | --- | --- |
| AUROC（95%CI） | 0.993（0.981–1.000） | 0.997（0.991–1.000） |
| Brier、对数损失 | 0.022 / 0.085 | 0.023 / 0.078 |
| 校准截距、斜率（95%CI） | −0.003（−0.99–0.98）/ 1.15（0.61–1.70） | −0.13（−1.14–0.89）/ 1.35（0.65–2.05） |
| 非零特征 | 30 | 14 |

阈值 0.5：真阳 62 / 假阴 2 / 真阴 106 / 假阳 1；敏感度 0.969（0.893–0.991）、特异度 0.991（0.949–0.998）、PPV 0.984、NPV 0.982，共 3 例判错。把阈值降到 0.3 敏感度不变而假阳性从 1 增到 6，降到 0.1 只多识别 1 例——两个漏诊（记录 213，p = 0.016；记录 135，p = 0.115）靠移动切点救不回来。

推动预测的主要是 `radius error`（OR 3.64/SD）、`worst texture`、`worst radius`、`worst concave points`，以及符号为负的 `fractal dimension error`（OR 0.44）。L1 把 16 个特征压到 0，性能基本不变。

## 可靠性判断

仅支持"在该数据分布内可复现地有效"，不支持换机构、换图像流程或临床使用。主要理由：

1. 同源、同一次导出的按行随机划分属于内部验证，没有时间外推，也没有跨机构验证。这一点是最重要的限制。
2. 概率几乎没有中间值：测试集 98 例 p ≤ 0.1、55 例 p ≥ 0.9，只有 18 例落在 0.1–0.9；0.2–0.8 区间的概率没有数据支撑。
3. 恶性只有 64 例，敏感度 95%CI 为 0.893–0.991，点估计的小数位不应引用。
4. PPV 0.984 建立在样本 37.3% 的恶性比例上；筛查人群中恶性比例低得多，同样的敏感度/特异度会给出低得多的 PPV。
5. 缺患者标识，无法排除同一患者多样本跨训练/测试；因此逐条预测审计的 fit-scope 与重复观测检查标为 `not_checked`，整体判定 `not_established`——不能声称"已排除泄漏"。行级一致性（无重叠、标签方向、由 CSV 重算的 AUROC/Brier 均一致，0 处不符）另做了独立核对。
6. 强共线（最高 |r| = 0.998）使得单个系数的大小和符号取决于同组放入哪些特征，只能读作条件关联，不能读作"半径本身的作用"。

## 文件

- [statistical-report.md](deliverables/statistical-analysis-package/statistical-report.md)：报告（含 4 张表、假设与适用边界）
- [analysis.py](deliverables/statistical-analysis-package/analysis.py)：全部建模与评估代码；`python analysis.py` 即可复现
- [analysis-results.json](deliverables/statistical-analysis-package/analysis-results.json)、[analysis-run.json](deliverables/statistical-analysis-package/analysis-run.json)：结构化结果与执行回执（哈希、库版本）
- [predictions.csv](deliverables/statistical-analysis-package/predictions.csv)：569 行逐条预测（划分、真实标签、`p_malignant`、0.5 判定、L1 预测、训练折外概率）
- [fitted-state.json](deliverables/statistical-analysis-package/fitted-state.json) / [fitted-model.joblib](deliverables/statistical-analysis-package/fitted-model.joblib)：拟合状态（标准化参数、系数、截距、C、阈值、软件版本）
- [prediction-audit.json](deliverables/statistical-analysis-package/prediction-audit.json)：逐条预测审计；[model-performance.svg](deliverables/statistical-analysis-package/model-performance.svg)：ROC 与校准图
- 报告中 128 个数值都由 `report.py` 从结果文件格式化生成，并用 `check_report_numbers.py` 逐条回溯核对（128/128 一致）