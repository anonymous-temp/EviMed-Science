#!/usr/bin/env python3
"""Render statistical-report.md from the executed results.

Every number in the report is formatted from analysis-results.json,
prediction-audit.json or fitted-state.json; the same values are written to
report-bindings.json so that the reported numbers can be checked against their
source paths (check_report_numbers.py). Re-running this script after a new
analysis regenerates the report and the bindings together.
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULTS = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
AUDIT = json.loads((HERE / "prediction-audit.json").read_text(encoding="utf-8"))
STATE = json.loads((HERE / "fitted-state.json").read_text(encoding="utf-8"))

BINDINGS: list[dict] = []


def num(value, source, decimals=3, suffix=""):
    text = f"{value:.{decimals}f}"
    BINDINGS.append(
        {
            "id": ".".join(str(part) for part in source),
            "source": source,
            "reported": float(text),
            "absoluteTolerance": 0.51 * 10 ** (-decimals),
        }
    )
    return text + suffix


def count(value, source, suffix=""):
    BINDINGS.append({"id": ".".join(str(p) for p in source), "source": source, "reported": int(value), "absoluteTolerance": 0})
    return f"{int(value)}{suffix}"


def ci(interval, decimals=3):
    return f"{interval[0]:.{decimals}f}–{interval[1]:.{decimals}f}"


primary, alt = RESULTS["analyses"][0], RESULTS["analyses"][1]
prof, diag, coef = RESULTS["profile"], RESULTS["diagnostics"], RESULTS["coefficients"]
P = "analyses", 0
op05 = primary["operatingPoints"]["0.5"]
shape = primary["probabilityShape"]
cal = primary["calibration"]
in_sample = primary["inSampleVsHeldOut"]

lines: list[str] = []
add = lines.append

add("# 乳腺癌肿瘤恶性概率：可解释基线模型与内部验证")
add("")
add("## 结论")
add("")
add(
    "在这份 WDBC 数据上，30 个特征标准化后的 L2 逻辑回归，在未参与拟合的 "
    f"{count(primary['n']['test'], P + ('n', 'test'))} 例中区分度很高"
    f"（AUROC {num(primary['discrimination']['auroc'], P + ('discrimination', 'auroc'))}，"
    f"95%CI {num(primary['discrimination']['aurocCI95Bootstrap'][0], P + ('discrimination', 'aurocCI95Bootstrap', 0))}–"
    f"{num(primary['discrimination']['aurocCI95Bootstrap'][1], P + ('discrimination', 'aurocCI95Bootstrap', 1))}），"
    f"概率整体接近校准（Brier {num(primary['overall']['brier'], P + ('overall', 'brier'))}，"
    f"校准斜率 {num(cal['slope'], P + ('calibration', 'slope'), 2)}）；"
    f"阈值 0.5 时 {count(primary['n']['eventsTest'], P + ('n', 'eventsTest'))} 例恶性中 "
    f"{count(op05['confusion']['truePositive'], P + ('operatingPoints', '0.5', 'confusion', 'truePositive'))} 例被正确识别。"
)
add("")
add(
    "但这只是同源数据的内部随机留出验证。没有患者标识、恶性样本只有 "
    f"{count(primary['n']['eventsTest'], P + ('n', 'eventsTest'))} 例，且概率几乎只取 0 和 1"
    f"（仅 {count(shape['testRowsBetween0.1And0.9'], P + ('probabilityShape', 'testRowsBetween0.1And0.9'))} 例落在 0.1–0.9）。"
    "因此结论只支持“在该数据分布内可复现地有效”，不足以支持换机构、换图像流程或直接用于临床决策。"
)
add("")

add("## 1 数据与结局定义")
add("")
add(
    f"数据为 {count(prof['rows'], ('profile', 'rows'))} 行、{count(prof['nFeatures'], ('profile', 'nFeatures'))} 个数值特征，"
    f"无缺失值（缺失 {count(prof['missingValues'], ('profile', 'missingValues'))} 个单元格），"
    f"无完全重复行（{count(prof['duplicateRowsAllColumns'], ('profile', 'duplicateRowsAllColumns'))} 行）。"
    f"恶性 {count(prof['classCounts']['malignant_source0'], ('profile', 'classCounts', 'malignant_source0'))} 例、"
    f"良性 {count(prof['classCounts']['benign_source1'], ('profile', 'classCounts', 'benign_source1'))} 例，"
    f"恶性占 {num(prof['malignantPercent'], ('profile', 'malignantPercent'), 1, '%')}。"
)
add("")
add(
    "数据字典规定 `breast_cancer_yn` 中 **0 表示恶性、1 表示良性**；本包拟合的目标是"
    " `z = 1 (恶性)`，`predictions.csv` 中的 `p_malignant` 与报告中所有概率都是 P(恶性)，"
    "未对任何概率做取反。首列是导出时写入的行号，只作记录键（`record_id`），不是预测因子。"
)
add("")
add(
    "字典说明一条记录对应一个肿瘤（细针穿刺样本），但抽取数据中没有患者标识："
    "行与行是否来自同一患者无法判断，本报告一律按“独立观测”处理，这是假设而非已验证的事实。"
)
add("")

add("## 2 模型与验证设计")
add("")
add(
    "- 特征：全部 30 个；在训练行上拟合标准化（均值/标准差），再拟合 L2 惩罚逻辑回归。"
)
add(
    f"- 惩罚强度 C 只在训练行内用 5 折分层交叉验证、以 log loss 在 0.003–10 之间选取，得 C = {num(STATE['l2Logistic']['C'], ('x', 'l2C'), 1) if False else STATE['l2Logistic']['C']}。"
)
add(
    f"- 分层随机 70/30 划分：训练 {count(primary['n']['train'], P + ('n', 'train'))} 例（恶性 "
    f"{count(primary['n']['eventsTrain'], P + ('n', 'eventsTrain'))} 例），测试 "
    f"{count(primary['n']['test'], P + ('n', 'test'))} 例（恶性 {count(primary['n']['eventsTest'], P + ('n', 'eventsTest'))} 例）。"
    "测试集只评一次，未参与标准化、调参或阈值选择。"
)
add("- 阈值 0.5 是先验设定的默认值，不是在本数据上优化的临床切点。")
add(
    "- 稀疏性对照：同一划分、同一调参规则下的 L1 逻辑回归，用来检查 30 个特征里有多少是冗余的。"
)
add("")
add(
    "随机按行划分属于内部验证。它回答“在同一来源的新个体上是否还能复现”，"
    "不回答“换医院、换设备、换染色/分割流程后是否仍然有效”。"
)
add("")

add("## 3 未参与拟合的数据上的表现")
add("")
add("表 1 主模型与稀疏对照（测试集，n = %s）" % count(primary["n"]["test"], P + ("n", "test")))
add("")
add("| 指标 | L2 主模型 | L1 稀疏对照 |")
add("| --- | --- | --- |")
add(
    f"| AUROC（95%CI） | {num(primary['discrimination']['auroc'], P + ('discrimination', 'auroc'))}（{ci(primary['discrimination']['aurocCI95Bootstrap'])}） "
    f"| {num(alt['discrimination']['auroc'], ('analyses', 1, 'discrimination', 'auroc'))}（{ci(alt['discrimination']['aurocCI95Bootstrap'])}） |"
)
add(
    f"| 平均精确率 | {num(primary['discrimination']['averagePrecision'], P + ('discrimination', 'averagePrecision'))} "
    f"| {num(alt['discrimination']['averagePrecision'], ('analyses', 1, 'discrimination', 'averagePrecision'))} |"
)
add(
    f"| Brier 分数 | {num(primary['overall']['brier'], P + ('overall', 'brier'))} "
    f"| {num(alt['overall']['brier'], ('analyses', 1, 'overall', 'brier'))} |"
)
add(
    f"| 对数损失 | {num(primary['overall']['logLoss'], P + ('overall', 'logLoss'))} "
    f"| {num(alt['overall']['logLoss'], ('analyses', 1, 'overall', 'logLoss'))} |"
)
add(
    f"| Brier skill（相对训练集患病率） | {num(primary['overall']['brierSkillScoreVsTrainPrevalence'], P + ('overall', 'brierSkillScoreVsTrainPrevalence'))} "
    f"| {num(alt['overall']['brierSkillScoreVsTrainPrevalence'], ('analyses', 1, 'overall', 'brierSkillScoreVsTrainPrevalence'))} |"
)
add(
    f"| 校准截距（95%CI） | {num(cal['intercept'], P + ('calibration', 'intercept'))}（{ci(cal['interceptCI95'])}） "
    f"| {num(alt['calibration']['intercept'], ('analyses', 1, 'calibration', 'intercept'))}（{ci(alt['calibration']['interceptCI95'])}） |"
)
add(
    f"| 校准斜率（95%CI） | {num(cal['slope'], P + ('calibration', 'slope'), 2)}（{ci(cal['slopeCI95'], 2)}） "
    f"| {num(alt['calibration']['slope'], ('analyses', 1, 'calibration', 'slope'), 2)}（{ci(alt['calibration']['slopeCI95'], 2)}） |"
)
add(
    f"| 非零特征数 | {count(prof['nFeatures'], ('profile', 'nFeatures'))} "
    f"| {count(coef['l1NSelected'], ('coefficients', 'l1NSelected'))} |"
)
add("")
add(
    f"测试集 Brier 为 {num(primary['overall']['brier'], P + ('overall', 'brier'))}，"
    f"相对“始终预测训练集患病率”的基准提升 {num(primary['overall']['brierSkillScoreVsTrainPrevalence'], P + ('overall', 'brierSkillScoreVsTrainPrevalence'))}。"
    f"校准截距 {num(cal['intercept'], P + ('calibration', 'intercept'))}（95%CI {ci(cal['interceptCI95'])}）与 0 相容，"
    f"斜率 {num(cal['slope'], P + ('calibration', 'slope'), 2)}（95%CI {ci(cal['slopeCI95'], 2)}）与 1 相容："
    "没有证据显示系统性高估或低估，但区间很宽，且几乎全部信息来自概率接近 0 与接近 1 的两端。"
)
add("")
add(
    f"训练集内 AUROC {num(in_sample['aurocTrainInSample'], P + ('inSampleVsHeldOut', 'aurocTrainInSample'))}、"
    f"Brier {num(in_sample['brierTrainInSample'], P + ('inSampleVsHeldOut', 'brierTrainInSample'))}，"
    f"对应留出集 {num(in_sample['aurocTest'], P + ('inSampleVsHeldOut', 'aurocTest'))} 与 "
    f"{num(in_sample['brierTest'], P + ('inSampleVsHeldOut', 'brierTest'))}。"
    "区分度几乎没掉，Brier 则明显上升：过拟合的幅度有限，但这是同一来源内部的对比，不构成外部有效性的证据。"
)
add("")
add("表 2 阈值 0.5 的混淆矩阵（测试集）")
add("")
add("|  | 预测恶性 | 预测良性 |")
add("| --- | --- | --- |")
add(
    f"| 实际恶性 | {count(op05['confusion']['truePositive'], P + ('operatingPoints', '0.5', 'confusion', 'truePositive'))} "
    f"| {count(op05['confusion']['falseNegative'], P + ('operatingPoints', '0.5', 'confusion', 'falseNegative'))} |"
)
add(
    f"| 实际良性 | {count(op05['confusion']['falsePositive'], P + ('operatingPoints', '0.5', 'confusion', 'falsePositive'))} "
    f"| {count(op05['confusion']['trueNegative'], P + ('operatingPoints', '0.5', 'confusion', 'trueNegative'))} |"
)
add("")
add(
    f"敏感度 {num(op05['sensitivity'], P + ('operatingPoints', '0.5', 'sensitivity'))}"
    f"（95%CI {ci(op05['sensitivityCI95'])}），特异度 {num(op05['specificity'], P + ('operatingPoints', '0.5', 'specificity'))}"
    f"（{ci(op05['specificityCI95'])}），阳性预测值 {num(op05['positivePredictiveValue'], P + ('operatingPoints', '0.5', 'positivePredictiveValue'))}"
    f"（{ci(op05['positivePredictiveValueCI95'])}），阴性预测值 {num(op05['negativePredictiveValue'], P + ('operatingPoints', '0.5', 'negativePredictiveValue'))}"
    f"（{ci(op05['negativePredictiveValueCI95'])}），准确率 {num(op05['accuracy'], P + ('operatingPoints', '0.5', 'accuracy'))}。"
    f"共 {count(len(primary['errorsAt0.5']), ('x', 'nErrors')) if False else len(primary['errorsAt0.5'])} 例判错。"
)
add("")
add("表 3 阈值敏感性（测试集；阈值不是调出来的，只用于看结论对切点的依赖）")
add("")
add("| 阈值 | 敏感度 | 特异度 | 阳性预测值 |")
add("| --- | --- | --- | --- |")
for label in ("0.1", "0.3", "0.5", "0.7", "0.9"):
    row = primary["thresholdSensitivity"][label]
    add(
        f"| {label} | {num(row['sensitivity'], P + ('thresholdSensitivity', label, 'sensitivity'))} "
        f"| {num(row['specificity'], P + ('thresholdSensitivity', label, 'specificity'))} "
        f"| {num(row['positivePredictiveValue'], P + ('thresholdSensitivity', label, 'positivePredictiveValue'))} |"
    )
add("")
thr = primary["thresholdSensitivity"]
tp05, fp05 = op05["confusion"]["truePositive"], op05["confusion"]["falsePositive"]
tp03, fp03 = thr["0.3"]["confusion"]["truePositive"], thr["0.3"]["confusion"]["falsePositive"]
tp01, fp01 = thr["0.1"]["confusion"]["truePositive"], thr["0.1"]["confusion"]["falsePositive"]
add(
    f"把阈值从 0.5 降到 0.3，敏感度不变（都是 {tp03} 例正确识别），假阳性从 {fp05} 例增到 {fp03} 例；"
    f"降到 0.1 才多识别 {tp01 - tp05} 例恶性，代价是假阳性增到 {fp01} 例。"
    f"两个漏诊样本的概率分别为 {num(primary['errorsAt0.5'][0]['pMalignant'], P + ('errorsAt0.5', 0, 'pMalignant'))}"
    f" 与 {num(primary['errorsAt0.5'][1]['pMalignant'], P + ('errorsAt0.5', 1, 'pMalignant'))}，靠移动切点救不回来；"
    "在这份数据上换阈值买不到多少敏感度，只会用假阳性去换。"
)
add("")
add(
    f"补充：用训练集折外预测确定的 95% 敏感度切点为 {num(RESULTS['thresholds']['trainCV95Sensitivity'], ('thresholds', 'trainCV95Sensitivity'))}"
    f"（折外敏感度 {num(RESULTS['thresholds']['trainCV95SensitivityOofSensitivity'], ('thresholds', 'trainCV95SensitivityOofSensitivity'))}），"
    "用到留出集得到的混淆矩阵与 0.5 相同。这不是调出来的测试集阈值，只是说明结论不依赖切点的第二位小数。"
)
add("")
add("### 指定切点 0.3 的工作点")
add("")
T3 = P + ("thresholdSensitivity", "0.3")
row3 = primary["thresholdSensitivity"]["0.3"]
c3 = row3["confusion"]
add(
    "按“恶性概率 ≥ 0.3 判为阳性”重新标记 **同一批 171 例留出样本** 的既有预测。"
    "模型、特征、训练/测试划分与 `predictions.csv` 中的概率都没有改动，也没有重新训练；"
    "0.3 是本次指定的报告切点，不是在本数据上搜索或优化得到的，不能当作最优阈值，也不建议据此改临床决策规则。"
)
add("")
add("表 3a 阈值 0.3 的混淆矩阵（测试集，n = %s）" % count(primary["n"]["test"], P + ("n", "test")))
add("")
add("|  | 预测恶性（p ≥ 0.3） | 预测良性（p < 0.3） |")
add("| --- | --- | --- |")
add(
    f"| 实际恶性 | {count(c3['truePositive'], T3 + ('confusion', 'truePositive'))} | "
    f"{count(c3['falseNegative'], T3 + ('confusion', 'falseNegative'))} |"
)
add(
    f"| 实际良性 | {count(c3['falsePositive'], T3 + ('confusion', 'falsePositive'))} | "
    f"{count(c3['trueNegative'], T3 + ('confusion', 'trueNegative'))} |"
)
add("")
add(
    f"敏感度 {num(row3['sensitivity'], T3 + ('sensitivity',))}（95%CI {ci(row3['sensitivityCI95'])}），"
    f"特异度 {num(row3['specificity'], T3 + ('specificity',))}（{ci(row3['specificityCI95'])}），"
    f"阳性预测值 {num(row3['positivePredictiveValue'], T3 + ('positivePredictiveValue',))}"
    f"（{ci(row3['positivePredictiveValueCI95'])}），阴性预测值 {num(row3['negativePredictiveValue'], T3 + ('negativePredictiveValue',))}"
    f"（{ci(row3['negativePredictiveValueCI95'])}），准确率 {num(row3['accuracy'], T3 + ('accuracy',))}。"
)
add("")
add(
    f"与 0.5 相比，阳性判定从 {count(op05['confusion']['truePositive'] + op05['confusion']['falsePositive'], P + ('x', 'positives05')) if False else op05['confusion']['truePositive'] + op05['confusion']['falsePositive']} 例变成 "
    f"{count(c3['truePositive'] + c3['falsePositive'], P + ('x', 'positives03')) if False else c3['truePositive'] + c3['falsePositive']} 例："
    f"多出的 {c3['falsePositive'] - op05['confusion']['falsePositive']} 例全部是良性，恶性识别数不变（"
    f"{c3['truePositive']} 例，敏感度仍是 {num(row3['sensitivity'], T3 + ('sensitivity',))}）。"
    f"因此在这个切点上，代价是特异度（{num(op05['specificity'], P + ('operatingPoints', '0.5', 'specificity'))} → "
    f"{num(row3['specificity'], T3 + ('specificity',))}）与阳性预测值（"
    f"{num(op05['positivePredictiveValue'], P + ('operatingPoints', '0.5', 'positivePredictiveValue'))} → "
    f"{num(row3['positivePredictiveValue'], T3 + ('positivePredictiveValue',))}）下降，换不到额外发现的恶性。"
    "该结论只针对这批 171 例，不同患病率下阳性预测值会变化。"
)
add("")
add("![留出集 ROC 与校准](model-performance.svg)")
add("")
add(
    "图：左为测试集 ROC；右为 10 分箱校准图，点面积表示箱内例数，竖线为事件率的 Wilson 95%CI。"
    "两端的点贴住对角线，中间几乎没有点。"
)
add("")

add("## 4 哪些特征在推动预测")
add("")
add("表 4 标准化系数与 OR（每 1 个标准差；bootstrap 200 次）")
add("")
add("| 特征 | 系数/SD | OR（95%CI） | 符号稳定率 |")
add("| --- | --- | --- | --- |")
for k, row in enumerate(coef["l2Rows"][:8]):
    add(
        f"| {row['feature']} | {num(row['coefPerSD'], ('coefficients', 'l2Rows', k, 'coefPerSD'), 2)} "
        f"| {num(row['oddsRatioPerSD'], ('coefficients', 'l2Rows', k, 'oddsRatioPerSD'), 2)}"
        f"（{num(row['oddsRatioCI95Bootstrap'][0], ('coefficients', 'l2Rows', k, 'oddsRatioCI95Bootstrap', 0), 2)}–"
        f"{num(row['oddsRatioCI95Bootstrap'][1], ('coefficients', 'l2Rows', k, 'oddsRatioCI95Bootstrap', 1), 2)}） "
        f"| {num(row['bootstrapSameSignShare'], ('coefficients', 'l2Rows', k, 'bootstrapSameSignShare'), 2)} |"
    )
add("")
add(
    f"OR 是“该特征每高 1 个标准差、其余特征不变时恶性几率的变化倍数”，是关联量，不是因果效应。"
    f"训练集中有 {count(diag['featurePairsAbsRAtLeast098'], ('diagnostics', 'featurePairsAbsRAtLeast098'))} 对特征 |r| ≥ 0.98"
    f"（最高 {num(diag['maxAbsFeatureCorrelationTrain'], ('diagnostics', 'maxAbsFeatureCorrelationTrain'))}，如 radius 与 perimeter、area），"
    "因此单个系数的大小和符号取决于同组里还放了谁，不能解读为“半径本身的作用”。"
    f"L1 版本把 {count(len(coef['l1ZeroedFeatures']), ('x', 'l1Zeroed')) if False else len(coef['l1ZeroedFeatures'])} 个特征压到 0、只保留 "
    f"{count(coef['l1NSelected'], ('coefficients', 'l1NSelected'))} 个，测试集 AUROC 与 Brier 基本不变，"
    "说明大量特征是冗余的，30 个系数并不等于 30 条独立信息。"
)
add("")

add("## 5 可靠性判断：能信到什么程度")
add("")
add(
    "1. **内部有效，外部未知。** 留出集与训练集同源、同一次导出、按行随机划分；没有时间外推，也没有跨机构验证。"
    "这是本报告最重要的限制。"
)
add(
    f"2. **概率几乎没有中间值。** 测试集 {count(shape['testRowsBelow0.1'], P + ('probabilityShape', 'testRowsBelow0.1'))} 例 p ≤ 0.1、"
    f"{count(shape['testRowsAbove0.9'], P + ('probabilityShape', 'testRowsAbove0.9'))} 例 p ≥ 0.9，"
    f"只有 {count(shape['testRowsBetween0.1And0.9'], P + ('probabilityShape', 'testRowsBetween0.1And0.9'))} 例落在 0.1–0.9。"
    "校准只能被两端的数据约束，0.2–0.8 区间的概率不能当作已验证的个体风险。"
)
add(
    f"3. **精确性有限。** 恶性只有 {count(primary['n']['eventsTest'], P + ('n', 'eventsTest'))} 例，敏感度 95%CI 为 "
    f"{num(op05['sensitivityCI95'][0], P + ('operatingPoints', '0.5', 'sensitivityCI95', 0))}–"
    f"{num(op05['sensitivityCI95'][1], P + ('operatingPoints', '0.5', 'sensitivityCI95', 1))}；"
    "换个随机划分，点估计会有可见移动，报告中不应引用点估计的小数位。"
)
errors = primary["errorsAt0.5"]
idx = {e["record_id"]: k for k, e in enumerate(errors)}
fn_rows = sorted([e for e in errors if e["kind"] == "false negative"], key=lambda e: e["pMalignant"])
fp_rows = [e for e in errors if e["kind"] == "false positive"]
add(
    f"4. **漏诊都落在概率最低端。** 记录 {fn_rows[0]['record_id']}（p = "
    f"{num(fn_rows[0]['pMalignant'], P + ('errorsAt0.5', idx[fn_rows[0]['record_id']], 'pMalignant'))}）与记录 "
    f"{fn_rows[1]['record_id']}（p = {num(fn_rows[1]['pMalignant'], P + ('errorsAt0.5', idx[fn_rows[1]['record_id']], 'pMalignant'))}）被判为良性，"
    f"误判的良性记录 {fp_rows[0]['record_id']} 的 p = "
    f"{num(fp_rows[0]['pMalignant'], P + ('errorsAt0.5', idx[fp_rows[0]['record_id']], 'pMalignant'))}。"
    "这类样本靠调阈值救不回来，只能靠补充特征或改进图像流程。"
)
add(
    f"5. **阳性预测值随患病率变化。** 本样本恶性占 {num(prof['malignantPercent'], ('profile', 'malignantPercent'), 1, '%')}"
    f"（富集样本），PPV {num(op05['positivePredictiveValue'], P + ('operatingPoints', '0.5', 'positivePredictiveValue'))} 是在这个比例下得到的；"
    "真实筛查人群中恶性比例低得多，同样的敏感度/特异度会给出低得多的 PPV。"
)
add(
    "6. **患者独立性未验证。** 缺患者标识，同一患者的多个样本可能同时进入训练与测试，而无法被发现；"
    "因此本条审计中的 fit-scope 与重复观测检查是 not_checked，不能声称“已排除泄漏”。"
)
add(
    "7. **特征依赖原始数字化流程。** 字典未给单位、染色、扫描仪与分割参数；换一套图像处理流程，"
    "这些数值的分布会变，模型与阈值都需要重新校准。"
)
add(
    "8. **未做的分析。** 没有外部校准、决策曲线、时间验证、亚组（年龄/设备）公平性分析，也没有与其他模型（如树模型）的对比；"
    "线性模型在强共线下系数不稳定，这是可解释性的代价。"
)
add("")

add("## 6 适用与不适用")
add("")
add(
    "- 适用：作为该数据集的**基线模型**与教学示例；作为后续特征工程、非线性模型或外部验证的对照；"
    "在相同数据分布内做探索性风险分层。"
)
add(
    "- 不适用：临床诊断或筛查决策、跨机构直接部署、向个体给出“恶性概率为 x%”的风险沟通、"
    "替代病理或影像科判断。"
)
add("")

add("## 7 文件与复现")
add("")
add("| 文件 | 内容 |")
add("| --- | --- |")
add("| `analysis.py` | 全部建模与评估代码（数据检查、划分、调参、指标、校准、系数、图、结果文件） |")
add("| `analysis-results.json` | 结构化结果：设计、诊断、两套模型、阈值、系数 |")
add("| `analysis-run.json` | 执行回执：脚本与数据哈希、库版本、运行记录 |")
add("| `predictions.csv` | 569 行逐条预测：划分、真实标签、`p_malignant`、0.5 判定、L1 预测、训练折外概率 |")
add("| `fitted-state.json` / `fitted-model.joblib` | 拟合状态：标准化参数、系数、截距、C、阈值、软件版本 |")
add("| `prediction-audit.json` | 逐条预测的结构审计与重新计算的一致性结果 |")
add("| `operating-point-0.3.json` / `verify_thr03.py` | 指定切点 0.3 的混淆矩阵与指标（由 `predictions.csv` 重算，不重新拟合） |")
add("| `audit.py` / `report.py` | 审计脚本与报告生成脚本 |")
add("| `model-performance.svg` | ROC 与校准图（脚本生成，无外部绘图库依赖） |")
add("")
sw = RESULTS["software"]
add(
    f"环境：Python {sw['python']}，scikit-learn {sw['sklearn']}，numpy {sw['numpy']}，pandas {sw['pandas']}，"
    f"scipy {sw['scipy']}，statsmodels {sw['statsmodels']}。"
)
add("")
add("复现：在包含 `data/breast-cancer.csv` 的工作目录下执行 `python analysis.py`，再执行 `python audit.py` 与 `python report.py`。")
add("")
add(
    "预测一致性：测试集 AUROC 与 Brier 由 `predictions.csv` 独立重算，与 `analysis-results.json` 一致"
    "（不一致项：" + str(len(AUDIT['localChecks']['mismatches'])) + "）；"
    "训练/测试记录键无重叠，5 个学习阶段的拟合行号都等于训练行。"
    f"审计整体判定为 `{AUDIT['audit']['validation']['status']}`：未发现划分重叠、重复记录、标签方向或预测文件问题，"
    "但因缺少 observation key，fit-scope 与重复观测检查为 not_checked。"
)
add("")

add("## 8 关键假设")
add("")
add("- 标签语义按数据字典：`breast_cancer_yn` 0 = 恶性；据此拟合 P(恶性)，未反转概率。")
add("- 一行视为一个独立肿瘤；不假设患者层面的独立性，也无法检验。")
add("- 全部 30 个特征进入主模型；未做特征筛选（L1 仅作对照）。")
add("- 随机 70/30 分层划分是内部验证；测试集只用一次。")
add("- 阈值 0.5 是默认值，不是临床切点；报告中不推荐任何临床阈值。")

text = "\n".join(lines) + "\n"
(HERE / "statistical-report.md").write_text(text, encoding="utf-8")
(HERE / "report-bindings.json").write_text(json.dumps({"bindings": BINDINGS}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"wrote report ({len(text)} chars), {len(BINDINGS)} numeric bindings")
