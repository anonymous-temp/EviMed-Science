#!/usr/bin/env python3
"""Recompute the operating point at P(malignant) >= 0.3 from the stored predictions.

No model is refitted: the probabilities are read from predictions.csv exactly as
written by the original run, relabelled at the specified threshold, and the
confusion matrix and metrics are recomputed from those labels. The recomputed
values are then compared with the 0.3 row already stored in
analysis-results.json, so a discrepancy would be visible rather than silent.

Writes operating-point-0.3.json.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
THRESHOLD = 0.3
Z = 1.959963984540054


def wilson(k: int, n: int) -> list[float]:
    p = k / n
    denom = 1 + Z * Z / n
    centre = (p + Z * Z / (2 * n)) / denom
    half = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / denom
    return [round(max(0.0, centre - half), 4), round(min(1.0, centre + half), 4)]


pred = pd.read_csv(HERE / "predictions.csv")
test = pred[pred["split"] == "test"].copy()
event = (test["y_true"] == 0).astype(int)          # 0 in the source column means malignant
positive = (test["p_malignant"] >= THRESHOLD).astype(int)

tp = int(((positive == 1) & (event == 1)).sum())
fn = int(((positive == 0) & (event == 1)).sum())
fp = int(((positive == 1) & (event == 0)).sum())
tn = int(((positive == 0) & (event == 0)).sum())

sensitivity = round(tp / (tp + fn), 4)
specificity = round(tn / (tn + fp), 4)
ppv = round(tp / (tp + fp), 4)
npv = round(tn / (tn + fn), 4)
accuracy = round((tp + tn) / len(test), 4)

out = {
    "schemaVersion": 1,
    "kind": "operating_point",
    "threshold": THRESHOLD,
    "rule": "predict malignant when p_malignant >= 0.3",
    "thresholdRole": "user-specified reporting cut-point; not selected or optimised on any data",
    "modelRefitted": False,
    "sourceOfProbabilities": "predictions.csv (unchanged fitted model)",
    "cohort": {
        "split": "test",
        "n": int(len(test)),
        "malignant": int(event.sum()),
        "benign": int((1 - event).sum()),
    },
    "confusion": {"truePositive": tp, "falsePositive": fp, "trueNegative": tn, "falseNegative": fn},
    "metrics": {
        "sensitivity": {"value": sensitivity, "ci95": wilson(tp, tp + fn)},
        "specificity": {"value": specificity, "ci95": wilson(tn, tn + fp)},
        "positivePredictiveValue": {"value": ppv, "ci95": wilson(tp, tp + fp)},
        "negativePredictiveValue": {"value": npv, "ci95": wilson(tn, tn + fn)},
        "accuracy": {"value": accuracy, "ci95": wilson(tp + tn, len(test))},
    },
}

stored = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))["analyses"][0]["thresholdSensitivity"]["0.3"]
checks = {
    "confusion": stored["confusion"] == out["confusion"],
    "sensitivity": stored["sensitivity"] == sensitivity,
    "specificity": stored["specificity"] == specificity,
    "positivePredictiveValue": stored["positivePredictiveValue"] == ppv,
    "sensitivityCI95": stored["sensitivityCI95"] == out["metrics"]["sensitivity"]["ci95"],
    "specificityCI95": stored["specificityCI95"] == out["metrics"]["specificity"]["ci95"],
    "positivePredictiveValueCI95": stored["positivePredictiveValueCI95"] == out["metrics"]["positivePredictiveValue"]["ci95"],
}
out["crossCheck"] = {"against": "analysis-results.json analyses[0].thresholdSensitivity['0.3']", "checks": checks, "allMatch": all(checks.values())}

(HERE / "operating-point-0.3.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"confusion": out["confusion"], "sensitivity": sensitivity, "specificity": specificity, "ppv": ppv, "npv": npv, "accuracy": accuracy, "allMatch": out["crossCheck"]["allMatch"]}, ensure_ascii=False))
