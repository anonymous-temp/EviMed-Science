#!/usr/bin/env python3
"""Check every number inserted into statistical-report.md against its source path.

report.py records, for each formatted number, the exact JSON path it came from
and the value as printed. This script resolves those paths in
analysis-results.json and compares, so a typo in the report writer cannot pass
silently. Writes report-number-check.json.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(Path(os.environ.get("EVIMED_CAPABILITY_SKILLS_DIR", "/opt/evimed/capability-skills")) / "statistical-analysis" / "scripts"))
from analysis_checks import compare_reported_numbers  # noqa: E402

RESULTS = json.loads((HERE / "analysis-results.json").read_text(encoding="utf-8"))
BINDINGS = json.loads((HERE / "report-bindings.json").read_text(encoding="utf-8"))["bindings"]

report = compare_reported_numbers(RESULTS, BINDINGS)
(HERE / "report-number-check.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

bad = [c for c in report["comparisons"] if c["status"] != "match"]
print(json.dumps({"status": report["status"], "counts": report["counts"], "problems": bad[:10]}, ensure_ascii=False, indent=2))
sys.exit(1 if bad else 0)
