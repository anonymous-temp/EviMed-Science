#!/usr/bin/env python3
"""Interpretable baseline model for malignant-probability estimation on WDBC.

Design choices (fixed before looking at held-out results):
- Event is malignancy. Source column ``breast_cancer_yn`` codes 0 = malignant,
  1 = benign (data/wdbc-dictionary.md), so the fitted target is
  ``z = 1 if breast_cancer_yn == 0 else 0`` and every predicted probability in
  this package is P(malignant).
- One row = one tumour (FNA sample). The extract carries no patient identifier,
  so rows are treated as independent observations and the original row index is
  used only as a record key.
- Fixed seed, stratified 70/30 train/test split. Test rows are touched once.
- Primary model: standardise the 30 features (fit on training rows only) and fit
  an L2-penalised logistic regression. The penalty strength C is chosen by
  5-fold stratified cross-validation on the training rows, minimising log loss.
- Sensitivity model: L1-penalised logistic regression, same split and selection
  rule, used to see whether a sparse subset carries the same signal.
- Operating points: 0.5 (a priori default) and a 95%-sensitivity threshold taken
  from out-of-fold training predictions, never from the test rows.

Outputs (written next to this script): analysis-results.json, predictions.csv,
fitted-state.json, fitted-model.joblib, model-performance.svg.
"""
from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    log_loss,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import StratifiedKFold, cross_val_predict, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.proportion import proportion_confint

import statsmodels.api as sm
import joblib

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
DATA = WORKSPACE / "data" / "breast-cancer.csv"
SEED = 20261026
C_GRID = [0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]
N_BOOT_AUC = 2000
N_BOOT_COEF = 200
CAL_BINS = 10


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def r4(value):
    if value is None:
        return None
    return float(round(float(value), 4))


def make_pipeline(penalty: str, C: float, seed: int) -> Pipeline:
    solver = "liblinear" if penalty == "l1" else "lbfgs"
    return Pipeline(
        [
            ("scaler", StandardScaler()),
            (
                "logit",
                LogisticRegression(
                    penalty=penalty,
                    C=C,
                    solver=solver,
                    max_iter=5000,
                    random_state=seed,
                ),
            ),
        ]
    )


def select_C(X, z, penalty: str, folds, seed: int):
    cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed + 1)
    curve = []
    for C in C_GRID:
        losses = []
        for fit_idx, val_idx in cv.split(X, z):
            pipe = make_pipeline(penalty, C, seed)
            pipe.fit(X[fit_idx], z[fit_idx])
            prob = pipe.predict_proba(X[val_idx])[:, 1]
            losses.append(log_loss(z[val_idx], prob, labels=[0, 1]))
        curve.append({"C": C, "cvLogLossMean": r4(np.mean(losses)), "cvLogLossSd": r4(np.std(losses))})
    best = min(curve, key=lambda row: (row["cvLogLossMean"], -row["C"]))
    return best["C"], curve, cv


def operating_point(z, prob, threshold, positives="malignant"):
    pred = prob >= threshold
    tp = int(np.sum((z == 1) & pred))
    fp = int(np.sum((z == 0) & pred))
    fn = int(np.sum((z == 1) & ~pred))
    tn = int(np.sum((z == 0) & ~pred))
    sens = tp / (tp + fn) if tp + fn else None
    spec = tn / (tn + fp) if tn + fp else None
    ppv = tp / (tp + fp) if tp + fp else None
    npv = tn / (tn + fn) if tn + fn else None

    def wilson(k, n):
        if n == 0:
            return None
        low, high = proportion_confint(k, n, alpha=0.05, method="wilson")
        return [r4(low), r4(high)]

    return {
        "threshold": r4(threshold),
        "rule": "predict malignant when p >= threshold",
        "positives": positives,
        "confusion": {"truePositive": tp, "falsePositive": fp, "trueNegative": tn, "falseNegative": fn},
        "sensitivity": r4(sens),
        "sensitivityCI95": wilson(tp, tp + fn),
        "specificity": r4(spec),
        "specificityCI95": wilson(tn, tn + fp),
        "positivePredictiveValue": r4(ppv),
        "positivePredictiveValueCI95": wilson(tp, tp + fp),
        "negativePredictiveValue": r4(npv),
        "negativePredictiveValueCI95": wilson(tn, tn + fn),
        "accuracy": r4((tp + tn) / len(z)),
    }


def auc_ci(z, prob, rng, n_boot=N_BOOT_AUC):
    z = np.asarray(z)
    pos_idx = np.where(z == 1)[0]
    neg_idx = np.where(z == 0)[0]
    estimates = []
    for _ in range(n_boot):
        sample = np.concatenate(
            [rng.choice(pos_idx, size=len(pos_idx), replace=True), rng.choice(neg_idx, size=len(neg_idx), replace=True)]
        )
        estimates.append(roc_auc_score(z[sample], prob[sample]))
    return [r4(np.quantile(estimates, 0.025)), r4(np.quantile(estimates, 0.975))], r4(np.std(estimates, ddof=1))


def calibration_regression(z, prob):
    eps = 1e-12
    p = np.clip(prob, eps, 1 - eps)
    logit_p = np.log(p / (1 - p))
    try:
        res = sm.Logit(np.asarray(z, dtype=float), sm.add_constant(logit_p)).fit(disp=0, method="newton", maxiter=200)
    except Exception as exc:  # separation or non-convergence
        return {"status": "unavailable", "reason": f"calibration_glm_failed: {type(exc).__name__}"}
    params = res.params
    ci = res.conf_int()
    if not all(np.isfinite(params)) or not all(np.isfinite(np.asarray(ci).ravel())):
        return {"status": "unavailable", "reason": "nonfinite_calibration_estimates"}
    return {
        "status": "complete",
        "method": "logit(event) = intercept + slope * logit(predicted probability), fitted on held-out rows",
        "intercept": r4(params[0]),
        "interceptCI95": [r4(ci[0][0]), r4(ci[0][1])],
        "slope": r4(params[1]),
        "slopeCI95": [r4(ci[1][0]), r4(ci[1][1])],
        "n": int(len(z)),
        "converged": bool(res.mle_retvals.get("converged", True)),
    }


def calibration_bins(z, prob, bins=CAL_BINS):
    edges = np.linspace(0.0, 1.0, bins + 1)
    out = []
    for i in range(bins):
        upper_inclusive = i == bins - 1
        mask = (prob >= edges[i]) & (prob <= edges[i + 1] if upper_inclusive else prob < edges[i + 1])
        count = int(np.sum(mask))
        events = int(np.sum(z[mask]))
        row = {
            "lower": r4(edges[i]),
            "upper": r4(edges[i + 1]),
            "upperInclusive": upper_inclusive,
            "count": count,
            "events": events,
            "meanProbability": r4(prob[mask].mean()) if count else None,
            "eventRate": r4(events / count) if count else None,
        }
        if count and 0 < events < count:
            low, high = proportion_confint(events, count, alpha=0.05, method="wilson")
            row["eventRateCI95"] = [r4(low), r4(high)]
        elif count:
            row["eventRateCI95"] = None
        out.append(row)
    return out


def evaluate(name, pipe, Xtr, ztr, Xte, zte, thresholds, rng):
    prob_tr = pipe.predict_proba(Xtr)[:, 1]
    prob_te = pipe.predict_proba(Xte)[:, 1]
    auroc = r4(roc_auc_score(zte, prob_te))
    ci, boot_sd = auc_ci(zte, prob_te, rng)
    method = (
        "L2-penalised logistic regression" if name.startswith("l2") else "L1-penalised logistic regression"
    ) + " on 30 standardised features; penalty C by 5-fold stratified CV (log loss) on training rows only"
    result = {
        "id": name,
        "status": "complete",
        "method": method,
        "estimand": "P(malignant | 30 image-derived features)",
        "estimate": auroc,
        "estimateMetric": "auroc on held-out test rows",
        "interval": ci,
        "intervalLevel": 0.95,
        "pValue": None,
        "warnings": [],
        "n": {"train": int(len(ztr)), "eventsTrain": int(np.sum(ztr)), "test": int(len(zte)), "eventsTest": int(np.sum(zte))},
        "discrimination": {
            "auroc": auroc,
            "aurocCI95Bootstrap": ci,
            "aurocBootstrapSd": boot_sd,
            "averagePrecision": r4(average_precision_score(zte, prob_te)),
            "testPrevalence": r4(np.mean(zte)),
            "trainAurocInSample": r4(roc_auc_score(ztr, prob_tr)),
        },
        "overall": {
            "brier": r4(brier_score_loss(zte, prob_te)),
            "brierSkillScoreVsTrainPrevalence": r4(1 - brier_score_loss(zte, prob_te) / brier_score_loss(zte, np.full_like(prob_te, np.mean(ztr)))),
            "logLoss": r4(log_loss(zte, prob_te, labels=[0, 1])),
            "brierTrainInSample": r4(brier_score_loss(ztr, prob_tr)),
        },
        "calibration": calibration_regression(zte, prob_te),
        "calibrationBins": calibration_bins(zte, prob_te),
        "operatingPoints": {},
        "software": {"sklearn": sklearn.__version__, "numpy": np.__version__, "scipy": scipy.__version__},
    }
    for label, thr in thresholds.items():
        result["operatingPoints"][label] = operating_point(zte, prob_te, thr)
    middle = int(np.sum((prob_te > 0.1) & (prob_te < 0.9)))
    if middle < 0.3 * len(prob_te):
        result["warnings"].append(
            f"held-out probabilities are near step-shaped: {middle} of {len(prob_te)} test rows fall between 0.1 and 0.9, "
            "so mid-range calibration is weakly identified"
        )
    return result, prob_tr, prob_te


def make_svg(path: Path, zte, prob_te, bins, title_note: str):
    """Dependency-free two-panel SVG: ROC and calibration on held-out rows."""
    width, height = 860, 400
    panels = {
        "roc": (70, 60, 300, 280),
        "cal": (520, 60, 300, 280),
    }
    def mapx(panel, v):
        x0, y0, w, h = panels[panel]
        return x0 + v * w
    def mapy(panel, v):
        x0, y0, w, h = panels[panel]
        return y0 + (1 - v) * h

    fpr, tpr, _ = roc_curve(zte, prob_te)
    auc = roc_auc_score(zte, prob_te)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" font-family="Helvetica, Arial, sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="20" y="22" font-size="16" font-weight="600" fill="#1f2933">Held-out test performance ({title_note})</text>',
    ]
    # axes for both panels
    for panel, xtitle, ytitle, title in (
        ("roc", "1 - specificity", "sensitivity", f"ROC (AUC = {auc:.3f})"),
        ("cal", "predicted P(malignant)", "observed malignant rate", "Calibration (10 bins)"),
    ):
        x0, y0, w, h = panels[panel]
        parts.append(f'<rect x="{x0}" y="{y0}" width="{w}" height="{h}" fill="#fbfcfd" stroke="#c8d0d8"/>')
        for k in range(1, 5):
            gx = x0 + k * w / 5
            gy = y0 + k * h / 5
            parts.append(f'<line x1="{gx:.1f}" y1="{y0}" x2="{gx:.1f}" y2="{y0+h}" stroke="#e6ebef"/>')
            parts.append(f'<line x1="{x0}" y1="{gy:.1f}" x2="{x0+w}" y2="{gy:.1f}" stroke="#e6ebef"/>')
        for k in (0, 0.5, 1):
            parts.append(f'<text x="{x0 + k*w:.1f}" y="{y0+h+16}" font-size="10" fill="#52606d" text-anchor="middle">{k:g}</text>')
            parts.append(f'<text x="{x0-8}" y="{y0+(1-k)*h+3:.1f}" font-size="10" fill="#52606d" text-anchor="end">{k:g}</text>')
        parts.append(f'<text x="{x0+w/2:.1f}" y="{y0+h+34}" font-size="11" fill="#52606d" text-anchor="middle">{xtitle}</text>')
        cy_label = y0 + h / 2
        parts.append(f'<text x="{x0-52}" y="{cy_label:.1f}" transform="rotate(-90 {x0-52} {cy_label:.1f})" font-size="11" fill="#52606d" text-anchor="middle">{ytitle}</text>')
        parts.append(f'<text x="{x0}" y="{y0-18}" font-size="12" font-weight="600" fill="#1f2933">{title}</text>')

    x0, y0, w, h = panels["roc"]
    parts.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0}" stroke="#9aa5b1" stroke-dasharray="4 4"/>')
    points = " ".join(f"{mapx('roc', f):.1f},{mapy('roc', t):.1f}" for f, t in zip(fpr, tpr))
    parts.append(f'<polyline points="{points}" fill="none" stroke="#1b6ca8" stroke-width="2.2"/>')

    x0, y0, w, h = panels["cal"]
    parts.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0}" stroke="#9aa5b1" stroke-dasharray="4 4"/>')
    parts.append(f'<text x="{x0+8}" y="{y0+16}" font-size="10" fill="#9aa5b1">perfect calibration</text>')
    for row in bins:
        if not row["count"] or row["meanProbability"] is None:
            continue
        cx = mapx("cal", row["meanProbability"])
        cy = mapy("cal", row["eventRate"])
        radius = 3 + 9 * (row["count"] / 40) ** 0.5
        parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{min(radius, 12):.1f}" fill="#1b6ca8" fill-opacity="0.55" stroke="#1b6ca8"/>')
        if row.get("eventRateCI95"):
            lo, hi = row["eventRateCI95"]
            parts.append(f'<line x1="{cx:.1f}" y1="{mapy("cal", max(lo,0)):.1f}" x2="{cx:.1f}" y2="{mapy("cal", min(hi,1)):.1f}" stroke="#1b6ca8" stroke-width="1" stroke-opacity="0.7"/>')
    parts.append(f'<text x="{x0+w-6}" y="{y0+h-8}" font-size="10" fill="#52606d" text-anchor="end">point area = bin count</text>')
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")


def main() -> int:
    data_hash = sha256(DATA)
    raw = pd.read_csv(DATA)
    record_id = raw.iloc[:, 0].astype(int)
    feature_names = [c for c in raw.columns if c not in (raw.columns[0], "breast_cancer_yn")]
    X_df = raw[feature_names]
    y_orig = raw["breast_cancer_yn"].astype(int)
    z = (y_orig == 0).astype(int)  # 1 = malignant (source code 0)

    profile = {
        "rows": int(len(raw)),
        "columns": int(raw.shape[1]),
        "nFeatures": len(feature_names),
        "missingValues": int(raw.isna().sum().sum()),
        "duplicateRowsAllColumns": int(raw.duplicated().sum()),
        "duplicateRowsOnFeatures": int(raw.duplicated(subset=feature_names).sum()),
        "classCounts": {
            "malignant_source0": int((y_orig == 0).sum()),
            "benign_source1": int((y_orig == 1).sum()),
        },
        "malignantPrevalence": r4((y_orig == 0).mean()),
        "malignantPercent": r4(100 * (y_orig == 0).mean()),
        "nonNegativeFeatures": bool((X_df >= 0).all().all()),
        "recordIdRange": [int(record_id.min()), int(record_id.max())],
        "recordIdUnique": bool(record_id.is_unique),
    }

    X = X_df.to_numpy(dtype=float)
    idx = np.arange(len(raw))
    train_idx, test_idx = train_test_split(idx, test_size=0.30, random_state=SEED, stratify=z)
    train_idx = np.sort(train_idx)
    test_idx = np.sort(test_idx)
    Xtr, Xte = X[train_idx], X[test_idx]
    ztr, zte = z.to_numpy()[train_idx], z.to_numpy()[test_idx]

    # Collinearity is a property of the training design, so report it there.
    corr = np.corrcoef(Xtr, rowvar=False)
    abs_corr = np.abs(corr)
    np.fill_diagonal(abs_corr, 0.0)
    pair_max = abs_corr.max()
    high_pairs = []
    for i in range(len(feature_names)):
        for j in range(i + 1, len(feature_names)):
            if abs_corr[i, j] >= 0.98:
                high_pairs.append({"a": feature_names[i], "b": feature_names[j], "r": r4(corr[i, j])})
    high_pairs.sort(key=lambda row: -abs(row["r"]))
    diagnostics = {
        "trainRows": int(len(train_idx)),
        "testRows": int(len(test_idx)),
        "trainMalignant": int(ztr.sum()),
        "testMalignant": int(zte.sum()),
        "maxAbsFeatureCorrelationTrain": r4(pair_max),
        "featurePairsAbsRAtLeast098": len(high_pairs),
        "topCollinearPairs": high_pairs[:8],
        "trainTestIdOverlap": int(len(set(record_id.iloc[train_idx]) & set(record_id.iloc[test_idx]))),
        "testIdsSubsetOfTrain": bool(set(record_id.iloc[test_idx]).issubset(set(record_id.iloc[train_idx]))),
    }

    models = {}
    curves = {}
    selected = {}
    for penalty, model_id in (("l2", "l2_logistic_primary"), ("l1", "l1_logistic_sensitivity")):
        best_C, curve, cv = select_C(Xtr, ztr, penalty, folds=5, seed=SEED)
        selected[penalty] = best_C
        curves[penalty] = curve
        pipe = make_pipeline(penalty, best_C, SEED)
        oof = cross_val_predict(pipe, Xtr, ztr, cv=cv, method="predict_proba")[:, 1]
        pipe.fit(Xtr, ztr)
        models[penalty] = pipe
        models[f"{penalty}_oof"] = oof

    # 95%-sensitivity threshold from out-of-fold training predictions only: the
    # lowest data value that still captures at least 95% of malignant training rows.
    oof_primary = models["l2_oof"]
    oof_malignant = np.sort(oof_primary[ztr == 1])
    allowed_below = int(np.floor(0.05 * len(oof_malignant)))
    thr95 = float(oof_malignant[allowed_below])
    oof_sens = float(np.mean(oof_primary[ztr == 1] >= thr95))
    thresholds = {"0.5": 0.5, f"trainCV95Sensitivity={thr95:.4f}": thr95}

    rng = np.random.default_rng(SEED + 2)
    primary_res, prob_tr, prob_te = evaluate(
        "l2_logistic_primary", models["l2"], Xtr, ztr, Xte, zte, {"0.5": 0.5}, rng
    )
    alt_res, _, prob_te_l1 = evaluate(
        "l1_logistic_sensitivity", models["l1"], Xtr, ztr, Xte, zte, {"0.5": 0.5}, np.random.default_rng(SEED + 2)
    )
    # Attach the training-CV operating point to the primary model.
    primary_res["operatingPoints"]["trainCV95Sensitivity"] = operating_point(zte, prob_te, thr95)
    primary_res["operatingPoints"]["trainCV95Sensitivity"]["derivation"] = (
        f"lowest out-of-fold training probability that still captures >=95% of malignant training rows "
        f"(out-of-fold sensitivity {oof_sens:.4f}); no test row used to choose it"
    )
    threshold_grid = {"0.1": 0.1, "0.3": 0.3, "0.5": 0.5, "0.7": 0.7, "0.9": 0.9}
    primary_res["thresholdSensitivity"] = {
        label: operating_point(zte, prob_te, value) for label, value in threshold_grid.items()
    }
    primary_res["probabilityShape"] = {
        "testRowsBetween0.1And0.9": int(np.sum((prob_te > 0.1) & (prob_te < 0.9))),
        "testRowsBelow0.1": int(np.sum(prob_te <= 0.1)),
        "testRowsAbove0.9": int(np.sum(prob_te >= 0.9)),
        "note": "A near step-shaped distribution limits how much the held-out rows can say about mid-range calibration.",
    }
    wrong = np.where((prob_te >= 0.5) != (zte == 1))[0]
    primary_res["errorsAt0.5"] = [
        {
            "record_id": int(record_id.to_numpy()[test_idx][k]),
            "trueLabel": "malignant" if zte[k] == 1 else "benign",
            "pMalignant": r4(prob_te[k]),
            "kind": "false negative" if zte[k] == 1 else "false positive",
        }
        for k in wrong
    ]
    primary_res["inSampleVsHeldOut"] = {
        "aurocTrainInSample": primary_res["discrimination"]["trainAurocInSample"],
        "aurocTest": primary_res["discrimination"]["auroc"],
        "aurocOptimism": r4(primary_res["discrimination"]["trainAurocInSample"] - primary_res["discrimination"]["auroc"]),
        "brierTrainInSample": primary_res["overall"]["brierTrainInSample"],
        "brierTest": primary_res["overall"]["brier"],
        "note": "In-sample values are descriptive only; the held-out values are the ones to quote.",
    }

    # Coefficients on the standardised scale, with bootstrap uncertainty and sign stability.
    l2 = models["l2"]
    coef = l2.named_steps["logit"].coef_.ravel()
    intercept = float(l2.named_steps["logit"].intercept_[0])
    scaler = l2.named_steps["scaler"]
    order = np.argsort(-np.abs(coef))
    boot_rng = np.random.default_rng(SEED + 3)
    boot_coefs = []
    for _ in range(N_BOOT_COEF):
        sample = boot_rng.integers(0, len(train_idx), size=len(train_idx))
        if ztr[sample].min() == ztr[sample].max():
            continue
        pipe = make_pipeline("l2", selected["l2"], SEED)
        pipe.fit(Xtr[sample], ztr[sample])
        boot_coefs.append(pipe.named_steps["logit"].coef_.ravel())
    boot_coefs = np.vstack(boot_coefs)
    coef_rows = []
    for j in order:
        draws = np.exp(boot_coefs[:, j])
        same_sign = float(np.mean(np.sign(boot_coefs[:, j]) == np.sign(coef[j])))
        coef_rows.append(
            {
                "feature": feature_names[j],
                "coefPerSD": r4(coef[j]),
                "oddsRatioPerSD": r4(np.exp(coef[j])),
                "oddsRatioCI95Bootstrap": [r4(np.quantile(draws, 0.025)), r4(np.quantile(draws, 0.975))],
                "bootstrapSameSignShare": r4(same_sign),
                "trainMean": r4(scaler.mean_[j]),
                "trainSd": r4(scaler.scale_[j]),
            }
        )
    l1 = models["l1"]
    l1_coef = l1.named_steps["logit"].coef_.ravel()
    l1_selected = [feature_names[j] for j in range(len(feature_names)) if abs(l1_coef[j]) > 1e-8]
    coef_block = {
        "scale": "coefficients are per 1 SD of the training feature distribution; odds ratio = exp(coef)",
        "intercept": r4(intercept),
        "l2Rows": coef_rows,
        "l1SelectedFeatures": l1_selected,
        "l1NSelected": len(l1_selected),
        "l1ZeroedFeatures": [f for f in feature_names if f not in l1_selected],
        "bootstrapReplicatesUsed": int(boot_coefs.shape[0]),
        "topFeatureSignStabilityMin": r4(min(row["bootstrapSameSignShare"] for row in coef_rows[:5])),
    }

    thresholds_block = {
        "default": 0.5,
        "trainCV95Sensitivity": r4(thr95),
        "trainCV95SensitivityOofSensitivity": r4(oof_sens),
        "note": "No threshold was tuned on the test rows; both operating points are fixed before held-out evaluation.",
    }

    # Per-row predictions: train rows carry in-sample probabilities, test rows are held out.
    split = np.array(["train"] * len(raw), dtype=object)
    split[test_idx] = "test"
    p_mal = np.empty(len(raw))
    p_mal[train_idx] = prob_tr
    p_mal[test_idx] = prob_te
    p_mal_l1 = np.empty(len(raw))
    p_mal_l1[train_idx] = models["l1"].predict_proba(Xtr)[:, 1]
    p_mal_l1[test_idx] = prob_te_l1
    p_oof = np.full(len(raw), np.nan)
    p_oof[train_idx] = oof_primary
    pred = pd.DataFrame(
        {
            "record_id": record_id.to_numpy(),
            "split": split,
            "y_true": y_orig.to_numpy(),
            "y_true_label": np.where(y_orig.to_numpy() == 0, "malignant", "benign"),
            "p_malignant": np.round(p_mal, 6),
            "p_benign": np.round(1 - p_mal, 6),
            "pred_malignant_at_0.5": (p_mal >= 0.5).astype(int),
            "p_malignant_l1": np.round(p_mal_l1, 6),
            "pred_malignant_l1_at_0.5": (p_mal_l1 >= 0.5).astype(int),
            "p_malignant_oof_train": np.where(np.isnan(p_oof), "", np.round(p_oof, 6).astype(str)),
        }
    )
    pred.to_csv(HERE / "predictions.csv", index=False)

    # Fitted state: everything needed to score a new row without refitting.
    fitted_state = {
        "schemaVersion": 1,
        "datasetId": "wdbc",
        "dataFile": "data/breast-cancer.csv",
        "dataSha256": data_hash,
        "targetDefinition": "z = 1 if breast_cancer_yn == 0 (malignant) else 0; probabilities are P(malignant)",
        "seed": SEED,
        "split": {"type": "stratified random 70/30 by row", "trainRows": int(len(train_idx)), "testRows": int(len(test_idx))},
        "features": feature_names,
        "scaler": {"mean": [r4(v) for v in scaler.mean_], "scale": [r4(v) for v in scaler.scale_]},
        "l2Logistic": {
            "C": selected["l2"],
            "intercept": r4(intercept),
            "coef": [r4(v) for v in coef],
            "cvCurve": curves["l2"],
        },
        "l1Logistic": {
            "C": selected["l1"],
            "intercept": r4(float(l1.named_steps["logit"].intercept_[0])),
            "coef": [r4(v) for v in l1_coef],
            "cvCurve": curves["l1"],
        },
        "thresholds": thresholds_block,
        "software": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "sklearn": sklearn.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "statsmodels": sm.__version__,
        },
    }
    (HERE / "fitted-state.json").write_text(json.dumps(fitted_state, ensure_ascii=False, indent=2), encoding="utf-8")
    joblib.dump({"l2": models["l2"], "l1": models["l1"], "features": feature_names}, HERE / "fitted-model.joblib")

    results = {
        "schemaVersion": 1,
        "datasetId": "wdbc",
        "dataFingerprint": {"file": "data/breast-cancer.csv", "sha256": data_hash, "rows": profile["rows"]},
        "design": {
            "unit": "one tumour (FNA sample) per row; no patient identifier in the extract",
            "event": "malignant (source code 0)",
            "split": "stratified random 70/30, seed 20261026; test rows used once",
            "preprocessing": "StandardScaler fitted on training rows only",
            "modelSelection": "C chosen by 5-fold stratified CV log loss on training rows only",
            "primaryModel": "L2-penalised logistic regression, 30 standardised features",
            "sensitivityModel": "L1-penalised logistic regression, same split and selection rule",
        },
        "profile": profile,
        "diagnostics": diagnostics,
        "thresholds": thresholds_block,
        "analyses": [primary_res, alt_res],
        "coefficients": coef_block,
        "software": fitted_state["software"],
    }
    (HERE / "analysis-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    make_svg(
        HERE / "model-performance.svg",
        zte,
        prob_te,
        primary_res["calibrationBins"],
        f"n={len(zte)}, malignant={int(zte.sum())}",
    )

    summary = {
        "train": [int(len(train_idx)), int(ztr.sum())],
        "test": [int(len(test_idx)), int(zte.sum())],
        "l2": {"C": selected["l2"], "auc": primary_res["discrimination"]["auroc"], "ci": primary_res["discrimination"]["aurocCI95Bootstrap"], "brier": primary_res["overall"]["brier"], "cal": primary_res["calibration"]},
        "l1": {"C": selected["l1"], "nSelected": len(l1_selected), "auc": alt_res["discrimination"]["auroc"], "brier": alt_res["overall"]["brier"]},
        "thr95": [r4(thr95), oof_sens],
        "op05": primary_res["operatingPoints"]["0.5"],
        "top": [(row["feature"], row["coefPerSD"], row["oddsRatioPerSD"], row["bootstrapSameSignShare"]) for row in coef_rows[:6]],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
