#!/usr/bin/env python3
"""Independent audit of the saved per-row predictions.

Reads predictions.csv and analysis-results.json, re-derives the held-out metrics
from the row-level file, and runs the platform prediction audit against an
explicit declaration of what was fitted on which rows. Writes
prediction-audit.json. The audit is deliberately separate from analysis.py so
that the numbers in the report are checked against the file that holds them.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, roc_auc_score

HERE = Path(__file__).resolve().parent
SKILL_ROOT = Path(
    os.environ.get("EVIMED_CAPABILITY_SKILLS_DIR", "/opt/evimed/capability-skills")
) / "statistical-analysis" / "scripts"
sys.path.insert(0, str(SKILL_ROOT))
from analysis_checks import audit_predictions  # noqa: E402

PRED = HERE / "predictions.csv"
RESULTS = HERE / "analysis-results.json"
OUT = HERE / "prediction-audit.json"


def main() -> int:
    pred = pd.read_csv(PRED)
    pred["y_true"] = pred["y_true"].astype(int).astype(str)
    results = json.loads(RESULTS.read_text(encoding="utf-8"))
    primary = next(a for a in results["analyses"] if a["id"] == "l2_logistic_primary")
    features = json.loads((HERE / "fitted-state.json").read_text(encoding="utf-8"))["features"]

    train_ids = pred.loc[pred["split"] == "train", "record_id"].astype(int).tolist()
    test_ids = pred.loc[pred["split"] == "test", "record_id"].astype(int).tolist()

    fit_stages = [
        {"name": "standardize_30_features", "idLevel": "observation", "fitIds": train_ids, "predictors": features},
        {"name": "l2_C_selection_5fold_cv", "idLevel": "observation", "fitIds": train_ids, "predictors": features},
        {"name": "l2_final_fit", "idLevel": "observation", "fitIds": train_ids, "predictors": features},
        {"name": "l1_C_selection_5fold_cv", "idLevel": "observation", "fitIds": train_ids, "predictors": features},
        {"name": "l1_final_fit", "idLevel": "observation", "fitIds": train_ids, "predictors": features},
    ]

    rows = pred.to_dict(orient="records")
    audit = audit_predictions(
        rows,
        outcome_column="y_true",
        positive_label="0",
        negative_label="1",
        probability_column="p_malignant",
        probability_label="0",
        split_column="split",
        patient_id_column="record_id",
        observation_id_column=None,
        train_label="train",
        test_label="test",
        fit_stages=fit_stages,
        predictor_columns=features,
        threshold=0.5,
        calibration_bins=10,
        withheld_rows=0,
    )

    test = pred[pred["split"] == "test"]
    y_code = test["y_true"].astype(int).to_numpy()
    event = (y_code == 0).astype(int)  # source 0 = malignant
    prob = test["p_malignant"].to_numpy()
    pred_pos = prob >= 0.5
    tp = int(np.sum((event == 1) & pred_pos))
    fp = int(np.sum((event == 0) & pred_pos))
    fn = int(np.sum((event == 1) & ~pred_pos))
    tn = int(np.sum((event == 0) & ~pred_pos))
    rederived = {
        "testRows": int(len(test)),
        "testMalignant": int(event.sum()),
        "auroc": round(float(roc_auc_score(event, prob)), 4),
        "brier": round(float(brier_score_loss(event, prob)), 4),
        "sensitivity": round(tp / (tp + fn), 4),
        "specificity": round(tn / (tn + fp), 4),
        "confusion": {"truePositive": tp, "falsePositive": fp, "trueNegative": tn, "falseNegative": fn},
    }
    reported = {
        "testRows": primary["n"]["test"],
        "testMalignant": primary["n"]["eventsTest"],
        "auroc": primary["discrimination"]["auroc"],
        "brier": primary["overall"]["brier"],
        "sensitivity": primary["operatingPoints"]["0.5"]["sensitivity"],
        "specificity": primary["operatingPoints"]["0.5"]["specificity"],
        "confusion": primary["operatingPoints"]["0.5"]["confusion"],
    }
    mismatches = [
        {"field": key, "rederived": rederived[key], "reported": reported[key]}
        for key in rederived
        if key != "confusion" and abs(float(rederived[key]) - float(reported[key])) > 1e-3
    ] + [
        {"field": "confusion", "rederived": rederived["confusion"], "reported": reported["confusion"]}
    ] * int(rederived["confusion"] != reported["confusion"])

    local_checks = {
        "rowCount": int(len(pred)),
        "trainRows": int(len(train_ids)),
        "testRows": int(len(test_ids)),
        "trainTestRecordIdOverlap": len(set(train_ids) & set(test_ids)),
        "probabilitySumToOneMaxAbsDeviation": float(np.max(np.abs(
            (pred["p_malignant"] + pred["p_benign"]) - 1.0
        ))),
        "missingProbabilities": int(pred["p_malignant"].isna().sum()),
        "fitIdsEqualTrainIdsForAllStages": all(set(stage["fitIds"]) == set(train_ids) for stage in fit_stages),
        "labelCodeConsistent": bool(
            (pred.loc[pred["y_true"] == "0", "y_true_label"] == "malignant").all()
            and (pred.loc[pred["y_true"] == "1", "y_true_label"] == "benign").all()
        ),
        "testRowsWithoutTrainInSampleProbability": bool(
            pred.loc[pred["split"] == "train", "p_malignant"].notna().all()
            and pred.loc[pred["split"] == "test", "p_malignant"].notna().all()
        ),
        "rederivedFromPredictions": rederived,
        "reportedInResults": reported,
        "mismatches": mismatches,
    }

    payload = {
        "schemaVersion": 1,
        "datasetId": "wdbc",
        "sourcePredictions": "predictions.csv",
        "declared": {
            "outcome": "malignant = 0 in the source column breast_cancer_yn",
            "positiveLabel": "0",
            "probabilityColumn": "p_malignant",
            "probabilityLabel": "0",
            "unit": "one tumour per row; no patient identifier exists in the extract",
            "fitRows": "398 training rows only; test rows never used for fitting or threshold choice",
            "threshold": 0.5,
            "withheldRows": 0,
        },
        "audit": audit,
        "localChecks": local_checks,
        "limitations": [
            "The extract has no patient identifier, so patient-level independence and patient-level split overlap cannot be checked.",
            "The fit-scope check therefore reports not_checked for every stage; the fit-id list was verified at row level separately (fitIdsEqualTrainIdsForAllStages).",
            "The audit confirms internal consistency of the saved predictions; it does not validate the model against new data.",
        ],
    }
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "validation": audit.get("validation"),
        "findings": audit.get("findings"),
        "status": audit.get("status"),
        "notChecked": audit.get("notChecked"),
        "auditMetrics": {"rocAuc": audit["metrics"]["rocAuc"], "brier": audit["metrics"]["brier"]},
        "mismatches": mismatches,
        "localChecks": {k: v for k, v in local_checks.items() if k not in ("rederivedFromPredictions", "reportedInResults")},
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
