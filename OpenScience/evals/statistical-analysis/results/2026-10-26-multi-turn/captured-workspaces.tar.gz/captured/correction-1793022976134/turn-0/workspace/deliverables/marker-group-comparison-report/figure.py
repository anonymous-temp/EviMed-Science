#!/usr/bin/env python
"""Draw figure-group-comparison.svg from the computed results and the source data.

No plotting library is installed in this environment, so the figure is written as
SVG directly: every position is derived from analysis-results.json and the data,
with the shared palette (slot 1 blue #2a78d6, slot 5 violet #4a3aa7, grey for
secondary estimates). Panel A: individual marker_mm values by group with group
means. Panel B: the B - A mean difference and its 95% interval per estimate.

The script also asserts that every mark it writes falls inside its panel, so a
coordinate error fails the run instead of producing a broken figure.
"""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path

import pandas as pd

BLUE, VIOLET, GREY, INK, LIGHT = "#2a78d6", "#4a3aa7", "#8e8e93", "#111111", "#d9d9de"

W, H = 780, 400
PANEL_A = {"x0": 76, "x1": 330, "y0": 66, "y1": 300}
PANEL_B = {"x0": 420, "x1": 745, "y0": 66, "y1": 300}

marks: list[tuple[float, float, str]] = []  # (x, y, panel) for the bounds check


def scale(value, d0, d1, r0, r1):
    if d1 == d0:
        return (r0 + r1) / 2
    return r0 + (value - d0) * (r1 - r0) / (d1 - d0)


def text(x, y, s, size=10, anchor="start", colour=INK, weight="400", panel="frame"):
    marks.append((float(x), float(y), panel))
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-family="Helvetica, Arial, sans-serif" '
            f'font-size="{size}" fill="{colour}" font-weight="{weight}" '
            f'text-anchor="{anchor}">{html.escape(str(s))}</text>')


def dot(cx, cy, r, colour, opacity=1.0, panel="A"):
    marks.append((float(cx), float(cy), panel))
    return (f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r}" fill="{colour}" '
            f'fill-opacity="{opacity}"/>')


def line(x1, y1, x2, y2, colour=INK, width=1.0, dash=None, cap=None, panel="A"):
    marks.append((float(x1), float(y1), panel))
    marks.append((float(x2), float(y2), panel))
    extra = f' stroke-dasharray="{dash}"' if dash else ""
    extra += f' stroke-linecap="{cap}"' if cap else ""
    return (f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{colour}" stroke-width="{width}"{extra}/>')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/cohort.csv")
    ap.add_argument("--results", default="analysis-results.json")
    ap.add_argument("--out", default="figure-group-comparison.svg")
    ap.add_argument("--meta", default="figure-meta.json")
    args = ap.parse_args()

    df = pd.read_csv(args.data, dtype={"patient_id": str, "group": str})
    r = json.loads(Path(args.results).read_text())
    desc = {d["group"]: d for d in r["descriptives"]}

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
             f'viewBox="0 0 {W} {H}" role="img" '
             f'aria-label="marker_mm by group, and B minus A difference with 95 percent '
             f'confidence intervals">',
             f'<rect width="{W}" height="{H}" fill="#ffffff"/>']

    # ---------------- Panel A: individual values ----------------
    pa = PANEL_A
    ymin = df["marker_mm"].min() - 0.8
    ymax = df["marker_mm"].max() + 0.8
    parts.append(text(pa["x0"], 38, "A   Individual marker_mm by group", 11, weight="600"))

    tick = 8
    while tick <= ymax:
        if tick >= ymin:
            y = scale(tick, ymin, ymax, pa["y1"], pa["y0"])
            parts.append(line(pa["x0"], y, pa["x1"], y, LIGHT, 0.8, panel="legacy"))
            parts.append(text(pa["x0"] - 8, y + 3.5, tick, 9, anchor="end", colour="#555"))
        tick += 2
    parts.append(line(pa["x0"], pa["y0"], pa["x0"], pa["y1"], INK, 0.9))
    mid = (pa["y0"] + pa["y1"]) / 2
    parts.append(f'<text transform="rotate(-90 22 {mid:.1f})" x="22" y="{mid:.1f}" '
                 f'font-family="Helvetica, Arial, sans-serif" font-size="10" fill="{INK}" '
                 f'text-anchor="middle">marker_mm (mm)</text>')

    xs = {"A": pa["x0"] + 66, "B": pa["x0"] + 186}
    for g, colour in (("A", BLUE), ("B", VIOLET)):
        gx = xs[g]
        vals = df.loc[df["group"] == g, "marker_mm"].to_numpy(dtype=float)
        for i, v in enumerate(vals):
            jitter = ((i * 5) % 7 - 3) * 4.4
            parts.append(dot(gx + jitter, scale(v, ymin, ymax, pa["y1"], pa["y0"]), 3.1,
                             colour, 0.6))
        parts.append(line(gx - 36, scale(desc[g]["mean"], ymin, ymax, pa["y1"], pa["y0"]),
                          gx + 36, scale(desc[g]["mean"], ymin, ymax, pa["y1"], pa["y0"]),
                          INK, 2.2, cap="round"))
        parts.append(text(gx, pa["y1"] + 24, f"{g}  n={desc[g]['n']}", 10, anchor="middle",
                          weight="600"))
        parts.append(text(gx, pa["y1"] + 39, f"mean {desc[g]['mean']:.2f} mm", 9,
                          anchor="middle", colour="#555"))

    # ---------------- Panel B: differences ----------------
    pb = PANEL_B
    order = ["primary-welch", "sensitivity-age-adjusted", "sensitivity-student"]
    labels = {"primary-welch": "Welch t, primary",
              "sensitivity-age-adjusted": "OLS adjusted for age, sensitivity",
              "sensitivity-student": "Student t, sensitivity"}
    entries = {a["id"]: a for a in r["analyses"] if a["status"] == "complete" and a.get("interval")}
    entries = [entries[i] for i in order if i in entries]

    parts.append(text(pb["x0"] - 10, 38, "B   B − A difference in marker_mm (mm), 95% CI", 11,
                      weight="600"))

    lo = min(a["interval"]["lower"] for a in entries)
    hi = max(a["interval"]["upper"] for a in entries)
    pad = (hi - lo) * 0.12
    lo, hi = min(lo - pad, -0.3), max(hi + pad, 0.3)
    for tick in range(0, 5):
        if lo <= tick <= hi:
            x = scale(tick, lo, hi, pb["x0"], pb["x1"])
            parts.append(line(x, pb["y0"], x, pb["y1"], LIGHT, 0.8, panel="B", dash=None))
            parts.append(text(x, pb["y1"] + 18, tick, 9, anchor="middle", colour="#555"))
    parts.append(text((pb["x0"] + pb["x1"]) / 2, pb["y1"] + 36, "difference (mm)", 10,
                      anchor="middle"))
    parts.append(line(scale(0, lo, hi, pb["x0"], pb["x1"]), pb["y0"],
                      scale(0, lo, hi, pb["x0"], pb["x1"]), pb["y1"], INK, 0.9, dash="3 3",
                      panel="B"))

    rows = [pb["y0"] + 62 + i * 78 for i in range(len(entries))]
    for y, a in zip(rows, entries):
        colour = VIOLET if a["id"] == "primary-welch" else GREY
        parts.append(text(pb["x0"] - 10, y - 17, labels[a["id"]], 10, weight="600"))
        parts.append(text(pb["x0"] - 10, y - 3,
                          f"{a['estimate']:.2f} mm ({a['interval']['lower']:.2f} to "
                          f"{a['interval']['upper']:.2f})", 9, colour="#555"))
        parts.append(line(scale(a["interval"]["lower"], lo, hi, pb["x0"], pb["x1"]), y,
                          scale(a["interval"]["upper"], lo, hi, pb["x0"], pb["x1"]), y,
                          colour, 2.4, cap="round", panel="B"))
        parts.append(dot(scale(a["estimate"], lo, hi, pb["x0"], pb["x1"]), y, 4.2, colour,
                         panel="B"))

    parts.append(text(pa["x0"] - 34, H - 16,
                      "Data: data/cohort.csv, a synthetic continuity fixture. Groups are "
                      "observational categories, not randomised.", 9, colour="#666"))

    # bounds check: nothing may be drawn outside the frame or its panel
    for x, y, panel in marks:
        assert 0 <= x <= W, f"x={x} outside the canvas"
        assert 0 <= y <= H, f"y={y} outside the canvas"
        if panel == "A":
            assert PANEL_A["x0"] - 36 <= x <= PANEL_A["x1"] + 4 and PANEL_A["y0"] - 4 <= y <= PANEL_A["y1"] + 40, f"panel A mark outside: {(x, y)}"
        elif panel == "B":
            assert PANEL_B["x0"] - 12 <= x <= PANEL_B["x1"] + 4 and PANEL_B["y0"] - 2 <= y <= PANEL_B["y1"] + 40, f"panel B mark outside: {(x, y)}"

    parts.append("</svg>")
    Path(args.out).write_text("\n".join(parts))
    meta = {
        "schemaVersion": 1,
        "status": "complete",
        "figure": args.out,
        "renderer": "pure-python SVG; no plotting library is installed in this environment",
        "marksChecked": len(marks),
        "estimatesDrawn": [{"id": a["id"], "estimate": a["estimate"],
                            "lower": a["interval"]["lower"], "upper": a["interval"]["upper"]}
                           for a in entries],
        "counts": {g: desc[g]["n"] for g in desc},
        "source": {"data": args.data, "results": args.results},
    }
    Path(args.meta).write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    print(f"wrote {args.out} ({Path(args.out).stat().st_size} bytes, {len(entries)} estimates, "
          f"{len(marks)} marks checked) and {args.meta}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
