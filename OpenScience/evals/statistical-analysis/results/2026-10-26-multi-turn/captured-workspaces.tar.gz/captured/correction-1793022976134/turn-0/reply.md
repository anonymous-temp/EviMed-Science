分析已完成，全部数字由脚本从 `data/cohort.csv` 现算，报告已交付。

## 主要结果

| 项目 | 数值 |
| --- | --- |
| A 组 (n=40) | 均值 10.23 mm，SD 1.44，中位数 10.51 |
| B 组 (n=40) | 均值 13.19 mm，SD 1.46，中位数 13.11 |
| **B − A 均值差** | **2.96 mm，95% 置信区间 2.32 至 3.60 mm** |
| 检验 | Welch t = 9.14，df = 77.98，p = 5.76e-14，Hedges g = 2.02 |

三套敏感性分析与独立交叉核对同向、同量级：Student t 区间 2.315–3.605（自由度 78）；百分位自助法 2.33–3.59（10000 次重抽样，种子 20261026，SE 0.321），与 Welch 区间两端最大差 0.018 mm；年龄调整 OLS 组效应 2.96（2.308–3.607），年龄系数 0.0026 mm/岁（p = 0.855）；Mann–Whitney U = 1468，p = 1.34e-10，属秩检验，不产生毫米尺度的估计，故报告里没有把它的结果与 2.96 并列。

## 需要你知道的几点

- 数据是 `data/dictionary.md` 声明的合成一致性数据，两组为观察性分类、未随机化，所以 2.96 mm 只是描述这份文件，不构成临床或因果结论。
- 年龄 SMD 仅 0.0855（低于 0.1 阈值），但两组年龄分布形状相同、B 组恰好整体大 1 岁，属结构性差异，因此保留了年龄调整作为敏感性分析，并在报告中说明它不是因果校正。
- 年龄调整模型有 1 个观测的 Cook 距离超阈值；报告里明确写成待验证提示，没有声称"剔除后结论不变"。
- 环境无绘图库，图是脚本直接生成的 SVG，绘制后按坐标核验了所有标记都在画布内。

## 可更新机制

入口是 `deliverables/marker-group-comparison-report/analysis.py`，依次跑 profile → estimate → figure → verify，任一步失败即非零退出。关键闭环在最后一步：`verify_numbers.py` 把报告"数值溯源"表里的 43 个数字逐个回到 `analysis-results.json` 的对应路径比对，当前 43/43 通过。数据改了却忘记改正文，这一步会直接 fail，不会留一份看起来完整但过时的报告。步骤依赖、输入哈希与执行回执都在 `analysis-session.json`、`analysis-state.json` 和 `.analysis-session-receipts/`，重复运行已验证产出字节一致。

交付物已通过本轮提交校验：报告 [statistical-report.md](deliverables/marker-group-comparison-report/statistical-report.md)、图 [figure-group-comparison.svg](deliverables/marker-group-comparison-report/figure-group-comparison.svg)，配套 `analysis-results.json`、`data-profile.json`、`figure-meta.json`、`report-number-check.json`、`analysis-run.json` 均在同目录。