# B 组相对 A 组 marker_mm 差异分析报告

**数据**：`data/cohort.csv`（80 行，A 组 40 例、B 组 40 例）
**口径**：`data/dictionary.md` —— 每行一个独立受试者（`patient_id`），一次基线观测，`marker_mm` 为毫米连续测量
**分析对象**：B 组减 A 组的均值差（正值表示 B 组更高）及其 95% 区间
**结论摘要**：B 组 `marker_mm` 均值比 A 组高 **2.96 mm，95% 置信区间 2.32 至 3.60 mm**（Welch 两样本 t 区间）。三套敏感性分析、独立的自助法交叉核对与年龄调整模型给出同一方向、几乎相同的量级；组间标准差接近（1.44 与 1.46），因此合并方差与 Welch 结果实质相同。该数据是合成的一致性测试数据，上述数字描述这份文件本身，不构成任何临床或因果结论。

## 1. 问题与估计目标

估计目标是可加尺度上的组间均值差：

> Δ = E[marker_mm | B] − E[marker_mm | A]，单位 mm

对应"若把同一批受试者从一个组换到另一个组，均值会移动多少毫米"这一描述性问题，而不是"组别造成了多少变化"的因果问题。两组是观察性分类（`data/dictionary.md` 明确说明未随机化），Δ 的区间只覆盖抽样不确定性，不覆盖混杂。

## 2. 数据与检查

| 检查项 | 结果 |
| --- | --- |
| 行数与受试者 | 80 行，80 个不同 `patient_id`，无重复记录 |
| 组样本量 | A 40、B 40 |
| `marker_mm` 缺失 | 0 |
| `marker_mm` 范围 | A 8.00–12.33 mm；B 11.01–15.38 mm |
| 重复/冲突记录 | 未发现 `patient_id` 重复；按受试者键的查重结果为 clean |
| 年龄平衡 | A 均值 54.50 岁、B 55.50 岁，标准化均数差 SMD = 0.0855，低于 0.1 的常规关注阈值[3] |

年龄一项需要多说一句：两组年龄分布形状完全相同，B 组每个受试者的年龄恰好比 A 组对应受试者大 1 岁。SMD 只有 0.0855，按阈值"平衡"，但这属于结构性差异而非随机波动，所以年龄调整被保留为敏感性分析，见 4.3。

数据是**合成的一致性测试数据**（`data/dictionary.md` 声明），因此检查结果说明的是文件内部一致，不是真实人群特征。

## 3. 分析方法

- **主分析**：Welch 两样本 t 区间。不假设两组方差相等，在两组方差不同或样本量不等时比合并方差法更稳妥[1]；本次两组 n 相同、方差接近，两种方法结果几乎一致，这正是报告两者的用处。
- **敏感性**：(a) 合并方差的 Student t；(b) Mann–Whitney U（秩检验，回答"B 是否随机地更大"[2]，其 p 值不附带均值差）；(c) 以 `marker_mm` 为因变量、组别与年龄为自变量的线性回归，取组别系数作为年龄调整后的均值差。
- **独立交叉核对**：对两组分别做有放回重抽样（每组 10000 次，种子 20261026），取均值差的百分位区间[4]。该核对不复用 t 分布的解析公式，只共用同一份数据和"均值差"这一定义。
- **区间水平**：双侧 95%。不做多重比较校正，因为只有一个预先指定的主估计；敏感性分析的 p 值按单次检验解读。

## 4. 结果

### 4.1 描述统计

| 组 | n | 均值 (mm) | 标准差 | 中位数 | 四分位间距 | 范围 |
| --- | --- | --- | --- | --- | --- | --- |
| A | 40 | 10.23 | 1.44 | 10.51 | 8.94–11.55 | 8.00–12.33 |
| B | 40 | 13.19 | 1.46 | 13.11 | 11.86–14.50 | 11.01–15.38 |

两组中位数与均值的相对位置一致，B 组整体右移约 3 mm；两组的取值范围只在 11.01–12.33 mm 这一段重叠，重叠区很窄。

### 4.2 主分析：B − A 的均值差

- 点估计：**2.96 mm**
- 95% 置信区间：**2.32 至 3.60 mm**
- Welch t = 9.141，自由度 77.98，p = 5.76e-14
- 标准化效应量 Hedges g = 2.024

读法：区间整体位于零点右侧，宽度约 1.29 mm。区间下限 2.32 mm 意味着即使按最不利于"B 更高"的一端取值，差异仍是正值且量级可观。p 值只说明"两组均值相同"这一假设与数据的相容程度很低，不表示差异在临床上重要 —— 后者需要结合 `marker_mm` 的临床最小重要差异来判断，而本数据是合成数据，无法提供该参照。

### 4.3 敏感性分析

| 分析 | 估计 (mm) | 95% 区间 (mm) | 备注 |
| --- | --- | --- | --- |
| Welch t（主） | 2.96 | 2.315–3.605 | 不假设方差齐性 |
| Student t | 2.96 | 2.315–3.605 | 自由度 78.00；与 Welch 相差 < 0.001 mm |
| Mann–Whitney U | — | — | U = 1468，p = 1.34e-10；秩检验不估计均值差 |
| 年龄调整 OLS | 2.96 | 2.308–3.607 | 年龄系数 0.0026 mm/岁（95% CI −0.0255 至 0.0307，p = 0.855） |
| 自助法（交叉核对） | 2.96 | 2.33–3.59 | 10000 次重抽样，种子 20261026，SE 0.321 |

三点需要说明：

1. Student 与 Welch 几乎相同，因为两组标准差只差 0.02 mm，方差比约 1.03，远未达到合并方差法会出问题的程度。这不是"两种方法都做了所以更可信"，而是"这组数据里方法选择不构成风险"。
2. 年龄调整后组效应为 2.96 mm，与未调整的 2.96 mm 基本不变；年龄本身在模型里没有可辨识的斜率（p = 0.855，区间横跨零点）。考虑到两组年龄只差 1 岁，这一结果符合预期，也说明该混杂路径在此数据中很弱 —— 但不等于"没有混杂"，未测量的变量不在模型里。
3. Mann–Whitney 的 p 值不能与 2.96 mm 并列：它检验的是分布位置的整体偏移，不产生毫米尺度的估计。表中把它的估计列留空，就是为了避免把描述性均值差误读成秩检验的输出。

### 4.4 独立交叉核对

自助法区间 2.33–3.59 mm 与 Welch 区间 2.315–3.605 mm 的两端差最大 0.018 mm，方向一致、宽度一致，且不包含零点。分歧如此之小，说明解析区间没有依赖近似失效的边界情形；若两者相差明显，需要先怀疑重抽样次数不足或分布偏态，而不是挑一个更好看的区间。

### 4.5 图

![B 组与 A 组 marker_mm 分布，以及各估计的差值区间](figure-group-comparison.svg)

左图为两组个体观测与组均值（横线），右图为三个完整估计的差值及 95% 区间。图中 2.96 mm 的三条区间几乎重合，直观显示方法选择对结论没有影响。

## 5. 诊断与稳健性

- **独立单位**：`patient_id` 为分析单位，80 行对应 80 个受试者，无重复测量，因此不需要聚类稳健标准误或混合模型；若日后同一受试者出现多次观测，本报告的区间会偏窄，必须改用受试者层面的方法。
- **方差齐性**：两组标准差 1.44 与 1.46，方差比约 1.03。本报告没有单独做 Levene 检验；处理方式是主分析用不假设等方差的 Welch，再把合并方差的 Student 作为对照，两者一致说明等方差假设在此数据中不是关键。
- **影响点**：年龄调整模型中 1 个观测的 Cook 距离超过 4/n 的经验阈值。这是一条提示而非结论：本报告未做剔除后重估，若要判断该观测是否改变组效应，需要补一步留一法重估；在 80 例、组效应 t 值约 9 的量级下，单个观测通常不足以推翻 2.96 mm，但这属于待验证的推断。
- **共线性**：组别与年龄的方差膨胀因子均为 1.002，接近正交，系数可分别解读。
- **模型拟合**：R² = 0.5174，残差标准误 1.457 mm、残差自由度 77。剩余方差主要来自个体间变异，组别只解释了一半左右的变异。
- **缺失数据**：无缺失，未做插补；若出现缺失且与结局相关，完整病例分析会引入偏倚，需改用多重插补并做敏感性比较。

## 6. 限制与不能支持的结论

1. **数据是合成的**。这是用于验证分析流程可复现的一致性测试数据，所有数字只描述这份文件；不能据此推断任何真实人群、药物或标志物的表现。
2. **不是因果估计**。两组为观察性分类，未随机化。即使年龄调整后估计稳定，也不能读作"分组导致 2.96 mm 的升高"；未测量混杂、选择效应都不在模型内。
3. **不能判断临床意义**。2.96 mm 是否重要取决于 `marker_mm` 的最小重要差异与测量误差，本数据未提供这两项信息。
4. **外部效度为零**。样本 80 例、来源不明，不能外推到任何目标人群。
5. **区间只反映抽样不确定性**，不包含测量误差、模型设定错误或数据生成过程本身的不确定性。

## 7. 可更新与复现

所有数字由脚本从 `data/cohort.csv` 现算，报告中不手写结果。数据或口径变化后的完整重跑只有一条命令（在工作区根目录执行），它依次跑四个步骤，任一步失败即以非零状态退出：

```bash
python deliverables/marker-group-comparison-report/analysis.py --data data/cohort.csv
```

产物里的输入路径按工作区相对路径记录，因此从工作区根目录调用是规范形式；换用别的相对路径调用会改变 `data-profile.json` 中记录的路径字符串，虽然数值不变，但会让连续性记录显示来源变化。需要单独跑某一步时，同样在工作区根目录执行：

```bash
D=deliverables/marker-group-comparison-report
python $D/profile.py  --data data/cohort.csv --out $D/data-profile.json
python $D/estimate.py --data data/cohort.csv --profile $D/data-profile.json \
                      --out $D/analysis-results.json --resamples 10000 --seed 20261026
python $D/figure.py   --data data/cohort.csv --results $D/analysis-results.json \
                      --out $D/figure-group-comparison.svg --meta $D/figure-meta.json
python $D/verify_numbers.py --results $D/analysis-results.json \
                      --report $D/statistical-report.md --out $D/report-number-check.json
```

最后一步是更新闭环的关键：它逐条读取本报告"数值溯源"表中的每个数字，回到 `analysis-results.json` 取对应路径的值比对，只要有一个数字与结果文件不符就以非零状态退出。因此改数据后忘记更新正文，`report-number-check.json` 会直接报 fail，而不是悄悄留下一份过时报告。

步骤依赖、输入输出与来源哈希记录在 `analysis-session.json`，执行状态与回执在 `analysis-state.json` 与 `.analysis-session-receipts/`。随分析工具包提供的连续性助手可以列出每一步是否因输入变化而需要重跑：

```bash
python analysis_session.py status --workspace . \
  --spec analysis-session.json --state analysis-state.json
```

它对每个步骤记录脚本与输入的哈希、运行环境版本和输出摘要；输入一变，对应步骤标记为 stale，由你决定重跑哪一步，不会自动改写数据或结果。

生产物清单：`data-profile.json`（数据检查）、`analysis-results.json`（全部估计与诊断）、`figure-group-comparison.svg` 与 `figure-meta.json`（图及绘制元信息）、`report-number-check.json`（正文数字与结果文件的绑定校验）。

## 8. 方法参考

1. Welch BL. The generalization of "Student's" problem when several different population variances are involved. *Biometrika*. 1947;34(1-2):28–35. [10.1093/biomet/34.1-2.28](https://doi.org/10.1093/biomet/34.1-2.28)
2. Mann HB, Whitney DR. On a test of whether one of two random variables is stochastically larger than the other. *Annals of Mathematical Statistics*. 1947;18(1):50–60. [10.1214/aoms/1177730491](https://doi.org/10.1214/aoms/1177730491)
3. Austin PC. Balance diagnostics for comparing the distribution of baseline covariates between treatment groups in propensity-score matched samples. *Statistics in Medicine*. 2009;28(25):3083–3107. [10.1002/sim.3697](https://doi.org/10.1002/sim.3697)
4. Efron B, Tibshirani RJ. *An Introduction to the Bootstrap*. Chapman & Hall/CRC; 1993. [10.1201/9780429246593](https://doi.org/10.1201/9780429246593)

## 数值溯源

表中每个数字都对应 `analysis-results.json` 中的一个路径，由 `verify_numbers.py` 自动比对；括号内为该数值在结果文件中的精度。

| 项目 | 报告值 | analysis-results.json 路径 |
| --- | --- | --- |
| A 组例数 | 40 | `descriptives.0.n` |
| A 组均值 | 10.23 | `descriptives.0.mean` |
| A 组标准差 | 1.44 | `descriptives.0.sd` |
| A 组中位数 | 10.51 | `descriptives.0.median` |
| A 组四分位下限 | 8.94 | `descriptives.0.q1` |
| A 组四分位上限 | 11.55 | `descriptives.0.q3` |
| B 组例数 | 40 | `descriptives.1.n` |
| B 组均值 | 13.19 | `descriptives.1.mean` |
| B 组标准差 | 1.46 | `descriptives.1.sd` |
| B 组中位数 | 13.11 | `descriptives.1.median` |
| B 组四分位下限 | 11.86 | `descriptives.1.q1` |
| B 组四分位上限 | 14.50 | `descriptives.1.q3` |
| B − A 均值差（主分析） | 2.96 | `analyses.0.estimate` |
| 主分析 95% 区间下限 | 2.315 | `analyses.0.interval.lower` |
| 主分析 95% 区间上限 | 3.605 | `analyses.0.interval.upper` |
| Welch t 统计量 | 9.141 | `analyses.0.values.t` |
| Welch 自由度 | 77.98 | `analyses.0.values.df` |
| Welch p 值 | 5.76e-14 | `analyses.0.pValue` |
| Hedges g | 2.024 | `analyses.0.values.hedgesG` |
| Student 区间下限 | 2.315 | `analyses.1.interval.lower` |
| Student 区间上限 | 3.605 | `analyses.1.interval.upper` |
| Student 自由度 | 78.00 | `analyses.1.values.df` |
| Mann–Whitney U | 1468 | `analyses.2.values.U` |
| Mann–Whitney p 值 | 1.34e-10 | `analyses.2.pValue` |
| 自助法区间下限 | 2.33 | `analyses.3.interval.lower` |
| 自助法区间上限 | 3.59 | `analyses.3.interval.upper` |
| 自助法标准误 | 0.321 | `analyses.3.values.bootstrapSE` |
| 自助法重抽样次数 | 10000 | `analyses.3.values.nResamples` |
| 年龄调整组效应 | 2.96 | `analyses.4.values.coefficients.1.estimate` |
| 年龄调整区间下限 | 2.308 | `analyses.4.values.coefficients.1.lower` |
| 年龄调整区间上限 | 3.607 | `analyses.4.values.coefficients.1.upper` |
| 年龄系数 | 0.0026 | `analyses.4.values.coefficients.2.estimate` |
| 年龄系数区间下限 | -0.0255 | `analyses.4.values.coefficients.2.lower` |
| 年龄系数区间上限 | 0.0307 | `analyses.4.values.coefficients.2.upper` |
| 年龄系数 p 值 | 0.855 | `analyses.4.values.coefficients.2.pValue` |
| R² | 0.5174 | `analyses.4.values.rSquared` |
| 残差标准误 | 1.457 | `analyses.4.values.residualStandardError` |
| 残差自由度 | 77 | `analyses.4.values.residualDf` |
| 方差膨胀因子（groupB） | 1.002 | `analyses.4.values.varianceInflation.groupB` |
| 年龄标准化均数差 | 0.0855 | `checks.age_smd` |
| 分析例数 | 80 | `checks.n_analysed` |
| 因缺失排除的例数 | 0 | `checks.excluded_missing_outcome` |
| Welch 与自助法区间最大差异 (mm) | 0.018 | `checks.welch_vs_bootstrap_max_gap_mm` |
