# B 组相对 A 组 marker_mm 差异分析报告（分组编码校正版）

**数据**：`data/coding-correction.csv`（80 行，A 组 40 例、B 组 40 例）——按校正文件订正分组标签后的数据；原导出 `data/cohort.csv` 未改动，仍保留在工作区。
**校正依据**：`data/coding-correction.csv`。原导出把 A、B 两个分组标签写反；逐患者核对确认患者集合、`age`、`marker_mm` 完全一致，只有 `group` 互换。
**口径**：`data/dictionary.md` —— 每行一个独立受试者（`patient_id`），一次基线观测，`marker_mm` 为毫米连续测量。
**分析对象**：B 组减 A 组的均值差（负值表示 B 组更低）及其 95% 区间。
**结论摘要**：校正后 B 组 `marker_mm` 均值比 A 组低 **2.96 mm，95% 置信区间 -3.60 至 -2.32 mm**（Welch 两样本 t 区间）。方向与上一版相反，证据强度完全没变：p 值、|t|、|Hedges g|、R²、年龄标准化差的绝对值与校正前逐位相同。方向翻转的唯一原因是估计目标定义为 B 减 A，而校正把两组标签对调、两个组的数值集合整体互换，差值因而必然取相反数；不是数据变了，也不是结论被推翻重来。数据仍是合成的一致性测试数据，报告里的数字描述这份文件本身，不构成任何临床或因果结论。

## 1. 问题与估计目标

- **估计目标**：Δ = mean(`marker_mm` | B) − mean(`marker_mm` | A)，单位 mm；对应"两组均值相差多少毫米"这一描述性问题，而不是"组别造成多少变化"的因果问题。
- **独立单位**：`patient_id`，全表 80 例，A、B 各 40 例；每人一次基线观测，`patient_id` 唯一，无重复测量。
- **方向约定**：Δ > 0 表示 B 组更高，Δ < 0 表示 B 组更低。本次 Δ = -2.96 mm。
- **区间**：双侧 95%，主分析为 Welch 两样本 t 区间。两组是观察性分类（`data/dictionary.md` 明确说明未随机化），区间只覆盖抽样不确定性，不覆盖混杂。
- **本次更新的性质**：**编码更正**，不是新数据、不是新的分析问题。患者、年龄、测量值、样本量、方法、区间水平、自助法种子全部与上一版相同，唯一的输入变化是分组标签。

## 2. 编码校正：做了什么，方向为什么改变

### 2.1 逐患者校验

校正文件不是一句说明，而是一张与原表同结构的数据表，因此"只换了标签"这件事可以直接验，不必相信。校验脚本把两张表按 `patient_id` 对齐后逐字段比较：

| 校验项 | 结果 | 含义 |
| --- | --- | --- |
| 患者集合与唯一性 | 相同，80/80，两侧均无重复 | 同一批人，没有被增删 |
| `age` 逐患者比较 | 0 处不符 | 年龄未动 |
| `marker_mm` 逐患者比较 | 0 处不符 | 测量值未动 |
| `group` 变更 | 80/80 全部为 A↔B | 每条记录都换向，没有部分换、部分不换 |
| 交换后组内数值集合 | 校正后 B 组恰为原 A 组的数值，A 组恰为原 B 组 | 两组整体互换，不是重抽样或重新编码 |
| 两组例数 | 校正后 A 40、B 40 | 与校正前一致 |
| 均值差 | 校正前 2.96，校正后 -2.96，两者之和为 0 | 精确取负，不是"约等于" |

只要有一项不符——例如某个 `marker_mm` 被顺手改掉，或只有部分行换向——校验脚本就直接失败并中止，后续分析不会在来历不明的数据上继续。

### 2.2 方向改变的原因：估计目标的方向由标签定义

设校正前 A、B 两组的测量值集合分别为 S_A、S_B。校正后 B 组的成员恰好就是 S_A、A 组的成员恰好就是 S_B（上表已验证），于是

    Δ_校正后 = mean(S_A) − mean(S_B) = −(mean(S_B) − mean(S_A)) = −Δ_校正前

这不是重新算出一个"大概是负的"结果，而是**算术恒等**：两个组占有的数值集合互换，减法两侧也就互换。由此，各类统计量自然分成两类：

| 量 | 校正前 | 校正后 | 变化方式 |
| --- | --- | --- | --- |
| 均值差 (mm) | 2.96 | -2.96 | 取相反数 |
| 95% 区间 (mm) | 2.32 至 3.60 | -3.60 至 -2.32 | 端点互换并取相反数 |
| t 统计量 | 9.14 | -9.14 | 取相反数 |
| Welch 自由度 | 77.98 | 77.98 | 不变 |
| p 值 | 5.76e-14 | 5.76e-14 | 不变 |
| Hedges g | 2.02 | -2.02 | 取相反数，绝对值不变 |
| Mann-Whitney U | 1468 | 132 | 取补：40×40 − 1468 = 132 |
| Mann-Whitney p 值 | 1.34e-10 | 1.34e-10 | 不变 |
| 年龄调整模型 R² | 0.5174 | 0.5174 | 不变 |
| 年龄标准化差（B−A） | 0.086 | -0.086 | 取相反数，绝对值不变 |
| A 组均值 (mm) | 10.23 | 13.19 | 两组均值互换 |
| B 组均值 (mm) | 13.19 | 10.23 | 两组均值互换 |

读法很清楚：**哪些量带方向，就跟着翻转；哪些量只衡量差异大小，就完全不动。** p 值、|t|、|g|、R² 一个数字都没变，说明"两组差别很大"这一证据强度毫无变化；变的是这句话指向哪一组。

这一点值得说透，因为"方向反过来"很容易被误读成结论反转。本次不是时间上的方向变化（例如干预前后、随访前后），而是**分组命名的更正**：上一版说"B 组更高"，在旧标签下是对那个现象的正确表述；换成正确标签后，同一现象的正确表述是"A 组更高"。如果只改数字不改这句话，报告就会把方向说反——这正是必须重写结论段、而不能只替换几个数值的原因。

校正的边界也要划清：数据本身不含任何能判定"哪套标签是真的"的信息。校正之所以被采纳，依据是研究方提供的裁定文件，加上"只换标签、未动测量"这一可验证前提，而不是从数值里读出来的。若校正文件本身也写反了，方向需要再翻一次——这一点在第 6 节写明，不在正文里含糊过去。

### 2.3 校正后数据的检查

- 80 行全部纳入分析，`marker_mm` 无缺失（因缺失排除 0 例），`patient_id` 唯一，两组各 40 例。
- `marker_mm` 范围：A 组 11.01 至 15.38 mm，B 组 8.00 至 12.33 mm；标准差 A 1.46、B 1.44，方差比 1.03。
- `age`：A 组均值 55.5 岁，B 组 54.5 岁；按大小排序后两组年龄恒差 −1 岁（B 组整体年轻 1 岁），标准化差 −0.086，绝对值低于 0.1 的常规关注阈值[3]。
- 这一年龄结构是"同一批年龄整体平移"，不是随机化之后的小幅波动。因此年龄只能作为调整协变量处理，不能当作两组基线可比的证据。
- 数据是**合成的一致性测试数据**（`data/dictionary.md` 声明），检查结果说明的是文件内部一致，不是真实人群特征。

## 3. 分析方法（沿用上一版，未因换标签而改）

方法完全沿用校正前的设定，因此新旧结果的任何差异只可能来自标签本身：

- **主分析**：Welch 两样本 t 区间。不假设两组方差相等，在方差不等或样本量不等时比合并方差法更稳妥[1]；本次两组 n 相同、方差接近，两种方法结果几乎一致，这正是同时报告两者的用处。
- **敏感性一**：合并方差的 Student t 区间，用于检查"方差相等"这一假设是否真的影响结论。
- **敏感性二**：Mann-Whitney U 秩检验，回答"B 是否随机地更大"[2]，其 p 值不附带毫米尺度的均值差。
- **敏感性三**：以 `marker_mm` 为因变量、组别与年龄为自变量的线性回归，取组别系数作为年龄调整后的均值差。两组未随机化，这是**调整**而非因果校正。
- **独立交叉核对**：分组内重抽样的百分位自助法（每组 10000 次，种子 20261026），不复用 t 分布的解析公式，只共用同一份数据与"均值差"这一定义[4]。
- **区间水平**：双侧 95%。不做多重比较校正，因为只有一个预先指定的主估计；敏感性分析的 p 值按单次检验解读。
- 未做正态性检验的堆砌：n=40、无极端离群时 t 区间对轻度非正态稳健，而逐项正态性检验既不能证明假设成立，也不会改变本次结论的方向。

## 4. 结果

### 4.1 描述统计（校正后标签）

| 组 | n | 均值 (mm) | 标准差 | 中位数 | 四分位间距 | 范围 |
| --- | --- | --- | --- | --- | --- | --- |
| A | 40 | 13.19 | 1.46 | 13.11 | 11.86 至 14.50 | 11.01 至 15.38 |
| B | 40 | 10.23 | 1.44 | 10.51 | 8.94 至 11.55 | 8.00 至 12.33 |

两组的分布形状几乎一样，只是整体平移了约 3 mm；取值范围仅在 11.01 至 12.33 mm 这一段重叠。分布形状相同、位置平移，正是均值差与 t 区间在此数据上表现一致的原因。

### 4.2 主分析：B − A 的均值差

- 点估计：**-2.96 mm**
- 95% 置信区间：**-3.60 至 -2.32 mm**
- t = -9.14，Welch 自由度 77.98，p = 5.76e-14
- 标准化效应量 Hedges g = -2.02

读法：区间宽度约 1.29 mm，整体位于零点左侧。区间上端 -2.32 mm 意味着即使按最不利于"B 更低"的一端取值，差异仍是负值且量级可观，因此在这份数据里"B 组均值低于 A 组"不是抽样波动的合理解释。p 值只说明"两组均值相同"这一假设与数据相容程度很低，不表示差异在临床上重要——后者需要结合 `marker_mm` 的最小重要差异来判断，而本数据是合成数据，无法提供该参照。

按标准化效应量读，g 的绝对值约 2.02，即两组均值相距约两个合并标准差；这与 t 值、p 值一致，属于同一件事的三种表达，不应重复计数为三条独立证据。

### 4.3 敏感性分析

| 分析 | 估计 (mm) | 95% 区间 (mm) | 备注 |
| --- | --- | --- | --- |
| Welch t（主） | -2.96 | -3.605 至 -2.315 | 不假设方差齐性 |
| Student t | -2.96 | -3.605 至 -2.315 | 自由度 78；与 Welch 相差 < 0.001 mm |
| Mann-Whitney U | — | — | U = 132，p = 1.34e-10；秩检验不估计均值差 |
| 年龄调整 OLS | -2.96 | -3.607 至 -2.308 | 年龄系数 0.0026 mm/岁（95% CI -0.0255 至 0.0307，p = 0.855） |
| 自助法（交叉核对） | -2.96 | -3.60 至 -2.33 | 10000 次重抽样，种子 20261026，SE 0.33 |

三点需要说明：

1. Student 与 Welch 几乎相同，因为两组标准差只差 0.02 mm，方差比 1.03，远未达到合并方差法会出问题的程度。这不是"两种方法都做了所以更可信"，而是"这组数据里方法选择不构成风险"。
2. 年龄调整后组效应为 -2.96 mm，与未调整的 -2.96 mm 基本相同；年龄本身在模型里没有可辨识的斜率（p = 0.855，区间横跨零点）。两组的年龄只差 1 岁，这一结果符合预期，也说明该混杂路径在此数据中很弱——但不等于"没有混杂"，未测量的变量不在模型里。
3. Mann-Whitney 的 p 值不能与 -2.96 mm 并列：它检验的是分布位置的整体偏移，不产生毫米尺度的估计，表中把它的估计列留空就是为了避免把描述性均值差误读成秩检验的输出。它的 U 值为 132，恰好是校正前 1468 的补数（40×40 − 1468），这也是"两组互换"的又一个直接证据。

### 4.4 独立交叉核对

百分位自助法（10000 次重抽样）给出 -2.96 mm，95% 区间 -3.60 至 -2.33 mm，标准误 0.33。点估计与 Welch 完全一致（两者都是同一组数据的均值差，差值为 0）；区间端点与 Welch 的最大差为 0.018 mm，远小于区间宽度 1.29 mm，两条完全不同的计算路径得到同一结论。

需要说明的一点：自助法区间**不是**校正前区间的精确镜像。点估计必然取负，但两种标签下的重抽样序列不同，端点因此有约 0.01 mm 量级的蒙特卡洛差异（校正前为 2.33 至 3.59）。这属于随机数噪声，不是额外的不确定性来源；要消除它需要用同一组重抽样索引做共轭重抽样，本报告没有这么做，所以把差异如实列出，而不是声称"完全对称"。

### 4.5 图

![B 组与 A 组 marker_mm 分布，以及各估计的差值区间（校正后标签）](figure-group-comparison.svg)

左图为两组个体观测与组均值（横线），右图为三个完整估计的差值及 95% 区间。校正后右侧三条区间整体位于零点左侧，且几乎重合，直观显示方法选择对结论没有影响。本环境没有绘图库，这张图由脚本直接生成 SVG，绘制后按坐标核验了 129 个标记全部落在画布内。

## 5. 诊断与稳健性

- **独立单位**：`patient_id` 为分析单位，80 行对应 80 个受试者，无重复测量，因此不需要聚类稳健标准误或混合模型；若日后同一受试者出现多次观测，本报告的区间会偏窄，必须改用受试者层面的方法。
- **方差齐性**：两组标准差 1.46 与 1.44，方差比 1.03。本报告没有单独做方差齐性检验；处理方式是主分析用不假设等方差的 Welch，再把合并方差的 Student 作为对照，两者一致说明等方差假设在此数据中不是关键。
- **年龄结构**：两组年龄整体相差 1 岁，属结构性差异。调整后组效应从 -2.96 变为 -2.96（仅小数第三位变化），说明结论不依赖是否调整年龄。
- **影响点**：年龄调整模型中 1 个观测的 Cook 距离超过 4/n 的经验阈值。这是一条提示而非结论：本报告**没有**做剔除该观测后的重新估计，因此不能声称"剔除后结论不变"；在 80 例、组效应 t 值约 9 的量级下，单个观测通常不足以推翻 -2.96 mm，但这仍属待验证的推断。
- **共线性**：组别与年龄的方差膨胀因子均为 1.002，接近正交，系数可分别解读。
- **模型拟合**：R² = 0.5174，调整 R² = 0.505，残差标准误 1.457 mm、残差自由度 77。剩余方差主要来自个体间变异，组别只解释了一半左右的变异。
- **缺失数据**：无缺失，未做插补；若日后出现缺失且与结局相关，完整病例分析会引入偏倚，需改用多重插补并做敏感性比较。
- **整体稳健性**：五个估计（Welch、Student、Mann-Whitney、自助法、年龄调整）方向一致，四个给出区间的估计全部落在零点左侧；Welch 与自助法的最大差异 0.018 mm 远小于区间宽度 1.29 mm。稳健的是方向与量级，不是某一种方法的特权。

## 6. 限制与不能支持的结论

1. **数据是合成的**。这是用于验证分析流程可复现的一致性测试数据，所有数字只描述这份文件；不能据此推断任何真实人群、药物或标志物的表现。
2. **不是因果估计**。两组为观察性分类，未随机化。即使年龄调整后估计稳定，也不能读作"分组导致 -2.96 mm 的差异"；未测量混杂与选择效应都不在模型内。
3. **校正文件的正误无法由数据自证**。本报告以研究方提供的校正文件为准，并把"只换标签、未动测量"逐患者验证到位。但数据内部没有任何信息能证明哪套标签是真实分组；若校正文件本身写反，方向需要再翻一次。这是本次结论唯一的前置假设，也是它最主要的脆弱点。
4. **不能判断临床意义**。2.96 mm 的差异是否重要取决于 `marker_mm` 的最小重要差异与测量误差，本数据未提供这两项信息。
5. **外部效度为零**。样本 80 例、来源不明，不能外推到任何目标人群。
6. **区间只反映抽样不确定性**，不包含测量误差、模型设定错误或数据生成过程本身的不确定性。
7. **单一基线观测**：每人仅一次测量，没有重复测量、没有时间信息，因此无法区分组间差异与个体内波动，也不能评估任何变化趋势。
8. **影响点未处理**：如第 5 节所述，Cook 距离超标的那 1 个观测没有做剔除重估。

## 7. 可更新与复现

所有数字由脚本从校正后的数据现算，报告中不手写结果。整条链路由一个入口脚本串联，顺序是"校正 → 画像 → 估计 → 作图 → 数字校验"，任一步失败即以非零状态退出，不会留下"看起来完整"的半成品；第一步失败（校正文件不是纯换标签）时后续步骤根本不会启动：

```bash
python deliverables/marker-group-comparison-report/analysis.py
```

默认参数即本次运行所用：`--original data/cohort.csv --correction data/coding-correction.csv`。从工作区根目录调用是规范形式，因为产物里的输入路径按工作区相对路径记录；换用别的相对路径调用会改变记录里的路径字符串，虽然数值不变，但会让连续性记录显示来源变化。

- **校正校验**：`correct_coding.py` 产出 `coding-correction-check.json`，记录两份输入文件的哈希、逐项比较结果，以及"校正后差值是否恰为校正前差值的相反数"。
- **步骤依赖与可复用性**：`analysis-session.json` 定义五个步骤及各自的输入、输出与上下文，执行状态与回执在 `analysis-state.json` 与 `.analysis-session-receipts/`。它对每个步骤记录脚本与输入的哈希、运行环境版本和输出摘要；输入一变，对应步骤标记为 stale，由你决定重跑哪一步，不会自动改写数据或结果。查看状态：

  ```bash
  python analysis_session.py status --workspace . \
    --spec analysis-session.json --state analysis-state.json
  ```

- **数值溯源**：本报告所有数字与结果文件逐条绑定，由 `verify_numbers.py` 在每次运行时重新比对，产出 `report-number-check.json`。只要有一个数字与结果文件不符就以非零状态退出，因此改数据后忘记更新正文会直接报 fail，而不是悄悄留下一份过时报告。它不承诺自动重写中文段落。
- **上一版归档**：`history/` 下保留了校正前的报告、结果文件、图、数字校验与会话定义（`statistical-report-original-coding.md`、`analysis-results-original.json`、`figure-original.svg`、`report-number-check-original.json`、`analysis-session-original.json`）。校正前的数值在下文旧口径表中可直接核对，不需要重跑一遍旧标签。

## 8. 方法参考

1. Welch BL. The generalization of "Student's" problem when several different population variances are involved. *Biometrika*. 1947;34(1-2):28–35. [10.1093/biomet/34.1-2.28](https://doi.org/10.1093/biomet/34.1-2.28)
2. Mann HB, Whitney DR. On a test of whether one of two random variables is stochastically larger than the other. *Annals of Mathematical Statistics*. 1947;18(1):50–60. [10.1214/aoms/1177730491](https://doi.org/10.1214/aoms/1177730491)
3. Austin PC. Balance diagnostics for comparing the distribution of baseline covariates between treatment groups in propensity-score matched samples. *Statistics in Medicine*. 2009;28(25):3083–3107. [10.1002/sim.3697](https://doi.org/10.1002/sim.3697)
4. Efron B, Tibshirani RJ. *An Introduction to the Bootstrap*. Chapman & Hall/CRC; 1993. [10.1201/9780429246593](https://doi.org/10.1201/9780429246593)

## 数值溯源

第一张表是校正后的报告值，第二张表是归档的校正前数值。每行第三列是结果文件中的取值路径：不带文件名的路径读取 `analysis-results.json`；`文件::路径` 形式读取该文件，用于核对归档结果。数值按写出的位数比较，容差为最后一位的半个单位；任一行不符则校验失败。

| 项目（校正后） | 报告值 | 结果路径 |
| --- | --- | --- |
| A 组例数 | 40 | `descriptives.0.n` |
| A 组均值 | 13.19 | `descriptives.0.mean` |
| A 组标准差 | 1.46 | `descriptives.0.sd` |
| A 组中位数 | 13.11 | `descriptives.0.median` |
| A 组四分位下限 | 11.86 | `descriptives.0.q1` |
| A 组四分位上限 | 14.50 | `descriptives.0.q3` |
| A 组最小值 | 11.01 | `descriptives.0.min` |
| A 组最大值 | 15.38 | `descriptives.0.max` |
| B 组例数 | 40 | `descriptives.1.n` |
| B 组均值 | 10.23 | `descriptives.1.mean` |
| B 组标准差 | 1.44 | `descriptives.1.sd` |
| B 组中位数 | 10.51 | `descriptives.1.median` |
| B 组四分位下限 | 8.94 | `descriptives.1.q1` |
| B 组四分位上限 | 11.55 | `descriptives.1.q3` |
| B 组最小值 | 8.00 | `descriptives.1.min` |
| B 组最大值 | 12.33 | `descriptives.1.max` |
| B − A 均值差（主分析） | -2.96 | `analyses.0.estimate` |
| 主分析 95% 区间下限 | -3.60 | `analyses.0.interval.lower` |
| 主分析 95% 区间上限 | -2.32 | `analyses.0.interval.upper` |
| Welch t 统计量 | -9.14 | `analyses.0.values.t` |
| Welch 自由度 | 77.98 | `analyses.0.values.df` |
| Welch p 值 | 5.76e-14 | `analyses.0.pValue` |
| Hedges g | -2.02 | `analyses.0.values.hedgesG` |
| Student 区间下限 | -3.60 | `analyses.1.interval.lower` |
| Student 区间上限 | -2.32 | `analyses.1.interval.upper` |
| Student 自由度 | 78 | `analyses.1.values.df` |
| Student p 值 | 5.75e-14 | `analyses.1.pValue` |
| Mann-Whitney U | 132 | `analyses.2.values.U` |
| Mann-Whitney p 值 | 1.34e-10 | `analyses.2.pValue` |
| 自助法区间下限 | -3.60 | `analyses.3.interval.lower` |
| 自助法区间上限 | -2.33 | `analyses.3.interval.upper` |
| 自助法标准误 | 0.33 | `analyses.3.values.bootstrapSE` |
| 自助法重抽样次数 | 10000 | `analyses.3.values.nResamples` |
| 年龄调整组效应 | -2.96 | `analyses.4.estimate` |
| 年龄调整区间下限 | -3.61 | `analyses.4.interval.lower` |
| 年龄调整区间上限 | -2.31 | `analyses.4.interval.upper` |
| 年龄调整 p 值 | 8.88e-14 | `analyses.4.pValue` |
| 年龄系数 | 0.0026 | `analyses.4.values.coefficients.2.estimate` |
| 年龄系数区间下限 | -0.0255 | `analyses.4.values.coefficients.2.lower` |
| 年龄系数区间上限 | 0.0307 | `analyses.4.values.coefficients.2.upper` |
| 年龄系数 p 值 | 0.855 | `analyses.4.values.coefficients.2.pValue` |
| R² | 0.5174 | `analyses.4.values.rSquared` |
| 调整 R² | 0.505 | `analyses.4.values.adjustedRSquared` |
| 残差标准误 | 1.457 | `analyses.4.values.residualStandardError` |
| F 统计量 | 41.28 | `analyses.4.values.fStatistic` |
| 残差自由度 | 77 | `analyses.4.values.residualDf` |
| 方差膨胀因子（groupB） | 1.002 | `analyses.4.values.varianceInflation.groupB` |
| 分析例数 | 80 | `checks.n_analysed` |
| 因缺失排除的例数 | 0 | `checks.excluded_missing_outcome` |
| Welch 与自助法区间最大差异 (mm) | 0.018 | `checks.welch_vs_bootstrap_max_gap_mm` |
| 年龄标准化差（B−A，带符号） | -0.086 | `checks.age_smd_signed` |
| 年龄标准化差（绝对值） | 0.0855 | `checks.age_smd_abs` |

| 项目（校正前，归档） | 报告值 | 归档路径 |
| --- | --- | --- |
| 旧口径 A 组均值 | 10.23 | `history/analysis-results-original.json::descriptives.0.mean` |
| 旧口径 B 组均值 | 13.19 | `history/analysis-results-original.json::descriptives.1.mean` |
| 旧口径 B − A 均值差 | 2.96 | `history/analysis-results-original.json::analyses.0.estimate` |
| 旧口径 95% 区间下限 | 2.32 | `history/analysis-results-original.json::analyses.0.interval.lower` |
| 旧口径 95% 区间上限 | 3.60 | `history/analysis-results-original.json::analyses.0.interval.upper` |
| 旧口径 Welch t 统计量 | 9.14 | `history/analysis-results-original.json::analyses.0.values.t` |
| 旧口径 Welch 自由度 | 77.98 | `history/analysis-results-original.json::analyses.0.values.df` |
| 旧口径 Welch p 值 | 5.76e-14 | `history/analysis-results-original.json::analyses.0.pValue` |
| 旧口径 Hedges g | 2.02 | `history/analysis-results-original.json::analyses.0.values.hedgesG` |
| 旧口径 Mann-Whitney U | 1468 | `history/analysis-results-original.json::analyses.2.values.U` |
| 旧口径 Mann-Whitney p 值 | 1.34e-10 | `history/analysis-results-original.json::analyses.2.pValue` |
| 旧口径 自助法区间下限 | 2.33 | `history/analysis-results-original.json::analyses.3.interval.lower` |
| 旧口径 自助法区间上限 | 3.59 | `history/analysis-results-original.json::analyses.3.interval.upper` |
| 旧口径 年龄调整组效应 | 2.96 | `history/analysis-results-original.json::analyses.4.estimate` |
| 旧口径 年龄调整区间下限 | 2.31 | `history/analysis-results-original.json::analyses.4.interval.lower` |
| 旧口径 年龄调整区间上限 | 3.61 | `history/analysis-results-original.json::analyses.4.interval.upper` |
| 旧口径 年龄调整模型 R² | 0.5174 | `history/analysis-results-original.json::analyses.4.values.rSquared` |
| 旧口径 年龄标准化差（B−A） | 0.0855 | `history/analysis-results-original.json::checks.age_smd` |
| 旧口径 Welch 与自助法区间最大差异 (mm) | 0.018 | `history/analysis-results-original.json::checks.welch_vs_bootstrap_max_gap_mm` |
