#!/usr/bin/env python
"""Re-read every number quoted in statistical-report.md against the results JSON.

Two checks:
1. The report's "数值溯源" table: each row is  | 项目 | 报告值 | 路径 |.
   The reported string is parsed at the precision it is written in and compared with
   the value at that path, with a tolerance of half a unit of the last quoted digit.
   A bare path reads analysis-results.json; `file.json::path` reads another JSON file
   (resolved next to the report), so archived numbers from the pre-correction run stay
   checkable instead of being retyped as folklore.
2. The prose must contain the primary difference and both confidence limits as written
   in the table, so the headline numbers are not only in the table.

Writes report-number-check.json. Exit code 1 if any binding fails.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

TOLERANCE_DIGITS = 0.5  # half a unit in the last place of the quoted string


def resolve(document, path: str):
    node = document
    for part in path.split("."):
        if isinstance(node, list):
            node = node[int(part)]
        elif isinstance(node, dict):
            node = node[part]
        else:
            raise KeyError(f"cannot descend into {type(node).__name__} at {part!r}")
    return node


def parse_number(cell: str):
    """Return (value, decimals) from a table cell: '2.96', '5.8e-14' or '5.8 × 10-14'."""
    cell = cell.strip().replace("−", "-").replace("×", "x").replace(" ", "")
    sci = re.fullmatch(r"([\d.]+)(?:x10\^?|e)([-+]?\d+)", cell, flags=re.IGNORECASE)
    if sci:
        mantissa, exponent = sci.group(1), sci.group(2)
        decimals = len(mantissa.split(".")[1]) if "." in mantissa else 0
        return float(f"{mantissa}e{int(exponent)}"), decimals
    plain = re.fullmatch(r"[-+]?\d*\.?\d+", cell)
    if not plain:
        raise ValueError(f"not a number: {cell!r}")
    decimals = len(cell.split(".")[1]) if "." in cell else 0
    return float(cell), decimals


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="analysis-results.json")
    ap.add_argument("--report", default="statistical-report.md")
    ap.add_argument("--out", default="report-number-check.json")
    args = ap.parse_args()

    results = json.loads(Path(args.results).read_text())
    report = Path(args.report).read_text()

    rows = re.findall(r"^\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*`([^`]+)`\s*\|\s*$",
                      report, flags=re.MULTILINE)
    report_dir = Path(args.report).resolve().parent
    other_documents: dict[str, object] = {}
    bindings, failures = [], 0
    for name, cell, path in rows:
        if path.startswith("analysis-results.json:"):
            path = path.split(":", 1)[1]
        document, binding_path = results, path
        if "::" in path:
            source, binding_path = path.split("::", 1)
            if source not in other_documents:
                other_documents[source] = json.loads((report_dir / source).read_text())
            document = other_documents[source]
        try:
            reported, decimals = parse_number(cell)
            actual = resolve(document, binding_path)
        except (KeyError, ValueError, IndexError, FileNotFoundError) as error:
            bindings.append({"name": name, "path": path, "reported": cell,
                             "status": "unresolved", "reason": str(error)})
            failures += 1
            continue
        tolerance = TOLERANCE_DIGITS * 10 ** (-decimals) + 1e-12
        ok = isinstance(actual, (int, float)) and abs(float(actual) - reported) <= tolerance
        bindings.append({"name": name, "path": path, "reported": cell,
                         "resultsValue": actual, "tolerance": tolerance,
                         "status": "pass" if ok else "fail",
                         **({} if ok else {"difference": float(actual) - reported})})
        failures += 0 if ok else 1

    # Prose cross-check: the headline numbers must also appear outside the table.
    prose = report.split("## 数值溯源")[0] if "## 数值溯源" in report else report
    headline = {}
    for key, path in (("difference", "analyses.0.estimate"),
                      ("lower", "analyses.0.interval.lower"),
                      ("upper", "analyses.0.interval.upper")):
        value = resolve(results, path)
        rendered = f"{value:.2f}"
        headline[key] = {"value": value, "rendered": rendered, "inProse": rendered in prose}
        if rendered not in prose:
            failures += 1

    check = {
        "schemaVersion": 1,
        "status": "pass" if failures == 0 else "fail",
        "report": args.report,
        "results": args.results,
        "bindingsChecked": len(bindings),
        "failures": failures,
        "headlineProse": headline,
        "bindings": bindings,
    }
    Path(args.out).write_text(json.dumps(check, indent=2, ensure_ascii=False))
    print(json.dumps({"status": check["status"], "bindingsChecked": len(bindings),
                      "failures": failures,
                      "failedBindings": [b for b in bindings if b["status"] != "pass"],
                      "headline": headline}, indent=2, ensure_ascii=False))
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
