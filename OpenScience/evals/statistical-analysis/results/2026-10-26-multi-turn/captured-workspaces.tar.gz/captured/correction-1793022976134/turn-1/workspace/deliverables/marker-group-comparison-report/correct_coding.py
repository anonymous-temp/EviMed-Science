#!/usr/bin/env python
"""Verify that data/coding-correction.csv differs from data/cohort.csv only in the group label.

The researcher states that the original A/B labels were reversed and supplies a
correction file with the same patients and measurements. This script does not take
that on trust: it compares the two files patient by patient and refuses (exit 1) if
anything other than `group` moved.

It also computes the arithmetic consequence for the estimand, because the direction
change in the report must be reproducible rather than asserted:

    delta_corrected = mean(corrected B) - mean(corrected A)
                    = mean(original A) - mean(original B)
                    = -delta_original

Usage:
    python correct_coding.py --original data/cohort.csv \
        --correction data/coding-correction.csv --out coding-correction-check.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

REQUIRED = ["patient_id", "group", "age", "marker_mm"]
SWAP = {"A": "B", "B": "A"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", default="data/cohort.csv")
    ap.add_argument("--correction", default="data/coding-correction.csv")
    ap.add_argument("--out", default="coding-correction-check.json")
    args = ap.parse_args()

    original_path, corrected_path = Path(args.original), Path(args.correction)
    failures: list[str] = []

    orig = pd.read_csv(original_path)
    corr = pd.read_csv(corrected_path)

    for name, df in (("original", orig), ("correction", corr)):
        missing = [c for c in REQUIRED if c not in df.columns]
        if missing:
            failures.append(f"{name}: missing required columns {missing}")
    if failures:
        return report(args.out, original_path, corrected_path, orig, corr, failures, None)

    # Same patients, one row each, no blanks in the fields the analysis relies on.
    same_patients = set(orig["patient_id"]) == set(corr["patient_id"])
    if not same_patients:
        failures.append("patient_id sets differ between original and correction")
    if not orig["patient_id"].is_unique:
        failures.append("original: patient_id is not unique")
    if not corr["patient_id"].is_unique:
        failures.append("correction: patient_id is not unique")
    if corr[["group", "marker_mm"]].isna().any().any():
        failures.append("correction: blank group or marker_mm")

    o = orig.set_index("patient_id").sort_index()
    c = corr.set_index("patient_id").sort_index()
    common = o.index.intersection(c.index)

    # Only the label may move: age and marker_mm must match exactly, patient by patient.
    age_mismatch = int((o.loc[common, "age"] != c.loc[common, "age"]).sum())
    marker_mismatch = int((o.loc[common, "marker_mm"] != c.loc[common, "marker_mm"]).sum())
    if age_mismatch:
        failures.append(f"age differs for {age_mismatch} patient(s); a relabelling must not move measurements")
    if marker_mismatch:
        failures.append(f"marker_mm differs for {marker_mismatch} patient(s); a relabelling must not move measurements")

    # The label change must be exactly the A<->B swap, applied to every patient.
    expected = o.loc[common, "group"].map(SWAP)
    not_swapped = c.loc[common, "group"] != expected
    if not_swapped.any():
        bad = int(not_swapped.sum())
        failures.append(f"{bad} patient(s) are not a clean A<->B swap; the correction is not a pure relabelling")

    # After the swap, each group holds exactly the other group's marker values.
    swapped = o.loc[common, "group"].map(SWAP)
    sets_swapped = {
        "corrected_B_holds_original_A": bool(sorted(c.loc[common, "marker_mm"][c.loc[common, "group"] == "B"])
                                             == sorted(o.loc[common, "marker_mm"][o.loc[common, "group"] == "A"])),
        "corrected_A_holds_original_B": bool(sorted(c.loc[common, "marker_mm"][c.loc[common, "group"] == "A"])
                                             == sorted(o.loc[common, "marker_mm"][o.loc[common, "group"] == "B"])),
    }
    if not all(sets_swapped.values()):
        failures.append("after the swap the groups do not hold each other's values; check the correction rule")

    # Arithmetic consequence for the reported estimand.
    def delta(frame: pd.DataFrame) -> float:
        means = frame.groupby("group")["marker_mm"].mean()
        return float(means["B"] - means["A"])

    d_original, d_corrected = delta(orig), delta(corr)
    negation = {
        "delta_original_mm": d_original,
        "delta_corrected_mm": d_corrected,
        "sum_mm": d_original + d_corrected,
        "is_exact_negation": bool(abs(d_original + d_corrected) < 1e-9),
    }
    if not negation["is_exact_negation"]:
        failures.append("corrected difference is not the exact negation of the original; the swap is not exhaustive")

    payload = {
        "schemaVersion": 1,
        "status": "pass" if not failures else "fail",
        "failures": failures,
        "original": {
            "path": str(original_path),
            "sha256": sha256(original_path),
            "rows": int(len(orig)),
            "groupCounts": {k: int(v) for k, v in orig["group"].value_counts().items()},
        },
        "correction": {
            "path": str(corrected_path),
            "sha256": sha256(corrected_path),
            "rows": int(len(corr)),
            "groupCounts": {k: int(v) for k, v in corr["group"].value_counts().items()},
        },
        "patients": {
            "compared": int(len(common)),
            "sameIdSet": bool(same_patients),
            "labelsChanged": int((o.loc[common, "group"].values != c.loc[common, "group"].values).sum()),
            "ageMismatches": age_mismatch,
            "markerMismatches": marker_mismatch,
            "unexpectedLabels": int((~o.loc[common, "group"].isin(list(SWAP))).sum()),
        },
        "groupValueSets": sets_swapped,
        "estimandConsequence": negation,
        "interpretation": (
            "The correction is a pure A<->B relabelling: patients, age and marker_mm are unchanged. "
            "Because the estimand is mean(B) - mean(A), exchanging the labels exchanges the two group "
            "means, so the point estimate and both interval endpoints take the opposite sign. Every "
            "symmetric quantity (|t|, degrees of freedom, p, Hedges g, R^2, |SMD|) is unchanged."
        ),
    }
    return report(args.out, original_path, corrected_path, orig, corr, failures, payload)


def report(out: str, original_path: Path, corrected_path: Path, orig, corr, failures, payload) -> int:
    path = Path(out)
    path.write_text(json.dumps(payload or {"schemaVersion": 1, "status": "fail", "failures": failures},
                               ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": (payload or {}).get("status", "fail"),
                      "out": str(path),
                      "failures": failures}, ensure_ascii=False))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
