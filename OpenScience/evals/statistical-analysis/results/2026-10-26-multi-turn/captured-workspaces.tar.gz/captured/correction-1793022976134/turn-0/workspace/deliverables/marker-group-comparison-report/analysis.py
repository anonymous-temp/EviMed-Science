#!/usr/bin/env python
"""Reproduce the whole analysis package in order: profile -> estimate -> figure -> verify.

Every number in statistical-report.md comes from analysis-results.json, so this
script is the single entry point for an update: run it after the data change, then
update the prose where report-number-check.json reports a mismatch.

The steps are called with workspace-relative paths from the workspace root, so this
entry point and analysis-session.json produce byte-identical artifacts.

Usage (from anywhere):
    python deliverables/marker-group-comparison-report/analysis.py [--resamples 10000] [--seed 20261026]

Exits non-zero as soon as one step fails, so a broken update cannot leave a
half-regenerated package that looks complete.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PREFIX = HERE.relative_to(ROOT).as_posix()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/cohort.csv")
    ap.add_argument("--resamples", default="10000")
    ap.add_argument("--seed", default="20261026")
    args = ap.parse_args()

    steps = [
        ("profile",
         ["profile.py", "--data", args.data, "--out", f"{PREFIX}/data-profile.json"]),
        ("estimate",
         ["estimate.py", "--data", args.data, "--profile", f"{PREFIX}/data-profile.json",
          "--out", f"{PREFIX}/analysis-results.json", "--resamples", args.resamples,
          "--seed", args.seed]),
        ("figure",
         ["figure.py", "--data", args.data, "--results", f"{PREFIX}/analysis-results.json",
          "--out", f"{PREFIX}/figure-group-comparison.svg",
          "--meta", f"{PREFIX}/figure-meta.json"]),
        ("verify",
         ["verify_numbers.py", "--results", f"{PREFIX}/analysis-results.json",
          "--report", f"{PREFIX}/statistical-report.md",
          "--out", f"{PREFIX}/report-number-check.json"]),
    ]

    for name, argv in steps:
        script = HERE / argv[0]
        print(f"== {name}: {argv[0]} {' '.join(argv[1:])}", flush=True)
        completed = subprocess.run([sys.executable, str(script), *argv[1:]], cwd=ROOT)
        if completed.returncode != 0:
            print(f"== {name}: failed with exit code {completed.returncode}", file=sys.stderr)
            return completed.returncode
    print("== all steps completed; report-number-check.json decides whether the prose is current")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
