#!/usr/bin/env python
"""Data-quality profile of data/cohort.csv before the group comparison.

Reads the source file, writes data-profile.json. Never modifies the source.
Checks: required columns, group membership, observation unit (patient_id),
missing marker_mm, exact and conflicting duplicate patient records, group sizes,
and age balance between the two groups.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SKILL_SCRIPTS = Path(__import__("os").environ.get(
    "EVIMED_CAPABILITY_SKILLS_DIR",
    "/usr/local/share/evimed/capability-skills",
)) / "statistical-analysis" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from analysis_methods import covariate_balance  # noqa: E402

REQUIRED = ["patient_id", "group", "age", "marker_mm"]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/cohort.csv")
    ap.add_argument("--out", default="data-profile.json")
    args = ap.parse_args()

    src = Path(args.data)
    df = pd.read_csv(src, dtype={"patient_id": str, "group": str})

    profile = {
        "schemaVersion": 1,
        "source": {"path": str(src), "sha256": sha256(src), "rows": int(len(df)),
                   "columns": list(df.columns)},
        "checks": {},
        "warnings": [],
        "group_sizes": {},
        "age_balance": None,
    }

    missing_cols = [c for c in REQUIRED if c not in df.columns]
    profile["checks"]["required_columns_present"] = {
        "passed": not missing_cols, "missing": missing_cols}
    if missing_cols:
        profile["warnings"].append(f"missing required columns: {missing_cols}")
        Path(args.out).write_text(json.dumps(profile, indent=2, ensure_ascii=False))
        return 2

    # Observation unit: is one row one independent subject?
    n_rows = int(len(df))
    n_ids = int(df["patient_id"].nunique())
    dup_mask = df.duplicated("patient_id", keep=False)
    dup_ids = sorted(df.loc[dup_mask, "patient_id"].unique().tolist())
    exact_dups = int(df.duplicated(keep=False).sum()) if dup_ids else 0
    conflicting = []
    for pid in dup_ids:
        block = df.loc[df["patient_id"] == pid].drop(columns=["patient_id"])
        if block.drop_duplicates().shape[0] > 1:
            conflicting.append(pid)
    profile["checks"]["observation_unit"] = {
        "declared_unit": "one independent subject per patient_id (data/dictionary.md)",
        "n_rows": n_rows,
        "n_unique_patient_id": n_ids,
        "repeated_patient_ids": dup_ids,
        "rows_in_exact_duplicate_groups": exact_dups,
        "patient_ids_with_conflicting_repeats": conflicting,
        "one_row_per_subject": n_rows == n_ids and not dup_ids,
    }
    if dup_ids:
        profile["warnings"].append(
            "repeated patient records present; independent-groups methods assume one row per subject")

    # Group membership
    counts = df["group"].value_counts(dropna=False).to_dict()
    profile["group_sizes"] = {str(k): int(v) for k, v in counts.items()}
    profile["checks"]["two_groups_only"] = {
        "passed": sorted(df["group"].dropna().unique().tolist()) == ["A", "B"]}

    # Missing outcome
    miss = df["marker_mm"].isna()
    profile["checks"]["outcome_missingness"] = {
        "column": "marker_mm",
        "n_missing": int(miss.sum()),
        "missing_rate": float(miss.mean()),
        "n_analysed": int((~miss).sum()),
    }
    if miss.any():
        profile["warnings"].append(
            f"{int(miss.sum())} missing marker_mm values excluded from the comparison")

    # Ranges / plausibility
    profile["checks"]["value_ranges"] = {
        col: {"min": float(df[col].min()), "max": float(df[col].max()),
              "sd": float(df[col].std(ddof=1)), "mean": float(df[col].mean())}
        for col in ["age", "marker_mm"]
    }

    # Age balance (observed grouping, not randomised)
    profile["age_balance"] = covariate_balance(
        df["group"], df[["age"]], contrast=("B", "A"), label="age balance B vs A")
    smd = profile["age_balance"].get("estimate")
    profile["checks"]["age_balance"] = {
        "standardized_mean_difference_B_minus_A": smd,
        "imbalanced_above_0_1": None if smd is None else bool(abs(smd) > 0.1),
        "age_mean_A": float(df.loc[df["group"] == "A", "age"].mean()),
        "age_mean_B": float(df.loc[df["group"] == "B", "age"].mean()),
        "age_paired_within_subject": bool(
            np.allclose(np.sort(df.loc[df["group"] == "A", "age"].to_numpy(dtype=float)) + 1.0,
                        np.sort(df.loc[df["group"] == "B", "age"].to_numpy(dtype=float)))),
    }

    Path(args.out).write_text(json.dumps(profile, indent=2, ensure_ascii=False))
    print(json.dumps({k: profile[k] for k in ("group_sizes", "warnings")}, indent=2,
                     ensure_ascii=False))
    print(json.dumps(profile["checks"]["observation_unit"], indent=2, ensure_ascii=False))
    print(json.dumps(profile["checks"]["age_balance"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
