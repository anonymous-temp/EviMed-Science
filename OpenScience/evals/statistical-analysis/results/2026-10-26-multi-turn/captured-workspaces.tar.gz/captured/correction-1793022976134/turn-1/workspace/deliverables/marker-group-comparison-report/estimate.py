#!/usr/bin/env python
"""Estimate the B minus A difference in marker_mm and its 95% interval.

Primary: Welch two-sample t interval for the difference in means (B - A), mm.
Sensitivity: pooled-variance t, Mann-Whitney rank test, and an OLS model
adjusting for age (observed groups, not randomised).
Independent cross-check: seeded percentile bootstrap of the mean difference.
Also writes the per-group descriptive table.

Every number quoted in statistical-report.md is read from analysis-results.json
by verify_numbers.py. The figure (figure-group-comparison.svg) is drawn from this
file by figure.py; no plotting library is installed here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SKILL_SCRIPTS = Path(os.environ.get(
    "EVIMED_CAPABILITY_SKILLS_DIR", "/usr/local/share/evimed/capability-skills",
)) / "statistical-analysis" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from analysis_methods import compare_groups, linear_regression  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def descriptives(df: pd.DataFrame) -> list[dict]:
    out = []
    for g in ["A", "B"]:
        x = df.loc[df["group"] == g, "marker_mm"].to_numpy(dtype=float)
        q1, q3 = np.percentile(x, [25, 75])
        out.append({
            "group": g, "n": int(x.size), "mean": float(np.mean(x)),
            "sd": float(np.std(x, ddof=1)), "se": float(np.std(x, ddof=1) / np.sqrt(x.size)),
            "median": float(np.median(x)), "q1": float(q1), "q3": float(q3),
            "min": float(np.min(x)), "max": float(np.max(x)),
        })
    return out


def bootstrap_difference(a: np.ndarray, b: np.ndarray, n_resamples: int, seed: int) -> dict:
    """Percentile bootstrap of mean(B) - mean(A); independent resampling within each group."""
    rng = np.random.default_rng(seed)
    diffs = np.empty(n_resamples)
    for i in range(n_resamples):
        diffs[i] = (rng.choice(b, b.size, replace=True).mean()
                    - rng.choice(a, a.size, replace=True).mean())
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return {
        "id": "crosscheck-bootstrap",
        "status": "complete",
        "method": "percentile bootstrap, two-sample mean difference (numpy, own code)",
        "estimand": "mean(B) - mean(A) of marker_mm, mm",
        "n": {"B": int(b.size), "A": int(a.size)},
        "estimate": float(np.mean(b) - np.mean(a)),
        "interval": {"lower": float(lo), "upper": float(hi), "level": 0.95},
        "values": {"nResamples": n_resamples, "bootstrapSE": float(np.std(diffs, ddof=1))},
        "seeded": True,
        "seed": seed,
        "warnings": [],
        "diagnostics": [],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/cohort.csv")
    ap.add_argument("--profile", default="data-profile.json")
    ap.add_argument("--out", default="analysis-results.json")
    ap.add_argument("--coding-check", default=None,
                    help="coding-correction-check.json from correct_coding.py, embedded as provenance")
    ap.add_argument("--resamples", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=20261026)
    args = ap.parse_args()

    src = Path(args.data)
    df = pd.read_csv(src, dtype={"patient_id": str, "group": str})
    profile = json.loads(Path(args.profile).read_text())

    one_row_per_subject = profile["checks"]["observation_unit"]["one_row_per_subject"]
    if not one_row_per_subject:
        raise SystemExit("repeated patient records present; resolve them before comparing groups")

    df = df.loc[df["marker_mm"].notna()].copy()
    a = df.loc[df["group"] == "A", "marker_mm"].to_numpy(dtype=float)
    b = df.loc[df["group"] == "B", "marker_mm"].to_numpy(dtype=float)

    primary = compare_groups(df["marker_mm"], df["group"], contrast=("B", "A"),
                             test="welch", subject=df["patient_id"], level=0.95,
                             label="B minus A")
    primary["id"] = "primary-welch"
    primary["estimand"] = "mean(B) - mean(A) of marker_mm, mm"

    student = compare_groups(df["marker_mm"], df["group"], contrast=("B", "A"),
                             test="student", subject=df["patient_id"], level=0.95,
                             label="B minus A, pooled variance")
    student["id"] = "sensitivity-student"

    mw = compare_groups(df["marker_mm"], df["group"], contrast=("B", "A"),
                        test="mann_whitney", subject=df["patient_id"], level=0.95,
                        label="B minus A, rank test")
    mw["id"] = "sensitivity-mann-whitney"

    boot = bootstrap_difference(a, b, args.resamples, args.seed)

    X = pd.DataFrame({"groupB": (df["group"] == "B").astype(float),
                      "age": df["age"].astype(float)})
    adj = linear_regression(df["marker_mm"], X, names=["groupB", "age"],
                            subject=df["patient_id"], level=0.95)
    adj["id"] = "sensitivity-age-adjusted"
    adj["estimand"] = "mean difference B - A adjusted for age (OLS), mm"

    desc = descriptives(df)
    means = {d["group"]: d["mean"] for d in desc}
    gap = means["B"] - means["A"]
    # Direction is whatever the corrected labels imply; the check is that the estimate
    # reproduces the descriptive gap, not that the gap has a particular sign.
    estimate_matches_gap = bool(abs(primary["estimate"] - gap) < 1e-9)
    direction = "B_higher" if gap > 0 else ("B_lower" if gap < 0 else "no_difference")
    boot_excludes_zero = bool(boot["interval"]["lower"] > 0 or boot["interval"]["upper"] < 0)

    coding = None
    if args.coding_check:
        cc = json.loads(Path(args.coding_check).read_text())
        coding = {
            "status": cc["status"],
            "checkPath": args.coding_check,
            "checkSha256": sha256(Path(args.coding_check)),
            "originalSha256": cc["original"]["sha256"],
            "correctionSha256": cc["correction"]["sha256"],
            "labelsChanged": int(cc["patients"]["labelsChanged"]),
            "ageMismatches": int(cc["patients"]["ageMismatches"]),
            "markerMismatches": int(cc["patients"]["markerMismatches"]),
            "isExactNegation": bool(cc["estimandConsequence"]["is_exact_negation"]),
            "deltaOriginalMm": float(cc["estimandConsequence"]["delta_original_mm"]),
        }

    warnings = [
        "Cohort is a synthetic continuity fixture (data/dictionary.md): no clinical claim is supported.",
        "Groups A and B are observational categories, not randomised assignments; the age-adjusted estimate is not a causal effect.",
    ]
    if coding is not None:
        warnings.append(
            "Group labels come from the supplied coding correction (A and B were reversed in the "
            "original export); patients and measurements are unchanged, see coding-correction-check.json.")

    results = {
        "schemaVersion": 1,
        "input": {"path": str(src), "sha256": sha256(src),
                  "profilePath": args.profile,
                  "profileSha256": sha256(Path(args.profile))},
        "contrast": {"defined": "B minus A", "unit": "mm",
                     "positiveMeans": "mean marker_mm is higher in group B",
                     "negativeMeans": "mean marker_mm is lower in group B"},
        "descriptives": desc,
        "analyses": [primary, student, mw, boot, adj],
        "checks": {
            "n_analysed": int(len(df)),
            "excluded_missing_outcome": int(profile["checks"]["outcome_missingness"]["n_missing"]),
            "one_row_per_subject": one_row_per_subject,
            "estimate_matches_descriptive_gap": estimate_matches_gap,
            "direction": direction,
            "bootstrap_excludes_zero": boot_excludes_zero,
            "welch_vs_bootstrap_max_gap_mm": float(max(
                abs(primary["interval"]["lower"] - boot["interval"]["lower"]),
                abs(primary["interval"]["upper"] - boot["interval"]["upper"]))),
            "age_smd_signed": profile["checks"]["age_balance"]["signed_standardized_difference_B_minus_A"],
            "age_smd_abs": profile["checks"]["age_balance"]["max_abs_standardized_difference"],
        },
        "coding": coding,
        "warnings": warnings,
    }
    Path(args.out).write_text(json.dumps(results, indent=2, ensure_ascii=False))

    print(json.dumps({r["id"]: {"status": r["status"], "estimate": r.get("estimate"),
                                "interval": r.get("interval"), "pValue": r.get("pValue")}
                      for r in results["analyses"]}, indent=2, ensure_ascii=False))
    print(json.dumps(results["checks"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
