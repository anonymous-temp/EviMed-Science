# Synthetic delivery fixture revision 3
This is precomputed test content, not a research result.
