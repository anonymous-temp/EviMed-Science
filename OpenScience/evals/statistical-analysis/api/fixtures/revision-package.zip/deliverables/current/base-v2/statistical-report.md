# Synthetic delivery fixture revision 2
This is precomputed test content, not a research result.
